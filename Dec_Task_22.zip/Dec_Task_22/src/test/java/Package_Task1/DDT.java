package Package_Task1;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.openqa.selenium.By;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class DDT extends GenericMethods {
	// public static String title;
	public static XSSFSheet sh;
	
	@BeforeTest
	public static void browser() throws Exception {
		startbrowser();
	}

	@Test
	public static void TitlesExtraction() throws IOException, OpenXML4JException {
		String path1=GenericMethods.propertyfile("Excelpath");
		ArrayList<String> URL = GenericMethods.AarrayList(GenericMethods.propertyfile("URL"), GenericMethods.propertyfile("URL1"),
				GenericMethods.propertyfile("URL2"));
		ArrayList<String> titles = new ArrayList<String>();
		
		for (int i = 0; i < URL.size(); i++) {
			driver.get(URL.get(i));
			String title = driver.getTitle();
			titles.add(title);
			
		}
		System.out.println(titles);
		for (int j = 0; j < titles.size(); j++) {
			
			writingdata1(path1,j, 0, titles.get(j));
		}

	}
	
	

	@AfterTest
	public static void teardown() {
		closebrowser();
	}

}