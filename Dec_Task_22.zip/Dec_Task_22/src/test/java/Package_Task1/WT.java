package Package_Task1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WT {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//		File file = new File("D:\\data1.xlsx");
//		FileInputStream fis = new FileInputStream(file);
//		XSSFWorkbook book1 = new XSSFWorkbook(fis);
//		XSSFSheet sh = book1.createSheet();
//		sh.createRow(0).createCell(0).setCellValue("String");
//		FileOutputStream fos = new FileOutputStream(file);
//		book1.write(fos);

		FileInputStream fis = new FileInputStream("D:\\data1.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(fis);

		XSSFSheet sheet = workbook.getSheet("TestData");
		sheet.createRow(0).createCell(0).setCellValue("String");
//		Row row = sheet.createRow(1);
//		Cell cell = row.createCell(1);
//
//		cell.setCellType(cell.CELL_TYPE_STRING);
//		cell.setCellValue("SoftwareTestingMaterial.com");
		FileOutputStream fos = new FileOutputStream("D:\\data1.xlsx");
		workbook.write(fos);
		fos.close();

	}

}
