package Package_Task1;



import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class WritingDataToExcel extends GenericMethods{

	
	@Test
	public static void task1() throws IOException, OpenXML4JException{
		startbrowser();
		
		
		//driver.get(Reusable.propertyfile("URL1"));
		String title1=driver.getTitle();
		System.out.println(title1);
		WebElement text1=driver.findElement(By.id("tabButton"));
		String textt1=text1.getText();
		
		writingdata(title1,textt1);
		
		
		
		
		closebrowser();
		}
		
	
}
