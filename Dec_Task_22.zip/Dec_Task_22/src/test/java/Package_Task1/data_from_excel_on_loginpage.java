package Package_Task1;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class data_from_excel_on_loginpage extends GenericMethods{	
	public static POM_Login pom_login=new POM_Login();
	@BeforeTest
	public static void browser() throws Exception {
		startbrowser();	
	}
	@Test
	public static void excel() throws Exception {
		GenericMethods.sendkeys(pom_login.username,GenericMethods.readdata(1,0));
		GenericMethods.sendkeys(pom_login.password,GenericMethods.readdata(1,1));
		//chooseElement(1,GenericMethods.propertyfile("username")).sendKeys(GenericMethods.readdata(1,0));
		//chooseElement(1,GenericMethods.propertyfile("password")).sendKeys(GenericMethods.readdata(1,1));
		screenshot1();
	}
	@AfterTest
	public static void closebrowser() {
		driver.close();
	}
}