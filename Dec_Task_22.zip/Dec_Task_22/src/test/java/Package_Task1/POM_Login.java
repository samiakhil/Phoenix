package Package_Task1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class POM_Login {
	public static WebDriver driver;
	By username = By.id("username");
	By password = By.id("password");
	public WebElement fullname() {
		return (driver.findElement(username));
	}
	public WebElement enterLastName() {
		return (driver.findElement(password));
	}
	
	
	
	
}
