package Package_Task1;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ThreadFactory;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.xmlbeans.impl.xb.xsdschema.Attribute.Use;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ThreadGuard;
import org.openqa.selenium.support.ui.Select;
import org.testng.Reporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class GenericMethods {
	public static WebDriver driver;
	public static Properties prop = new Properties();
	public static XSSFWorkbook book;
	public static FileInputStream fis;
	public static File file;
	public static XSSFSheet sh;
	public static Actions action;
	public static Row row;
	public static void startbrowser() throws IOException {
		WebDriverManager.chromedriver().setup();
		ChromeOptions opt = new ChromeOptions();
		opt.setExperimentalOption("excludeSwitches", new String[] { "enable-automation" });
		// opt.addArguments("--incognito");
//		String str = propertyfile("headless");
//		boolean headless= true;
//		if (true) {
//			opt.addArguments("--headless");
//		}

//		if (str.equals("true")) {
//			opt.addArguments("--headless");
//		}	
		opt.addArguments("start-maximized");
		driver = ThreadGuard.protect(new ChromeDriver(opt));
		driver.manage().deleteAllCookies();
//		driver.get(GenericMethods.propertyfile("URL"));
	}
	public static String propertyfile(String string) throws IOException {
		FileInputStream fis = new FileInputStream("./src/test/java/Package_Task1/cofigdata.properties");
		prop.load(fis);
		String str = prop.getProperty(string);
		return str;
	}
	public static String writingdata(String title, String textt1) throws IOException {
		File file = new File("C:\\Users\\su21260\\Desktop\\datadata.xlsx");
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook book = new XSSFWorkbook();
		XSSFSheet sh = book.createSheet();
		sh.createRow(0).createCell(0).setCellValue("Title");
		sh.createRow(1).createCell(0).setCellValue(title);
		sh.createRow(2).createCell(0).setCellValue(textt1);
		FileOutputStream fos = new FileOutputStream(file);
		book.write(fos);
		fos.close();
		fis.close();
		return title;
	}
	public static void screenshot1() throws IOException {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File dest = new File("./Screenshot\\" + customizeddate() + ".png");
		FileUtils.copyFile(src, dest);
		Reporter.log("Validation Is completed Successfully......." + "<a href='" + dest.getAbsolutePath()
				+ "' target=_blank'>clickhere</a>");
//		Reporter.log("Login Screen of JQUERY: " + "<a href='" + dest.getAbsolutePath() + "'> <img src='"
	}
	public static WebElement chooseElement(int x, String path) {
		WebElement webElement = null;
		switch (x) {
		case 1:
			webElement = driver.findElement(By.id(path));
			break;
		case 2:
			webElement = driver.findElement(By.className(path));
			break;
		case 3:
			webElement = driver.findElement(By.linkText(path));
			break;
		case 4:
			webElement = driver.findElement(By.xpath(path));
			break;
		case 5:
			webElement = driver.findElement(By.cssSelector(path));
			break;
		case 6:
			webElement = driver.findElement(By.tagName(path));
			break;
		}
		return webElement;
	}
	public static String customizeddate() {
		Date date = new Date();
		String str = date.toString();
		String finalstr = str.replace(":", "");
		String string = finalstr.replace(" ", "");
		return string;
	}
	public static void sendkeys(By locator, String path) {
		try {
			WebElement sendtext = driver.findElement(locator);
			if (sendtext.isDisplayed()) {
				sendtext.sendKeys(path);
			}
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
	}
	public static String readdata(int i, int j) throws IOException {
		fis = new FileInputStream(new File(
				"C:\\Users\\su21260\\Desktop\\Task\\Task1\\Task1\\src\\test\\java\\Package_Task1\\LoginData.xlsx"));
		book = new XSSFWorkbook(fis);
		sh = book.getSheetAt(0);
		int rowcount = sh.getLastRowNum();
		String value = sh.getRow(i).getCell(j).getStringCellValue();
		System.out.println(value);
		return value;
	}
	public static ArrayList<String> AarrayList(String text1, String tex2, String tex3) {
		ArrayList<String> users = new ArrayList<String>();
		users.add(text1);
		users.add(tex2);
		users.add(tex3);
		return users;
	}
	public static void writingdata1(String path,int rowNum, int cellNum, String cellValue) throws IOException {
		File file = new File(path);
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook book = new XSSFWorkbook(fis);
		XSSFSheet sh = book.getSheetAt(0);
		sh.createRow(rowNum).createCell(cellNum).setCellValue(cellValue);
		FileOutputStream fos = new FileOutputStream(file);
		book.write(fos);
		book.close();
	}
	
	public static String excleData(int row, int column) throws Exception {
		FileInputStream fi = new FileInputStream(new File(GenericMethods.propertyfile("Excelpath")));
		XSSFWorkbook wb = new XSSFWorkbook(fi);
		XSSFSheet sh = wb.getSheet("Sheet1");
		String ss = sh.getRow(row).getCell(column).getStringCellValue();
		System.out.println(ss);
		wb.close();
		return ss;
	}
	   public void uploadFileWithRobot (String filePath) {
	        StringSelection stringSelection = new StringSelection(filePath);
	        Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
	        clipboard.setContents(stringSelection, null);
	        Robot robot = null;
	        try {
	            robot = new Robot();
	        } catch (AWTException e) {
	            e.printStackTrace();
	        }
	        robot.delay(250);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        robot.keyPress(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_V);
	        robot.keyRelease(KeyEvent.VK_CONTROL);
	        robot.keyPress(KeyEvent.VK_ENTER);
	        robot.delay(150);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	    }
	public static void closebrowser() {
		driver.close();
	}
	public static void Actions_MoveToElement(WebElement ele) {
		action = new Actions(driver);
		action.moveToElement(ele).build().perform();
	}
	public static void dropdown(WebElement element, String Text) {
		Select select = new Select(element);
		select.selectByVisibleText(Text);
	}
	public static void gettext(String str, String path) {
		if (str.equalsIgnoreCase("xpath")) {
			WebElement ele = driver.findElement(By.xpath(path));
			ele.getText();
		}
	}
	public static List<WebElement> listofelements(String path) {
		List<WebElement> listelement = driver.findElements(By.xpath(path));
		int size = listelement.size();
		for (int i = 0; i <= size; i++) {
			String listtext = listelement.get(i).getText();
		}
		return listelement;
	}
	public static void scrolltoviewelement(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollIntoView", element);
	}
	public static void send_keys(WebElement element,String object) {
		element.click();
		element.clear();
		element.sendKeys(object);
	}
	public static void actionclick(WebElement ele) {
		action = new Actions(driver);
		action.click(ele).build().perform();
	}
	public static void screenshot() throws IOException {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File dest = new File("./Screenshot\\sindhu3.png");
		FileUtils.copyFile(src, dest);
		Reporter.log("Validation Is completed Successfully......." + "<a href='" + dest.getAbsolutePath()
				+ "' target=_blank'>clickhere</a>");
	}	
	public static List findAllLinks(WebDriver driver,String value )
    { 
        List <WebElement> elementList = new ArrayList();
        elementList = driver.findElements(By.tagName("value"));
        List finalList = new ArrayList();
        for(WebElement element : elementList)
        {
            if (element.getAttribute("href") != null)
            {
                finalList.add(element);
            }
        }
        return finalList;
    }	
	
	
	public static void Sleep2k() throws Exception {
		Thread.sleep(2000);
	}

	
}
// sh.createRow(i).createCell(j).setCellValue("Title");
//sh.createRow(i).createCell(0).setCellValue(text1);
//sh.createRow(i).createCell(0).setCellValue(tex2);
//sh.createRow(i).createCell(0).setCellValue(tex3);

//String[] row_heading = { "title" };
//String text1 = driver.getTitle();
//System.out.println(text1);
//WebElement text2 = driver.findElement(By.id("tabButton"));
//String tex2 = text2.getText();
//WebElement text3 = driver.findElement(By.id("messageWindowButton"));
//String tex3 = text3.getText();
//System.out.println(tex3);
//ArrayList<String> users = new ArrayList<String>();
//users.add(text1);
//users.add(tex2);
//users.add(tex3);

//Row headerRow = sh.createRow(0);
//for (int i = 0; i < row_heading.length; i++) {
//	Cell cell = headerRow.createCell(i);
//	cell.setCellValue(row_heading[i]);
//}

//for (int j = 0; j < users.size(); j++) {
//	Row datarow = sh.createRow(j + 1);
//	datarow.createCell(0).setCellValue(users.get(j));
//	datarow.createCell(0).setCellValue(users.get(j));
//	datarow.createCell(0).setCellValue(users.get(j));
//}