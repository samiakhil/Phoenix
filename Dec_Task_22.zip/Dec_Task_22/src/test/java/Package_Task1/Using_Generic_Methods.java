package Package_Task1;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Using_Generic_Methods extends GenericMethods{

	@BeforeTest
	public static void browser() throws Exception {
		startbrowser();
	}

	@Test
	public static void usingmethods() throws IOException, OpenXML4JException {
		

	}

	@AfterTest
	public static void teardown() {
		closebrowser();
	}

}
