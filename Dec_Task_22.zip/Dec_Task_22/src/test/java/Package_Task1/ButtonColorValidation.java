package Package_Task1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.Color;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ButtonColorValidation extends GenericMethods {

	@BeforeTest
	public static void browser() throws Exception {
		startbrowser();
	}

	@Test
	public static void pub() {
		WebElement ele = driver.findElement(By.xpath("/html/body/nav/div/div/div[2]/ul/li[1]/a/button"));

		String srgb = ele.getCssValue("background-color");

		String clr = Color.fromString(srgb).asHex();
		String exp="#f68422";
		System.out.println(clr);
		Assert.assertEquals(clr, exp);
		//assert clr.equals("#f68422");
		if(clr.equals(exp))
		{
			System.out.println("color matched");
		}
	}

	@AfterTest
	public static void teardown() {
		closebrowser();
	}

}
