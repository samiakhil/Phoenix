package internal;

public class test32 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] num= {1,2,3,4,6,7,8,9,10};
int sum=0;
int sum2=0;
for(int i=0;i<num.length;i++) {
	sum+=num[i];
}
//System.out.println(sum);

for(int i=1;i<=10;i++) {
	sum2+=i;

}
//System.out.println(sum2);
System.out.println(sum2-sum);	

	}
}
