package internal;

public class test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] num= {1,2,3,4,5};
int max=0;
for(int i=0;i<num.length;i++)
{
	for (int j=0;j<num.length;j++)
	{
	if((num[i]*num[j])>max)
	{
		max=num[i]*num[j];
		if(num[i]!=num[j] && max==20)
		{
				System.out.println(+num[i]+","+num[j]);
	}
	}

	}
}
	}

}
