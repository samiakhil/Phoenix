package internal;

public class test29 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] num= {1,2,3,4,5,6};
for(int i=num.length-1;i>=0;i--) {
	System.out.print(num[i]);
}
	}

}
