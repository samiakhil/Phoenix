package internal;

import java.util.Arrays;

public class test7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] num= {3, 8, 6, 7, 5, 9};
Arrays.sort(num);
for(int i=0;i<num.length;i++) {
	System.out.print(num[i]);
}

	}

}
