package internal;

public class test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num[]={2, 8, 7, 2, 2, 5, 2, 3, 1, 2, 2};
int max=num.length/2;
for(int i=0;i<num.length;i++) {
	int count=0;
	for(int j=i;j<num.length;j++) {
		if(num[i]==num[j]) {
			count++;
		}	
	}
	if(count>max) {
		//max=count;
		
	System.out.println(num[i]);
	}
}
	}
}
