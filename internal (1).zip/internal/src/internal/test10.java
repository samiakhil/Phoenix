package internal;

public class test10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int [] num= {1, 3, 5, 4, 8, 2, 4, 3, 6, 5 };

int one=num[1];
int two=num[7];
int three=num[5];

System.out.println(Math.abs(1-5));
System.out.println(Math.abs(7-5));
System.out.println(Math.min(4,2));
	}

}
