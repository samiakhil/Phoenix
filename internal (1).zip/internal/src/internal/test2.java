package internal;

import java.util.Arrays;

public class test2 {
	
	public static void main(String[] args) {
		int[] num=  { 1, 0, 1, 0, 1, 0, 0, 1 };
		// TODO Auto-generated method stub
		
	Arrays.sort(num);
	for(int i=0;i<num.length;i++) {
System.out.print(num[i]);
	}
	}
}
