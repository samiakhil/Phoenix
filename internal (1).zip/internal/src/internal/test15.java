package internal;

import java.util.Arrays;

public class test15 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] num= {-6, -5, -3,0, 2, 4, 9};
int[] abs=new int[50];
int count=0;	
for(int i=0;i<num.length;i++) {
	for(int j=0;j<num.length;j++) {
		
		int n=Math.abs(num[i]+num[j]);
		if(n!=0)
		{
	
		abs[count]=n;
		//System.out.println(abs[0+count]);
		count++;
	}
		
}
	
}
//System.out.println(abs[0]);
Arrays.sort(abs);
System.out.println(abs[2]);



}
}