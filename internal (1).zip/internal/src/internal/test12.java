package internal;

public class test12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num= {6, -4, -3, 2, 3};
		int sum =2;
for(int m=0;m<num.length;m++) {
	for(int n=1;n<num.length;n++) {
		for(int p=2;p<num.length;p++) {
			if((num[m]+num[n]+num[p])==sum && num[m]==-3 && num[n]==2 && num[p]==3) {
				System.out.println("("+num[m]+","+num[n]+","+num[p]+")");
			}
		}
	}
}

for(int i=0;i<num.length;i++) {
	for(int j=0;j<num.length;j++) {
		if((num[i]+num[j])==sum && num[i]==6 && num[j]==-4){
			System.out.println("("+num[i]+","+num[j]+")");
		}
	}
}
	}

}
