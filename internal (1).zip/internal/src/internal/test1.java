package internal;

public class test1 {
		
		public static void main(String[] args) {
			int[] nums = {8, 7, 2, 5, 3, 1};
			for (int i=0;i<nums.length;i++) {
				for (int j=0;j<nums.length;j++) {
					if(nums[i]+nums[j]==10) {
						System.out.println("pair found ("+nums[i]+","+nums[j]+")");
					}
				}
			}
		}

	}

