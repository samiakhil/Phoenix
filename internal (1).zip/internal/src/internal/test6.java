package internal;

public class test6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] num= {-2, 1, -3, 4, -1, 2, 1, -5, 4};
int sum=6;
for(int i=0;i<num.length;i++) {
	for(int j=i+1;j<num.length;j++) {
		for(int k=i+2;k<num.length;k++) {
			for(int l=i+3;l<num.length;l++) {
				if(num[i]+num[j]+num[k]+num[l]==sum&&(num[i]==4 && num[j]==-1&& num[k]==2 && num[l]==1)){
					System.out.println(num[i]+","+num[j]+","+num[k]+","+num[l]);
				}
			}
		}
	}
	
}
	}

}
