package internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class test8 {
public static int prod(List<Integer> set, int maximum) {
	int product=1;
	for(int j : set) {
		product*=j;
	}
	if(set.size()!=0) {
		maximum=Integer.max(maximum,product);
	}
	return maximum;
}
public static int findpowerset(List<Integer> S, List<Integer> set,int n, int maximum) {
	if(n==0) {
		return prod(set,maximum);
	}
	set.add(S.get(n-1));
	maximum=findpowerset(S,set,n-1,maximum);
	set.remove(set.size()-1);
	return findpowerset(S,set,n-1,maximum);
}
public static void main(String[] args) {
	List<Integer> S=Arrays.asList( -6, 4, -5, 8, -10, 0, 8);
	int n=S.size();
	List<Integer>set=new ArrayList<>();
	int maximum=findpowerset(S,set,n,Integer.MIN_VALUE);
	System.out.println("The product is :"+maximum);
}

}
