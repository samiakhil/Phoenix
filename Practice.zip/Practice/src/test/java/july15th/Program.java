package july15th;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Program {

   // public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//		String si= "dad";
//		String rev="";
//		
//		for(int i=si.length()-1;i>=0;i--){
//			
//			rev=rev+si.charAt(i);
//			
//		}
//		
//		if(si.equalsIgnoreCase(rev)) {
//			
//		
//		System.out.println(rev);
//		}
//		//System.out.println(rev);
//		else {
//		System.out.println(rev);
//	}
//		
//	}

//	----------------------------------------------------------------------------
	//public static void main(String[] args) {
		
//	--windows Handiling--
//	
//	WebDriverManager.chromedriver().setup();
//	
//	WebDriver driver = new ChromeDriver();
//
//	driver.manage().window().maximize();
//
//	// Load the website
//	driver.get("http://www.naukri.com/");
//
//	// It will return the parent window name as a String
//	String parent=driver.getWindowHandle();
//
//	Set<String>s=driver.getWindowHandles();
//
//	// Now iterate using Iterator
//	Iterator<String> I1= s.iterator();
//
//	while(I1.hasNext())
//	{
//
//	String child_window=I1.next();
//
//
//	if(!parent.equals(child_window))
//	{
//	driver.switchTo().window(child_window);
//
//	System.out.println(driver.switchTo().window(child_window).getTitle());
//
//	driver.close();
//	}
//
//	}
//	//switch to the parent window
//	driver.switchTo().window(parent);
//
//	}
//	
	
//	-------------------------------------
	
	
	
	WebDriver driver = new ChromeDriver();

	driver.manage().window().maximize();

	driver.get("https://www.browserstack.com/");

	((JavascriptExecutor) driver).executeScript("scroll(0,300)");

	Actions ac = new Actions(driver);

	WebElement live= driver.findElement(By. cssSelector("div.product-cards-wrapper--click a[title='Live']")); 
	ac.moveToElement(live).build().perform();

	Thread.sleep(3000);

	WebElement automate= driver.findElement(By.cssSelector("div.product-cards-wrapper--click a[title='App Automate']"));
	automate.click();

	Thread.sleep(2000);

	//Thread.sleep(4000);

driver.close();

	
//	Actions as = new Actions(driver);
//	as.moveToElement(automate).perform();
//	as.dragAndDrop(live, automate).perform();
//	
//	driver.findElement(By.cssSelector("div.product-cards-wrapper--click a[title='App Automate']")).click();
	
	
    
    
}
	   }
	
}
	
	
}	
	

