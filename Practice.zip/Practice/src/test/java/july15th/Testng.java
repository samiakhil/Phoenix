package july15th;




import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Testng {
	
	@Test
	public void testss() {
	
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://chromedriver.chromium.org/downloads");
	 WebElement ele=   driver.findElement(By.xpath("//span[text()='the Chrome for Testing availability dashboard']"));
	     ele.click();
	     boolean s=ele.getText() != null;
	     Assert.assertTrue(s);

		
	
	

}
}