package Utilitys;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

public class Confiures {

	
	
	 public static Properties ps;
	    public static FileInputStream fi;

	public static String prop(String Key) throws Throwable {

		  fi = new FileInputStream("C:\\Users\\LENOVO\\eclipse-workspace\\Selenium_Framework\\src\\test\\java\\Utilitys\\config.properties");
		 ps= new Properties();
	     
		ps.load(fi);
		return Key;
		
		
	}

}
