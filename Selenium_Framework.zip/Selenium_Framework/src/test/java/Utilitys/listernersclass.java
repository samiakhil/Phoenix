package Utilitys;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Utilitys.Listernersxample;

@Listeners(Listernersxample.class) 

public class listernersclass {

	

		
		@Test
		public static  void test1() {
			
		System.out.println(" passed1");
		
		}
		@Test
		public static void test2() {
			
			Assert.assertFalse(true);
			System.out.println("failed");
		
		}
		@Test(timeOut=1000)
		public static void test3() throws Throwable {
			
			Thread.sleep(3000);
			
			System.out.println("timeout failed");
			
			
		}
		@Test(dependsOnMethods= "test3" ,alwaysRun=true )
		public static void test4() {
			
			
			System.out.println("skipped");
		}
		
					
					
	}
	
	
	
	
	

