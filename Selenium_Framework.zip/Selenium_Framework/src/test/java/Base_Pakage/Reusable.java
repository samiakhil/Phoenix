package Base_Pakage;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import Page_objects.admin_page;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Reusable {

	public static WebDriver driver;
   
	
	public static void openurl() throws Throwable {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		Thread.sleep(5000);
	}

	
	public static void click(By ele ) {
		
		driver.findElement(ele).click();

	}
	
	public static void closeBrowser() {
		driver.close();
		
	}

	public static void synchonization() throws Throwable {
		
		Thread.sleep(4000);
	}
	
	public static void enterdata(By el,String val) {
		
		driver.findElement(el).sendKeys(val);
	}
	
	public static void dropdown(By di,String data) { 
	Select s = new Select(driver.findElement(di));
	s.selectByValue(data);
	  }

	
	public static void screenshots(WebDriver driver,String Filepath ) throws Throwable {
		
		TakesScreenshot scrShot =((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		File DestFile=new File(Filepath);
		FileUtils.copyFile(SrcFile, DestFile);
		
			}
	
//	
	
	
}
