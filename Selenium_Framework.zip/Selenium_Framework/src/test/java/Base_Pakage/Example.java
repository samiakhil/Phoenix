//package Base_Pakage;
//
//import java.awt.Robot;
//import java.awt.event.KeyEvent;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.Test;
//
//import Page_objects.admin_page;
//import io.github.bonigarcia.wdm.WebDriverManager;
//
//public class Example extends admin_page{
//
//	public static WebDriver driver;
//	
//	@Test
//	public static void main() throws Throwable {
//		
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//		Thread.sleep(5000);
//		
//
//		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Admin");
//		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("admin123");
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button")).click();
//	Thread.sleep(5000);
//		
//	sendkeys(admin);
//		//driver.findElement(By.xpath("(//*[text()=\"Admin\"])[1]")).click();
//		Thread.sleep(4000);
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div[2]/div[1]/button")).click();
//		Thread.sleep(5000);
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[1]/div/div[2]/div/div/div[2]/i")).click();
//		Robot rb = new Robot();
//		rb.keyPress(KeyEvent.VK_DOWN);
//		rb.keyPress(KeyEvent.VK_DOWN);
//
//		rb.keyPress(KeyEvent.VK_ENTER);
//		
//		//driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/div/div[2]/div/div/input")).sendKeys("akhil");
//		
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[3]/div/div[2]/div/div/div[2]/i")).click();
//		
//		Robot rbs = new Robot();
//		rbs.keyPress(KeyEvent.VK_DOWN);
//	
//		rbs.keyPress(KeyEvent.VK_DOWN);
//
//		rb.keyPress(KeyEvent.VK_ENTER);
//		Thread.sleep(5000);
//		
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[2]/div/div[2]/div/div/input")).sendKeys("Fiona Gra");
//		Thread.sleep(5000);
//		Robot rbi = new Robot();
//		rbi.keyPress(KeyEvent.VK_DOWN);
//	
//		//rbi.keyPress(KeyEvent.VK_DOWN);
//
//		rbi.keyPress(KeyEvent.VK_ENTER);
//		Thread.sleep(5000);
//		
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[4]/div/div[2]/input")).sendKeys("sakhill23");
//		
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[1]/div/div[2]/input")).sendKeys("Akhil@123");
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[2]/div/div[2]/div/div[2]/input")).sendKeys("Akhil@123");
//
//		driver.findElement(By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[3]/button[2]")).click();
//
//				
//		
//		
//		
//		
//	}
//	
//	
//	
//}
