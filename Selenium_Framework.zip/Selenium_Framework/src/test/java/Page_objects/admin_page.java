package Page_objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class admin_page {

	
	

	public static By username= By.xpath("//input[@name='username']");
	public  static By password= By.xpath("//input[@name='password']");
	public static By login_button =By.xpath("//*[@id=\"app\"]/div[1]/div/div[1]/div/div[2]/div[2]/form/div[3]/button");
	
	
   public  static By admin = By.xpath("//*[@id=\"app\"]/div[1]/div[1]/aside/nav/div[2]/ul/li[1]/a/span");
	public static By Add_button = By.xpath("//button[@class='oxd-button oxd-button--medium oxd-button--secondary']");   
	public static By User_role = By.xpath ("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[1]/div/div[2]/div/div/div[2]/i");
    public static By statu =By.xpath("//*[@id=\"app\"]/div[1]/div[2]/div[2]/div/div/form/div[1]/div/div[3]/div/div[2]/div/div/div[2]/i");
	
	

		
	
	
	
}
