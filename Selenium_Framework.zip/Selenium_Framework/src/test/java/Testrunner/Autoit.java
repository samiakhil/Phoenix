package Testrunner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Autoit {

	public static WebDriver driver;
		@Test	
		public static void fileupload() {
		WebDriverManager.chromedriver().setup();
	       driver = new ChromeDriver();
		
		driver.get("https://www.ilovepdf.com/pdf_to_word");
		//driver.findElement(By.xpath("")).click();
		
		
		
		}	
		
	}


