package Testrunner;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.FileInputStream;
import java.util.Properties;

import org.testng.annotations.Test;

import Base_Pakage.Reusable;
import Page_objects.admin_page;
import Utilitys.Confiures;

public class Testscript extends Reusable {

	//admin_page lo = new admin_page();
	
	//
	 public static Properties ps;
	    public static FileInputStream fi;
	
	   
	    
	@Test(priority=0)
	public static void login() throws Throwable {
		
		//String  sm =Confiures.prop("un");
		openurl();
        ps= new Properties();
        fi = new FileInputStream("C:\\Users\\LENOVO\\eclipse-workspace\\Selenium_Framework\\src\\test\\java\\Utilitys\\Property.file");
     	ps.load(fi);
		    
     	synchonization();

		enterdata(admin_page.username, ps.getProperty("un"));
		enterdata(admin_page.password, ps.getProperty("passwords"));
		click(admin_page.login_button);
		synchonization();
		}
	
	@Test(priority=1)
	public static void adduser() throws Throwable {
		
		synchonization();
		click(admin_page.admin);
		synchonization();
		click(admin_page.Add_button);
		click(admin_page.User_role);
		synchonization();
		Robot rb = new Robot();
		rb.keyPress(KeyEvent.VK_DOWN);
		rb.keyPress(KeyEvent.VK_DOWN);

    	rb.keyPress(KeyEvent.VK_ENTER);
		
    	click(admin_page.statu);
    	synchonization();
    	Robot rbs = new Robot();
		rbs.keyPress(KeyEvent.VK_DOWN);
	
		rbs.keyPress(KeyEvent.VK_DOWN);

		rb.keyPress(KeyEvent.VK_ENTER);
    	
	}
	
	
	
}
