package failtestcases_taking_scrrenshots;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class listernersxample1 extends Reusables implements ITestListener{

	
	
	 
	 
	 
	  public void onTestFailure(ITestResult result) {
	  
		
		
			screenshots(result.getMethod().getMethodName()+".png");
		} 
					
		}
		  
		  
		  
	 		    
	  
		  
	 	
	

