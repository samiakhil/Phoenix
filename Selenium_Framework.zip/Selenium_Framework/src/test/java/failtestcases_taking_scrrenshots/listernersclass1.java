package failtestcases_taking_scrrenshots;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Page_objects.admin_page;
import Utilitys.Listernersxample;

@Listeners(listernersxample1.class) 

public class listernersclass1 extends Reusables{

	
	//admin_page obj = new admin_page();
	
	@Test
	
    	
	public static void launchorangehrm() throws Throwable {
		
		
		openurl1();
		
		synchonization();
		
		
		enterdata(admin_page.username, "Admin");
		enterdata(admin_page.password,"admin12");
	screenshots("login");
		click(admin_page.login_button);
		
	}
     
		
	
		
					
					
	}
	
	
	
	
	

