Prerequisites:
=============

1. Install Java jdk-1.8 or higher in machin.
2. Install Eclipse IDE , and add TestNG, Maven Plugins.

 Project clone : clone the pigeon hole project from below git url
=============

 url: https://github.com/ojashub/PigeonLab

* pull code from UAT branch
stepts :  git checkout UAT
	  git pull
 
 
Run Project:
============

To run Test suite: 
----------------

Steps:
 1.import cloned project to eclipse
 2. go to pigeonsuite.xml file-> right click on pigeonSuite.xml -> run as -> TestNG suite
 
 To run individual Test script:
 -----------------------------
 
 Steps:
 1.import cloned project to eclipse
 2.go to src/test/java ->com.PigeonholeLive.Scripts package --> go to scenario Test class --> 
 go to GenericMethods.openBrowser(browser) method in @Beforeclass --> change browser value, like GenericMethods.openBrowser("ie/chrome") --> then right click -> run as -> click TestNg test 
 
 
 Results:
 =======
  go to test-ouput folder --> open pigeon-emailable-report.html file