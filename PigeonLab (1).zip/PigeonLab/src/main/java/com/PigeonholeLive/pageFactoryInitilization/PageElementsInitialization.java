package com.PigeonholeLive.pageFactoryInitilization;

import org.openqa.selenium.support.PageFactory;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AdminPanelPage;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.AppearancePage;
import com.PigeonholeLive.Pages.AudienceWebAppPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.LoginPage;
import com.PigeonholeLive.Pages.ProfilePage;
import com.PigeonholeLive.Pages.ProjectorPanelPage;
import com.PigeonholeLive.Pages.PurchasePage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Pages.SecurityPage;
import com.PigeonholeLive.Pages.SessionPage;

public class PageElementsInitialization extends GenericMethods {

	// Login page elements initialization
	public void loginPageObjectory() {

		PageFactory.initElements(driver, LoginPage.class);
	}

	// Dashboard page elements initialization
	public void dashBoardPageObjectory() {

		PageFactory.initElements(driver, DashboardPage.class);
	}

	// AdminPannel page elements initialization
	public void adminPannelPageObjectory() {

		PageFactory.initElements(driver, AdminPanelPage.class);
	}

	// AWA page elements initialization
	public void AWAPageObjectory() {

		PageFactory.initElements(driver, AudienceWebAppPage.class);
	}

	// Projector panel page elements initialization
	public void projecterPageObjectory() {

		PageFactory.initElements(driver, ProjectorPanelPage.class);
	}

	// Run events page elements initialization
	public void runEventsPageObjectory() {

		PageFactory.initElements(driver, RunEventsPage.class);
	}

	// Session page elements initialization
	public void sessionPageObjectory() {

		PageFactory.initElements(driver, SessionPage.class);
	}

	// Agenda page elements initialization
	public void agendaPageObjectory() {

		PageFactory.initElements(driver, AgendaPage.class);
	}

	// Purchase page elements initialization
	public void purchasePageObjectory() {

		PageFactory.initElements(driver, PurchasePage.class);
	}

	// Profile page elements initialization
	public void profilePageObjectory() {

		PageFactory.initElements(driver, ProfilePage.class);
	}

	// Security page elements initialization
	public void securityPageObjectory() {

		PageFactory.initElements(driver, SecurityPage.class);
	}

	// Appearance page elements initialization
	public void appearancePageObjectory() {

		PageFactory.initElements(driver, AppearancePage.class);
	}

}
