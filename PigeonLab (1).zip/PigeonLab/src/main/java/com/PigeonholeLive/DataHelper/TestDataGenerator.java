package com.PigeonholeLive.DataHelper;

import java.util.Locale;
import com.github.javafaker.Faker;

public class TestDataGenerator {
	static Faker faker = new Faker(new Locale("en-SG"));

	// Random Data Generation
	public static String randomTestName = faker.name().name();
	public static String randomEventName = faker.book().title().replaceAll("'", "1");
	public static String randomSessionName = faker.book().title().replaceAll("'", "1");
	public static String randomAddress = faker.address().streetAddress();
	public static String randomCity = faker.address().city();
	public static String randomState = faker.address().state();
	public static String randomZipCode = faker.address().zipCode();
	public static String randomName = faker.name().fullName();
	public static String description = faker.lorem().characters();
	public static String textMessage = faker.lorem().sentence(2);
	public static String question = faker.name().firstName().replaceAll(" ", "");
	public static String firstOption = faker.name().name();
	public static String secondOption = faker.name().name();
	
	
	public static String textAnswer = faker.lorem().characters(10);

	public static void main(String[] args) {
		System.out.println(randomAddress);
		System.out.println(randomZipCode);
		System.out.println(randomCity);
		System.out.println(randomState);

	}

}
