package com.PigeonholeLive.Utilities;

public class ApplicationTittles {

	public static final String agendaPageTitle = "2018 Asia Leadership Conference - Agenda - Pigeonhole Live Dashboard";
	public static final String dashBoardTitle = "My Pigeonholes - Pigeonhole Live Dashboard";
	public static final String loginPageTitle = "Login to your account - Pigeonhole Live Dashboard";	
	public static final String runEventsTitle = "2018 Asia Leadership Conference - Run - Pigeonhole Live Dashboard";
}
