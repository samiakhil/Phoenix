package com.PigeonholeLive.Pages;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class AgendaPage extends GenericMethods {
	
	// Page Elements section
	@FindBy(how = How.CSS, using = ".add-session-btn")
	public static WebElement addSessionLink;

	@FindBy(how = How.CSS, using = "[class='session-name']")
	public static WebElement sessionNameTextField;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='link-content']/parent::a)[2]")
	public static WebElement agendaButton;
	
	@FindBy(how = How.XPATH, using = "(//label[@class=\"p-checkbox hide-if-archived   \"]/span)[11]")
	public static WebElement answersVerifyCheckBox;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='link-content'])[2]")
	public static WebElement agendaLink;
	
	@FindBy(how = How.XPATH, using = "//div//p[@class='lead empty-text']")
	public static WebElement redeemMessage;
	
	@FindBy(how = How.XPATH, using = "//strong[contains(text(), 'Technology and Corporate Communications')]")
	public static WebElement getSessionName;
	
	@FindBy(how = How.XPATH, using = "//div[3]/div/a//span[1]")
	public static WebElement editButton;
	
	@FindBy(how = How.XPATH, using = "//div[7]/label/span[1]")
	public static WebElement checkAnswerCheckbox;
	
	@FindBy(how = How.CSS, using = "div > div.help-center__wrapper > a")
	public static WebElement tooltipButton;
	
	@FindBy(how = How.CSS, using = ".btn-save-session")
	public static WebElement saveQAbutton;
	
	@FindBy(how = How.CSS, using = ".quick-run-button")
	public static WebElement runLinkButton;

	@FindBy(how = How.XPATH, using = "//a[text()=\"Admin Panel\"]")
	public static WebElement adminpanelButton;
	
	
	// Page Commands section
	public void selectAddSession() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		agendaButton.click();
		GenericMethods.sychronizationinterval();
		addSessionLink.click();
	}

	public void clickOnAgendaLinkButton() {
	
		agendaLink.click();	
	}
	
	public void clickOnEditButton() {		
		
		editButton.click();	
	}
	
	public void clickOnAnswersCheckbox() {		
		
		checkAnswerCheckbox.click();	
	}

	public void clickOnToolTip() {
		
		tooltipButton.click();
		tooltipButton.click();
	}
	
	public void clickOnSaveQA() {
		
		saveQAbutton.click();
	}
	
	public void clickOnRunLinkButton() {
		
		runLinkButton.click();
	}

	public void clickOnAdminPanel() {

		adminpanelButton.click();
	}
}
