package com.PigeonholeLive.Pages;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class ProjectorPanelPage extends GenericMethods {

}
