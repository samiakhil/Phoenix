package com.PigeonholeLive.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class DashboardPage extends GenericMethods {

	// Page Elements section
	@FindBy(how = How.CSS, using = ".pigeonhole-listview__add-btn")
	public static WebElement addPigeonHoleButton;

	@FindBy(how = How.CSS, using = ".workspace-tooltip__dismiss")
	public static WebElement gotItButton;

	@FindBy(how = How.CSS, using = ".pigeonhole-listview--addbasic-btn")
	public static WebElement basicPigeonHoleButton;

	@FindBy(how = How.XPATH, using = "//div[@class='dd-item pigeonhole-listview--purchase-btn']//span[text() ='Premium Pigeonhole']")
	public static WebElement premiumPigeonHoleButton;

	@FindBy(how = How.XPATH, using = "//a[@class='profile-dropdown__button']")
	public static WebElement accountDropdownLink;

	@FindBy(how = How.XPATH, using = "//a[contains(text(),'Account Settings')]")
	public static WebElement accountSettingsLink;

	@FindBy(how = How.CSS, using = "[name='oldPassword']")
	public static WebElement currentPasswordField;

	@FindBy(how = How.CSS, using = "[name='password']")
	public static WebElement newPasswordField;

	@FindBy(how = How.CSS, using = "[name='passwordConfirm']")
	public static WebElement confirmPasswordField;

	@FindBy(how = How.XPATH, using = "//button[text() = 'Save']")
	public static WebElement saveButton;

	@FindBy(how = How.XPATH, using = "//span[@class='icon icon-logout']")
	public static WebElement logoutButton;

	@FindBy(how = How.CSS, using = "[class = 'modal-affirmative-button btn btn-primary btn-lg']")
	public static WebElement gotItButtonOne;

	@FindBy(how = How.XPATH, using = "//p[contains(text(),'My Team Workspace')]")
	public static WebElement myTeamWorkSpaceButton;

	@FindBy(how = How.CSS, using = "[class='header-nav-button header-nav-button-templates']")
	public static WebElement templatesButton;

	@FindBy(how = How.CSS, using = "[class='btn btn-primary dropdown-toggle create-template-button pull-right']")
	public static WebElement createTemplateButton;

	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Poll')]")
	public static WebElement pollTemplateLink;

	@FindBy(how = How.CSS, using = "[class^='create']")
	public static WebElement createNewTemplateButton;

	@FindBy(how = How.CSS, using = "[class='pigeonhole-listview__list-link-classy']")
	public static WebElement asiaLeadershipConferenceLink;

	@FindBy(how = How.CSS, using = ".pigeonhole-listview__list-link-classy")
	public static WebElement eventName;
	
	@FindBy(how = How.XPATH, using = "//button[@class='btn btn-tertiary pigeonhole-listview__annual-btn']")
	public static WebElement annualPlanButton;
	
	@FindBy(how = How.CSS, using = "[class$='icon-small']")
	public static WebElement greyPlusIcon;

	@FindBy(how = How.CSS, using = "[placeholder$='Event Name']")
	public static WebElement eventNameInput;

	@FindBy(how = How.CSS, using = ".random-passcode-button")
	public static WebElement randomPassCodeLink;

	@FindBy(how = How.CSS, using = ".modal-affirmative-button ")
	public static WebElement continueButton;
	
	@FindBy(how = How.XPATH, using = "//div//h2[contains(text(),' Set Up Your Event')]")
	public static WebElement setUpEvent;
	
	@FindBy(how = How.XPATH, using = "//div//h2[contains(text(), 'You')]")
	public static WebElement youHaveJoinedTeam;
	
	@FindBy(how = How.CSS, using = "a > span.workspace-switcher__logo > span")
	public static WebElement teamWorspacelogo;
	
	@FindBy(how = How.XPATH, using = "(//div/ul/li[3])[1]")
	public static WebElement teamSettings;
	
	@FindBy(how = How.XPATH, using = "(//div[1]/div/a)[26]")
	public static WebElement ongoingPigeonhole;
	
	// Page Commands section
	public void clickOnGotItButton() {

		gotItButton.click();
	}

	public void clickOnAddPigeonHole() {

		addPigeonHoleButton.click();
	}

	public void clickOnPremiumPigeonHole() throws Throwable {

		GenericMethods.sychronizationinterval();
		clickOnGotItButton();
		clickOnAddPigeonHole();
		GenericMethods.sychronizationinterval();
		Thread.sleep(2000); //Synchronization required
		premiumPigeonHoleButton.click();
	}

	public void clickBasicPigeonhole() throws Throwable {

		Thread.sleep(5000); //Synchronization required
		clickOnGotItButton();
		clickOnAddPigeonHole();
		basicPigeonHoleButton.click();
	}

	public void addSession() throws Throwable {

		gotItButton.click();
		asiaLeadershipConferenceLink.click();
		GenericMethods.sychronizationinterval();
		AgendaPage.addSessionLink.click();
	}

	public void changeToNewPassword(String randomPassword) throws Throwable {

		gotItButton.click();
		accountDropdownLink.click();
		GenericMethods.sychronizationinterval();
		accountSettingsLink.click();
		GenericMethods.switchToNewWindow(1);
		GenericMethods.sychronizationinterval();
		String getPasswordText = LoginPage.passwordText.getText();
		String[] password = getPasswordText.split("\\s");
		GenericMethods.switchToNewWindow(2);
		GenericMethods.sychronizationinterval();
		currentPasswordField.sendKeys(password[1]);
		newPasswordField.sendKeys(randomPassword);
		confirmPasswordField.sendKeys(randomPassword);
		saveButton.click();
	}

	public static void logoutFromDashboard() throws Throwable {
		
		Thread.sleep(5000);//Synchronization required 
		accountDropdownLink.click();
		GenericMethods.sychronizationinterval();
		logoutButton.click();
	}

	public void validateLoginAuthentication(String randomPassword) throws Throwable {

		GenericMethods.switchToNewWindow(1);
		String EmailText = LoginPage.emailText.getText();
		String[] userName = EmailText.split("\\s");
		GenericMethods.switchToNewWindow(2);
		LoginPage.emailField.sendKeys(userName[1]);
		LoginPage.continueToLoginButtonOne.click();
		GenericMethods.sychronizationinterval();
		LoginPage.passwordField.sendKeys(randomPassword);
		LoginPage.logintoWorkspaceButton.click();
	}

	public void navigatingToTeamDashboard() throws Throwable {

		gotItButtonOne.click();
		GenericMethods.sychronizationinterval();
		myTeamWorkSpaceButton.click();
		GenericMethods.sychronizationinterval();
		templatesButton.click();
		GenericMethods.sychronizationinterval();
		createTemplateButton.click();
		GenericMethods.sychronizationinterval();
		pollTemplateLink.click();
		GenericMethods.sychronizationinterval();
		createNewTemplateButton.click();
	}

	public void clickOnEvent() {

		eventName.click();

	}

	public void navigatToRunYourEventPage() {

		gotItButton.click();
		asiaLeadershipConferenceLink.click();
	}

	public void clickOnAnnualPlan() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		annualPlanButton.click();
	}
	
	public void clickOnGotItButtonOne() {

		gotItButtonOne.click();
	}

	public void clickOnMyTeamWorkSpace() {

		myTeamWorkSpaceButton.click();
	}

	public void clickOnGreyPlusIcon() {

		greyPlusIcon.click();
	}
	
	public void fillEventName(String name) {

		eventNameInput.sendKeys(name);
	}

	public void clickOnRandomPassCode() {

		randomPassCodeLink.click();
	}

	public void clickOnContinueButton() {

		continueButton.click();
	}
	
	public void clickOnTeamWorkspaceLogo() {

		teamWorspacelogo.click();
	}
	
	public void clickOnTeamSettings() {

		teamSettings.click();
	}
	public void clickOnOngoingPigeonhole() {

		ongoingPigeonhole.click();
	}
}
