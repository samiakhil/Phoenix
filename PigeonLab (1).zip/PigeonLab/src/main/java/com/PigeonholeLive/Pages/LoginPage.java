package com.PigeonholeLive.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class LoginPage extends GenericMethods {

	// Page Elements section
	@FindBy(how = How.XPATH, using = "//a[text() = 'Login page']")
	public static WebElement loginpageLink;

	@FindBy(how = How.CSS, using = "div:nth-child(2)")
	public static WebElement emailText;

	@FindBy(how = How.CSS, using = "div:nth-child(3)")
	public static WebElement passwordText;

	@FindBy(how = How.CSS, using = "[name='email']")
	public static WebElement emailField;

	@FindBy(how = How.XPATH, using = "//button[text() = 'Continue to Login']")
	public static WebElement continueToLoginButtonOne;

	@FindBy(how = How.CSS, using = "[name='passwd']")
	public static WebElement passwordField;

	@FindBy(how = How.CSS, using = "[type='submit']")
	public static WebElement logintoWorkspaceButton;

	// Page Commands section
	public void clickOnLoginpageButton() throws Throwable {

		GenericMethods.sychronizationinterval();
		loginpageLink.click();
	}

	public void setPassword() throws Throwable {
		
		continueToLoginButtonOne.click();
		GenericMethods.switchToNewWindow(1);
		String getPasswordText = passwordText.getText();
		String[] password = getPasswordText.split("\\s");
		GenericMethods.switchToNewWindow(2);
		GenericMethods.sychronizationinterval();
		passwordField.sendKeys(password[1]);
		logintoWorkspaceButton.click();
	}
	public void logintoPigeonholeLiveAccount() throws Throwable {
	
			String EmailText = emailText.getText();
			String[] userName = EmailText.split("\\s");
			GenericMethods.sychronizationinterval();
			GenericMethods.switchToNewWindow(2);
			GenericMethods.sychronizationinterval();		
			try {
				GenericMethods.elementToBePresent(emailField);
				emailField.sendKeys(userName[1]);
				setPassword();
			}		
			catch(Exception e) { 
				DashboardPage.logoutFromDashboard();
				GenericMethods.sychronizationinterval();
				emailField.sendKeys(userName[1]);
				setPassword();
			}
	}

}
