package com.PigeonholeLive.Pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class AudienceWebAppPage extends GenericMethods {

	// Page Elements section
	@FindBy(how = How.XPATH, using = "(//a//span[text()='Enter this Discussion'])[3]")
	public static WebElement enterThisDiscussionLink;
	
	@FindBy(how = How.XPATH, using = "(//a//span[text()='Enter this Discussion'])[1]")
	public static WebElement enterThisDiscussionLinkTwo;
	
	@FindBy(how = How.CSS, using = "[class='question-input']")
	public static WebElement openTextField;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'Submit')]")
	public static WebElement submitButton;
	
	@FindBy(how = How.CSS, using = "[class='modal-text']")
	public static WebElement textName;
	
	@FindBy(how = How.CSS, using = "[class='btn btn-primary modal-btn modal-btn-ok']")
	public static WebElement submitButtonTwo;
	
	@FindBy(how = How.CSS, using = "[class='question-content allow-user-select']")
	public static WebElement answerText;
	
	@FindBy(how = How.CSS, using = "[class='icon icon-qna-vote-outline question-vote-triangle']")
	public static WebElement upIconButton;
	
	@FindBy(how = How.CSS, using = "[class='allow-user-select']")
	public static WebElement agenda;
	
	
	
	//Page Commands section
	public void clickOnOpenSessionLink() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		GenericMethods.switchToNewWindow(2);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,750)");
		Thread.sleep(4000);
		enterThisDiscussionLink.click();
	}
	
	public void setAnswer(String textMessage) throws Throwable {
		
		openTextField.sendKeys(textMessage);
		GenericMethods.sychronizationinterval();
		submitButton.click();
		GenericMethods.sychronizationinterval();
	}
	
	public void clickOnWordCloudSessionLink() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		GenericMethods.switchToNewWindow(2);
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,750)");
		Thread.sleep(4000);
		enterThisDiscussionLinkTwo.click();
	}
}
