package com.PigeonholeLive.Pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class RunEventsPage extends GenericMethods {

	// Page Elements section
	@FindBy(how = How.CSS, using = ".quick-run-button")
	public static WebElement runLinksButton;

	@FindBy(how = How.CSS, using = "[class='active']")
	public static WebElement runYourEventHeader;

	@FindBy(how = How.CSS, using = "[class='icon icon-help']")
	public static WebElement questionMark;

	@FindBy(how = How.CSS, using = "[data-panel-type='Audience Web App']")
	public static WebElement AWA_Link;
	
	@FindBy(how = How.CSS, using = "[data-panel-type='Admin Panel']")
	public static WebElement AdminPanel_Link;

	@FindBy(how = How.CSS, using = ".upgrade-btn")
	public static WebElement upgradeLink;

	@FindBy(how = How.CSS, using = ".box-PLAN_V5_UP_CAPTIVATE")
	public static WebElement selectCaptivate;

	@FindBy(how = How.XPATH, using = "(//tr[@class=\"purchase-row-big\"]/child::td[2])[1]")
	public static WebElement totalVerifyPayment;

	@FindBy(how = How.CSS, using = ".pay-button.enter-details-if-needed")
	public static WebElement payButton;

	@FindBy(how = How.XPATH, using = " //h2[@class=\"modal-title\"]")
	public static WebElement upgradeVerifyTitle;

	@FindBy(how = How.CSS, using = "[placeholder=\"Address line 1\"]")
	public static WebElement addressLineOneInputField;

	@FindBy(how = How.CSS, using = "[name=\"city\"]")
	public static WebElement cityInputField;

	@FindBy(how = How.CSS, using = "[name=\"state\"]")
	public static WebElement stateInputField;

	@FindBy(how = How.CSS, using = "[name=\"postCode\"]")
	public static WebElement zipCodeInputField;

	@FindBy(how = How.CSS, using = "[name=\"country\"]")
	public static WebElement countryDropDown;

	@FindBy(how = How.XPATH, using = "//button[@class=\"btn btn-primary pay-button submit-details-button\"]")
	public static WebElement secondPayButton;

	@FindBy(how = How.CSS, using = ".box-PLAN_V5_UP_ENGAGE")
	public static WebElement selectEngage;

	@FindBy(how = How.CSS, using = ".box-PLAN_V5_UP_MANAGE")
	public static WebElement managePlanField;

	@FindBy(how = How.XPATH, using = "(//a[contains(text(),'Admin Panel')])[2]")
	public static WebElement adminPanelButton;
	
	@FindBy(how = How.CSS, using = "div > div.help-center__wrapper > a")
	public static WebElement tooltipButton;

	@FindBy(how = How.CSS, using = ".quick-run-button.dropdown-toggle")
	public static WebElement runLinkButton;

	@FindBy(how = How.CSS, using = ".dropdown-menu > a:nth-child(3)")
	public static WebElement adminPannelButton;
	
	@FindBy(how = How.CSS, using = "div > div.passcode > span")
	public static WebElement capturePasscode;

	@FindBy(how = How.CSS, using = "[placeholder='Enter Event Passcode']")
	public static WebElement passcodeField;

	@FindBy(how = How.CSS, using = "div.passcode-entry-arrow > div")
	public static WebElement arrowButton;
	
	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Ongoing pigeonhole')]")
	public static WebElement ongoingPigeonhole;
	
	@FindBy(how = How.XPATH, using = "(//div[@class='link-content'])[4]")
	public static WebElement moreSettingsButton;
	
	@FindBy(how = How.CSS, using = "a[href$=\"agenda\"]:nth-child(1)")
	public static  WebElement agendaButton;

	// Page Commands section
	public void accessAWAFromRunLinks() throws Throwable {

		GenericMethods.sychronizationinterval();
		questionMark.click();
		questionMark.click();
		GenericMethods.sychronizationinterval();
		runLinksButton.click();
		AWA_Link.click();
	}
	
	public void accessAdminPanelFromRunLinks() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		runLinksButton.click();
		AdminPanel_Link.click();
		
	}

	public void clickOnUpgradePigeonhole() throws Throwable {

		GenericMethods.sychronizationinterval();
		upgradeLink.click();
	}

	public void selectCaptivatePigeonhole() throws Throwable {

		selectCaptivate.click();
		GenericMethods.sychronizationinterval();
		payButton.click();
		Thread.sleep(4000); //Required more wait
	}

	public void upgradePaymentDetails(String addressLine, String city, String state, String zipCode, String country)
			throws Throwable {

		addressLineOneInputField.sendKeys(addressLine);
		GenericMethods.sychronizationinterval();
		cityInputField.sendKeys(city);
		stateInputField.sendKeys(state);
		zipCodeInputField.sendKeys(zipCode);
		GenericMethods.sychronizationinterval();
		Select countryName = new Select(countryDropDown);
		countryName.selectByVisibleText(country);
		Thread.sleep(4000); //Required more wait
	}

	public void clickPayButton() throws Throwable {

		JavascriptExecutor executor = (JavascriptExecutor) driver;
		executor.executeScript("arguments[0].click();", secondPayButton);
	}

	public void upgradeEngagePigeonhole() throws Throwable {

		selectEngage.click();
		GenericMethods.sychronizationinterval();
		payButton.click();
		Thread.sleep(4000); //Required more wait
	}

	public void upgradeManagePigeonhole() throws Throwable {

		managePlanField.click();
		GenericMethods.sychronizationinterval();
		payButton.click();
		Thread.sleep(4000); //Required more wait
	}

	public void clickOnAdminPanel() {

		adminPanelButton.click();
	}
	
public void clickOnToolTip() throws Throwable {
		
		tooltipButton.click();
		GenericMethods.sychronizationinterval();
		tooltipButton.click();
	}

	public void clickOnRunLinkButton() {
		
		runLinkButton.click();
	}

	public void clickOnAdminPannelButton() {
		
		adminPannelButton.click();
	}
	
	public void openNewTab() {
		
		String newTab = "window.open('https://staging-app.pigeonlab.tech','_blank');";
		((JavascriptExecutor) driver).executeScript(newTab);
	}

	public void enterPasscode(String passcode) throws Throwable {
		
		passcodeField.clear();
		GenericMethods.sychronizationinterval();
		passcodeField.sendKeys(passcode);
	}

	public void clickOnArrow() throws Throwable {
		
		arrowButton.click();
		GenericMethods.sychronizationinterval();
	}
	
	public void clickOnMoreSettingsButton() {
		
		moreSettingsButton.click();
	}
	
	public void clickOnAgenda() {
		
		agendaButton.click();
	}
}
