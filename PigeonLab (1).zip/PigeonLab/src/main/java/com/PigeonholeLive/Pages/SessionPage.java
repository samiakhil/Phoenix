package com.PigeonholeLive.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class SessionPage extends GenericMethods {

	// Page Elements section
	@FindBy(how = How.CSS, using = ".confirmation-btn")
	public static WebElement gotItButton;

	@FindBy(how = How.CSS, using = ".add-session-btn")
	public static WebElement addSessionButton;

	@FindBy(how = How.CSS, using = "[name='name']")
	public static WebElement sessionNameInput;

	@FindBy(how = How.CSS, using = ".btn-add-poll-qn")
	public static WebElement addQuestionButton;

	@FindBy(how = How.CSS, using = ".poll-qn-field")
	public static WebElement pollQuestionInput;

	@FindBy(how = How.CSS, using = ".btn-save-poll-qn")
	public static WebElement saveButton;

	@FindBy(how = How.CSS, using = "[class='notifications top-right']")
	public static WebElement toastMessageNotification;

	@FindBy(how = How.CSS, using = "[class='main-text']")
	public static WebElement questionTextField;

	@FindBy(how = How.CSS, using = "[class='btn btn-secondary dropdown-toggle']")
	public static WebElement downArrowButton;

	@FindBy(how = How.CSS, using = "[class='dropdown-item duplicate-poll-qn-button ']")
	public static WebElement duplicateButton;

	@FindBy(how = How.XPATH, using = "(//div[@class='main-text'])[2]")
	public static WebElement DuplicateQuestionText;

	@FindBy(how = How.CSS, using = "[name='pollAllowComments']")
	public static WebElement CommentsCheckField;

	@FindBy(how = How.XPATH, using = "(//button[@data-toggle='dropdown'])[2]")
	public static WebElement downArrowButtonTwo;

	@FindBy(how = How.XPATH, using = "(//button[@class='dropdown-item danger delete-poll-qn-button'])[2]")
	public static WebElement deleteButton;

	@FindBy(how = How.CSS, using = "[class='modal-content ']")
	public static WebElement popUpAlertMessage;

	@FindBy(how = How.CSS, using = "[class='modal-affirmative-button btn btn-primary']")
	public static WebElement popUpDeleteButton;

	@FindBy(how = How.CSS, using = "[class='separate expandable-action']")
	public static WebElement advanceCustomisationHeader;

	@FindBy(how = How.CSS, using = "[name='labelText']")
	public static WebElement sessionLableField;

	@FindBy(how = How.CSS, using = "[name='buttonText']")
	public static WebElement buttonTextField;

	@FindBy(how = How.CSS, using = "[name='pollPreMessage']")
	public static WebElement prePollMessageField;

	@FindBy(how = How.CSS, using = "[class='btn btn-primary btn-save-session']")
	public static WebElement createTemplateButtonTwo;

	@FindBy(how = How.CSS, using = "[class='template-name']")
	public static WebElement templateSessionTextField;

	@FindBy(how = How.CSS, using = "[name='name']")
	public static WebElement sessionNameField;

	@FindBy(how = How.XPATH, using = "//span[contains(text(),'description')]")
	public static WebElement descriptionLink;

	@FindBy(how = How.CSS, using = "[name='description']")
	public static WebElement descriptionField;

	@FindBy(how = How.CSS, using = "[data-field='location']")
	public static WebElement locationLink;

	@FindBy(how = How.CSS, using = "[name='location']")
	public static WebElement locationField;

	@FindBy(how = How.CSS, using = "[class='modal-title edit-poll-qn-title']")
	public static WebElement popUpTittleField;

	@FindBy(how = How.CSS, using = "[name='question']")
	public static WebElement pollQuestionField;

	@FindBy(how = How.CSS, using = "[id='poll_option_-1']")
	public static WebElement optionFieldOne;

	@FindBy(how = How.CSS, using = "[id='poll_option_-2']")
	public static WebElement optionFieldTwo;

	@FindBy(how = How.CSS, using = "[class='workspace-tooltip__dismiss']")
	public static WebElement tooltipGotItButton;

	@FindBy(how = How.CSS, using = "[class='breadcrumb']")
	public static WebElement headerText;

	@FindBy(how = How.CSS, using = "[data-maxlength='12']")
	public static WebElement tagsFiled;

	@FindBy(how = How.CSS, using = "[class$='btn-save-session']")
	public static WebElement addQAButton;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Poll: Open-ended')]")
	public static WebElement pollOpenEndedButton;

	@FindBy(how = How.CSS, using = "[name='pollQuestion']")
	public static WebElement questionFiled;

	@FindBy(how = How.CSS, using = "[class='btn btn-primary btn-save-session']")
	public static WebElement addOpenEndedPollButton;

	@FindBy(how = How.XPATH, using = "//div[contains(text(),'Poll: Multiple choice')]")
	public static WebElement pollMultipleChoiceButton;

	@FindBy(how = How.CSS, using = ".modal-affirmative-button")
	public static WebElement previousSessionButton;

	@FindBy(how = How.CSS, using = ".box-poll_quiz")
	public static WebElement clickOnPollQuiz;

	@FindBy(how = How.XPATH, using = "//textarea[@name='name']")
	public static WebElement sessionNameFieldForAudience;

	@FindBy(how = How.CSS, using = ".btn-add-poll-qn")
	public static WebElement clickAddQuestionButton;

	@FindBy(how = How.XPATH, using = "(//input[contains(@id,'poll_option')])[1]")
	public static WebElement answerOptionFirstField;

	@FindBy(how = How.XPATH, using = "(//input[contains(@id,'poll_option')])[3]")
	public static WebElement answerOptionSecondField;

	@FindBy(how = How.XPATH, using = "//div[@data-id='-1']//span[text()='Mark as correct']")
	public static WebElement clickOnFirstOptionMarkAsCorrect;

	@FindBy(how = How.CSS, using = ".btn-save-poll-qn")
	public static WebElement clickOnSaveButton;

	@FindBy(how = How.XPATH, using = "//span[text()='Audience pace']")
	public static WebElement audiencePace;

	@FindBy(how = How.CSS, using = ".custom-session-label")
	public static WebElement sessionLabelField;

	@FindBy(how = How.CSS, using = ".custom-button-text")
	public static WebElement ButtonTextField;

	@FindBy(how = How.CSS, using = ".btn-save-session")
	public static WebElement clickOnAddQuiz;

	@FindBy(how = How.XPATH, using = "//select[@name='timerDuration']")
	public static WebElement presenterPace;

	@FindBy(how = How.XPATH, using = "(//div[@class='link-content']/parent::a)[2]")
	public static WebElement clickOnAgendaButton;

	@FindBy(how = How.XPATH, using = "(//div[@class=\"session-item-content\"]//following-sibling::div//div//a//span[1])[1]")
	public static WebElement clickOnMCQEditButton;

	@FindBy(how = How.XPATH, using = "//div[@class=\"alert alert-danger\"]")
	public static WebElement errorMessageText;

	@FindBy(how = How.CSS, using = ".btn-edit-poll-qn")
	public static WebElement editPollQuestion;

	@FindBy(how = How.XPATH, using = "(//div[@class=\"input-group existing-poll-option\"]/child::div/child::span)[1]")
	public static WebElement markOptionOneAsCorrect;

	@FindBy(how = How.CSS, using = ".btn-save-poll-qn")
	public static WebElement saveQuiz;

	@FindBy(how = How.XPATH, using = "//button[@data-target=\".session-poll-qn-modal\"]/child::span")
	public static WebElement addQuestionLocked;

	@FindBy(how = How.XPATH, using = "//td[@class=\"addons-modal purchase-form clearfix\"]/h2[@class=\"modal-title\"]")
	public static WebElement upgradePigeonHoleVerifyTitle;

	@FindBy(how = How.XPATH, using = "//span[@class=\"box-radio-content box-dummy\"]")
	public static WebElement clickOnRegularBox;

	@FindBy(how = How.XPATH, using = "//input[@name=\"buttonUrl\"]")
	public static WebElement advanceCustomizationButtonLink;

	@FindBy(how = How.XPATH, using = "//input[@name=\"buttonText\"]")
	public static WebElement advanceCustomizeButtonText;

	@FindBy(how = How.CSS, using = ".custom-button-text")
	public static WebElement advanceCustomizationVerifyText; 

	@FindBy(how = How.CSS, using = ".box-survey")
	public static WebElement clickOnSurveyBox;

	@FindBy(how = How.CSS, using = "[name=\"name\"]")
	public static WebElement surveySessionName;

	@FindBy(how = How.CSS, using = "[data-field=\"description\"]")
	public static WebElement clickOnDescriptionLink;

	@FindBy(how = How.CSS, using = ".btn-add-survey.hide-if-archived")
	public static WebElement clickOnAddQuestion;

	@FindBy(how = How.CSS, using = ".add-survey-title")
	public static WebElement surveyVerifyTitle; 

	@FindBy(how = How.XPATH, using = "(//div[@class=\"validation-container\"]/div/div/input)[8]")
	public static WebElement addSurveyQuestionInputField;

	@FindBy(how = How.CSS, using = "#survey-option-input")
	public static WebElement surveyOptionsInputField;

	@FindBy(how = How.CSS, using = ".btn-save-survey")
	public static WebElement clickOnSaveOptionButton;

	@FindBy(how = How.XPATH, using = "//select[@id=\"surveyType\"]")
	public static WebElement typeOpenText;

	@FindBy(how = How.CSS, using = "[name=\"surveyQuestion\"]")
	public static WebElement addSurveyQuestionTwoInput;

	@FindBy(how = How.CSS, using = ".session-survey__count")
	public static WebElement surveyQuestionsVerifyCount; 

	@FindBy(how = How.CSS, using = ".custom-session-label")
	public static WebElement sessionLabelVerifyText; 

	@FindBy(how = How.CSS, using = ".box-poll_wordcloud")
	public static WebElement clickOnWordCloud;

	@FindBy(how = How.XPATH, using = "//textarea[@name=\"description\"]")
	public static WebElement descriptionLinkField;

	@FindBy(how = How.XPATH, using = "//span[@data-field=\"location\"]")
	public static WebElement clickLocationLink;

	@FindBy(how = How.CSS, using = ".poll-question")
	public static WebElement pollQuestion;

	@FindBy(how = How.CSS, using = ".btn-save-session")
	public static WebElement savePollQuestion;

	@FindBy(how = How.CSS, using = "[class='tab active']")
	public static WebElement sessionTab;
	
	@FindBy(how = How.XPATH, using = "(//span[@class='hide-if-archived'])[1]")
	public static WebElement EditButton;
	
	@FindBy(how = How.CSS, using = "[class='poll-settings__title']")
	public static WebElement pollQuestionTittled;
	
	@FindBy(how = How.XPATH, using ="//div//div//button[@class='btn btn-secondary btn-add-poll-qn locked basic-plan-limited open-addon-shop-button']")
	public static WebElement addQuestionButtonOne;
	
	@FindBy(how = How.CSS, using = "[class='modal-title']")
	public static WebElement upgradingThePlanPopUp;
	
	// Page Commands section
	public void addNewSession(String sessionName) throws Throwable {

		GenericMethods.sychronizationinterval();
		clickOnPollQuiz.click();
		sessionNameField.sendKeys(sessionName);
	}

	public void addQuestion(String question, String firstOption, String secondOption) throws Throwable {

		GenericMethods.sychronizationinterval();
		Thread.sleep(5000);// Synchronization required
		clickAddQuestionButton.click();
		GenericMethods.sychronizationinterval();
		pollQuestionInput.sendKeys(question);
		answerOptionFirstField.sendKeys(firstOption);
		GenericMethods.sychronizationinterval();
		answerOptionSecondField.sendKeys(secondOption);
		GenericMethods.sychronizationinterval();
		clickOnFirstOptionMarkAsCorrect.click();
		GenericMethods.sychronizationinterval();
		clickOnSaveButton.click();
		GenericMethods.sychronizationinterval();

	}

	public void audiencePeace(String sessionLabel, String buttonText) throws Throwable {

		GenericMethods.sychronizationinterval();
		audiencePace.click();
		addAdvanceCustomisation(sessionLabel, buttonText);
	}

	public void submitQuiz() {

		clickOnAddQuiz.click();

	}

	public void addPresenterPace() throws Throwable {

		Select value = new Select(presenterPace);
		value.selectByIndex(5);
		GenericMethods.sychronizationinterval();
		clickOnAddQuiz.click();
	}

	public void presenterPaceOnBasicPlan() throws Throwable {

		GenericMethods.sychronizationinterval();
		clickOnAgendaButton.click();
		clickOnMCQEditButton.click();
		GenericMethods.sychronizationinterval();
		clickOnPollQuiz.click();
	}

	public void editPollQuiz() throws Throwable {

		editPollQuestion.click();
		GenericMethods.sychronizationinterval();
		markOptionOneAsCorrect.click();
		saveQuiz.click();
		GenericMethods.sychronizationinterval();
	}

	public void clickOnLockedButton() throws Throwable {

		GenericMethods.sychronizationinterval();
		addQuestionLocked.click();
	}

	public void createSurveySession(String sessionName) throws Throwable {

		clickOnSurveyBox.click();
		surveySessionName.sendKeys(sessionName);
		clickOnDescriptionLink.click();
		GenericMethods.sychronizationinterval();
	}

	public void addQuestionButton() throws Throwable {

		GenericMethods.sychronizationinterval();
		clickOnAddQuestion.click();
	}

	public void addSurveyQuestionAndAnswer(String surveyQuestionOne, String optionOne, String optionTwo)
			throws Throwable {

		GenericMethods.sychronizationinterval();
		addSurveyQuestionInputField.click();
		addSurveyQuestionInputField.sendKeys(surveyQuestionOne);
		GenericMethods.sychronizationinterval();
		surveyOptionsInputField.click();
		surveyOptionsInputField.sendKeys(optionOne);
		surveyOptionsInputField.sendKeys(optionTwo);
		GenericMethods.sychronizationinterval();
		clickOnSaveOptionButton.click();
	}

	public void addSurveyQuestionTwo(String question) {

		Select value = new Select(typeOpenText);
		value.selectByValue("open");
		addSurveyQuestionTwoInput.click();
		addSurveyQuestionTwoInput.sendKeys(question);
		clickOnSaveOptionButton.click();
	}

	public void addSurvey() {

		clickOnAddQuiz.click();

	}

	public void createWordCloudSession(String sessionName) {

		clickOnWordCloud.click();
		sessionNameFieldForAudience.sendKeys(sessionName);

	}

	public void addWordCloudSessionQuestion(String descriptionLinkText, String questionText) {

		clickOnDescriptionLink.click();
		descriptionLinkField.sendKeys(descriptionLinkText);
		clickLocationLink.click();
		pollQuestion.sendKeys(questionText);
		savePollQuestion.click();
	}

	public void fillUpAgendaInformation(String sessionPlantText, String Description, String locationName) {
		sessionNameField.sendKeys(sessionPlantText);
		descriptionLink.click();
		GenericMethods.elementToBePresent(descriptionField);
		descriptionField.sendKeys(Description);
		clickLocationLink.click();
		GenericMethods.elementToBePresent(locationField);
		locationField.sendKeys(locationName);

	}

	public void clickOnaddaddQuestionButton() throws Throwable {

		addQuestionButton.click();
		GenericMethods.sychronizationinterval();

	}

	public void addMultipleChoiceQuestion(String question, String optionOne, String optionTwo) throws Throwable {

		pollQuestionInput.sendKeys(question);
		optionFieldOne.sendKeys(optionOne);
		optionFieldTwo.sendKeys(optionTwo);
		saveButton.click();
		GenericMethods.sychronizationinterval();
	}

	public void addDuplicateQuestion() throws Throwable {

		GenericMethods.sychronizationinterval();
		downArrowButton.click();
		GenericMethods.sychronizationinterval();
		duplicateButton.click();
	}

	public void deleteDuplicateQuestion() throws Throwable {
		downArrowButtonTwo.click();
		GenericMethods.sychronizationinterval();
		deleteButton.click();
		GenericMethods.checkIfElementExists(popUpAlertMessage);
		GenericMethods.sychronizationinterval();
		popUpDeleteButton.click();
		GenericMethods.sychronizationinterval();
	}

	public void addPrePollText(String sampleText) throws Throwable {

		prePollMessageField.sendKeys(sampleText);
		createTemplateButtonTwo.click();
	}

	public void addTags(String fruitText, String vegtableText) {
		tagsFiled.sendKeys(fruitText);
		tagsFiled.sendKeys(Keys.ENTER);
		tagsFiled.sendKeys(vegtableText);
		tagsFiled.sendKeys(Keys.ENTER);
	}

	public void addAdvanceCustomisation(String lableName, String buttonText) throws Throwable {

		GenericMethods.sychronizationinterval();
		Thread.sleep(3000); // Synchronization required
		advanceCustomisationHeader.click();
		GenericMethods.sychronizationinterval();
		sessionLableField.sendKeys(lableName);
		GenericMethods.sychronizationinterval();
		buttonTextField.sendKeys(buttonText);
	}

	public void clickOnAddQAButton() throws Throwable {

		addQAButton.click();
		GenericMethods.sychronizationinterval();
	}

	public void clickOnPollOpenEnded() {

		pollOpenEndedButton.click();
	}

	public void addPollQuestion(String question) throws Throwable {

		GenericMethods.sychronizationinterval();
		questionFiled.sendKeys(question);
	}

	public void clickOnaddOpenEndedPollButton() throws Throwable {

		addOpenEndedPollButton.click();
		GenericMethods.sychronizationinterval();
	}

	public void clickOnpollMultpleChoicButton() {

		pollMultipleChoiceButton.click();
	}

	public void addingSessionName(String sessionName) {

		sessionNameField.sendKeys(sessionName);
	}

public void clickOnEditButton() {
		
		EditButton.click();
	}
	
	public void addingFiveMCPQuestions(String pollQuestion, String optionOne, String optionTwo) throws Throwable {
		
		for(int i =1 ; i<=4 ; i++) {
			clickOnaddaddQuestionButton();
			GenericMethods.sychronizationinterval();
			addMultipleChoiceQuestion(pollQuestion, optionOne, optionTwo);
			WebElement addedPollQuestion = driver.findElement(By.xpath("(//div[@class='main-text'])"+ "["+i+ "+" +1+ "]"));
			GenericMethods.checkIfElementExists(addedPollQuestion);
			GenericMethods.sychronizationinterval();
		}
		Actions action = new Actions(driver);
		action.moveToElement(addQuestionButtonOne).build().perform();
		GenericMethods.sychronizationinterval();
		addQuestionButtonOne.click();
	}
}
