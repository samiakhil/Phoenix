package com.PigeonholeLive.Pages;


import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class SecurityPage extends GenericMethods {

	// Page Elements section
	@FindBy(how = How.XPATH, using = "//*[@name='ipWhitelist']")
	public static WebElement ipAddressTextbox;

	@FindBy(how = How.XPATH, using = "(//div/button[2])[4]")
	public static WebElement saveButton;

	@FindBy(how = How.CSS, using = ".header-nav-button.header-nav-button-pigeonholes")
	public static WebElement pigeonholesButton;

	@FindBy(how = How.CSS, using = "div > div.help-center__wrapper > a")
	public static WebElement toolTipButton;

	@FindBy(how = How.XPATH, using = "(//div[2]/div/div[1])[5]")
	public static WebElement runLinks;

	@FindBy(how = How.XPATH, using = "(//a[@class='dropdown-item'])[1]")
	public static WebElement audienceWebApp;

	@FindBy(how = How.CSS, using = "[class$='p-indicator']")//[class$='p-indicator'](//div[1]/label/span)[1]
	public static WebElement ipWhiteList;

	@FindBy(how = How.XPATH, using = "(//div[2]/button[2])[1]")
	public static WebElement saveIP;
	
	@FindBy(how = How.XPATH, using = "//div/div[3]/div[4]")
	public static WebElement errorMessage;

	// Page Commands section
	public void enterIpAddress(String ipAddress) throws Throwable {

		ipAddressTextbox.clear();
		ipAddressTextbox.sendKeys(ipAddress);
	}

	public void clickOnSaveButton() throws Throwable {
		
		saveButton.click();
		GenericMethods.sychronizationinterval();
		driver.navigate().refresh();
	}

	public void clickOnPigeonholesButton() {
		
		pigeonholesButton.click();
	}
	
	public void clickOnToolTipButton() {
		
		toolTipButton.click();
		toolTipButton.click();	
	}
	
	public void clickOnRunLinks() throws Throwable {
	
		runLinks.click();
	}

	public void clickOnAudienceWebApp() throws Throwable {
	
		audienceWebApp.click();
	}

	public void clickOnIPWhiteList() throws Throwable {
		
		driver.navigate().refresh();
		ipWhiteList.click();
	}

	public void clickOnSaveIP() {
		
		saveIP.click();
	}
}
