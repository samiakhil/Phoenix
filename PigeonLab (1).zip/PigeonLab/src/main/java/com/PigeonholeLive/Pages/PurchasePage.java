package com.PigeonholeLive.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class PurchasePage {

	// Page Elements section
	@FindBy(how = How.XPATH, using = "//div//h3[contains(text(), ' 1. Select a Pigeonhole')]")
	public static WebElement selectAPigeonHoleField;

	@FindBy(how = How.XPATH, using = "//div[@class='purchase-center-accordion__content']//div[@class='purchase-center-product-list']//div[@name='Captivate']")
	public static WebElement captivateField;

	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Next')]")
	public static WebElement nextButton;

	@FindBy(how = How.ID, using = "address14")
	public static WebElement addressField;

	@FindBy(how = How.ID, using = "city6")
	public static WebElement cityField;

	@FindBy(how = How.ID, using = "state7")
	public static WebElement stateField;

	@FindBy(how = How.ID, using = "postCode8")
	public static WebElement postalCodeField;

	@FindBy(how = How.ID, using = "country9")
	public static WebElement countryField;

	@FindBy(how = How.XPATH, using = "//button[contains(text(),'Pay')]")
	public static WebElement payButton;

	@FindBy(how = How.XPATH, using = "//div[@class=\"purchase-center-summary__header\"]//div[@class=\"purchase-center-summary__container\"]")
	public static WebElement priceDropdownIcon;

	@FindBy(how = How.XPATH, using = "//a[text()='Add promo code?']")
	public static WebElement promoCodeLink;

	@FindBy(how = How.XPATH, using = "//input[@name='voucherCode']")
	public static WebElement promoCodeField;

	@FindBy(how = How.XPATH, using = "//button[contains(text(), 'Apply')]")
	public static WebElement applyButton;

	@FindBy(how = How.XPATH, using = "//div[@class='form-control StripeElement empty']//div[@class='__PrivateStripeElement']//input[@class='__PrivateStripeElement-input']")
	public static WebElement cardNumberField;

	@FindBy(how = How.XPATH, using = "//input[@class=\"form-control touched pristine\"]")
	public static WebElement nameField;

	@FindBy(how = How.XPATH, using = "//div[@class=\"form-group row\"][3]//input")
	public static WebElement dateField;

	@FindBy(how = How.XPATH, using = "//div[@class=\"form-group row\"][4]//input")
	public static WebElement cvvField;

	@FindBy(how = How.XPATH, using = "//button[contains(text(), 'Submit payment')]")
	public static WebElement submitButton;

	@FindBy(how = How.XPATH, using = "//div[@class='new-pigeonhole-modal']//p[text()='Thank you for purchasing a new Pigeonhole!']")
	public static WebElement thankYouForPurchasingTextField;
	
	@FindBy(how = How.XPATH, using = "//div[@class='purchase-center-accordion__content']//div[@class='purchase-center-product-list']//div[@name='Manage']")
	public static WebElement manageField;
	
	@FindBy(how = How.XPATH, using = "//div[@name='Annual Captivate Plan']")
	public static WebElement annualCaptivateField;
	
	@FindBy(how = How.XPATH, using = "//div[@category='contract']")
	public static WebElement additionalUserField;
	
	@FindBy(how = How.XPATH, using = "//div[@class='purchase-center-number-input']//button[2]")
	public static WebElement plusSymbol;
	
	@FindBy(how = How.XPATH, using = "//div[@category='contract']")
	public static WebElement additionalUsersTwoTextField;

	@FindBy(how = How.XPATH, using = "//div[@class='purchase-center-summary__container-child']//table//tr[@class='purchase-center-summary__payable']")
	public static WebElement totalPaybleamountField;
	
	@FindBy(how = How.XPATH, using = "//div[@class=\"modal-content \"]")
	public static WebElement teamWorkSpacePopup;

	@FindBy(how = How.XPATH, using = "//div[@class=\"setup-workspace-content--form\"]//input")
	public static WebElement teamWorkSpaceNameField;

	@FindBy(how = How.XPATH, using = "//button[text() ='Add Later']")
	public static WebElement addLaterButton;
	
	@FindBy(how = How.XPATH, using = "//button[text() ='Create Workspace']")
	public static WebElement createWorkspaceButton;

	@FindBy(how = How.XPATH, using = "//div[@class=\"pigeonhole-listview__wrapper\"]//h1[@class=\"pigeonhole-listview__title\"]")
	public static WebElement teamTitle;
	
	@FindBy(how = How.XPATH, using = "//div[@name='Annual Manage Plan']")
	public static WebElement annualManageField;
	
	@FindBy(how = How.CSS, using = ".submit-details-button")
	public static WebElement secondPayButton;
	
	@FindBy(how = How.XPATH, using = "//div[@class=\"new-pigeonhole-modal\"]/p[text()='Congratulations, your Pigeonhole has been upgraded!']")
	public static WebElement congratulationsVerifyMessage;
	
	@FindBy(how = How.XPATH, using = "//div[@class=\"new-pigeonhole-modal\"]/button[text()='Continue']")
	public static WebElement continueButton;

	// Page Commands 
	public void selectCaptivateProductItem() throws Throwable {

		GenericMethods.sychronizationinterval();
		captivateField.click();
		GenericMethods.sychronizationinterval();
		nextButton.click();
	}

	public void selectEngageProductItem() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		nextButton.click();
	}

	public void fillBillingDetails(String address, String city, String state, String zipCode, String country)
			throws Throwable {

		addressField.sendKeys(address);
		cityField.sendKeys(city);
		stateField.sendKeys(state);
		postalCodeField.sendKeys(zipCode);
		GenericMethods.sychronizationinterval();
		Select countryName = new Select(countryField);
		countryName.selectByVisibleText(country);

	}
	
	public void addPromoCode(String promocode) throws Throwable {

		priceDropdownIcon.click();
		GenericMethods.sychronizationinterval();
		promoCodeLink.click();
		GenericMethods.sychronizationinterval();
		promoCodeField.sendKeys(promocode);
		applyButton.click();

	}

	public void clickPayButton() throws Throwable {

		GenericMethods.sychronizationinterval();
		payButton.click();
		GenericMethods.sychronizationinterval();
	}

	public void fillPaymentDetails(String cardNumber, String CardHolderName, String expireDate, String cvv)
			throws Throwable {

		GenericMethods.sychronizationinterval();
		cardNumberField.sendKeys(cardNumber);
		nameField.sendKeys(CardHolderName);
		GenericMethods.sychronizationinterval();
		dateField.sendKeys(expireDate);
		GenericMethods.sychronizationinterval();
		cvvField.sendKeys(cvv);
			
	}
	
	public void submitPayment() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		submitButton.click();	
	}
	
	public void submitPaymentDetails() throws Throwable {
		
		secondPayButton.click();
		GenericMethods.sychronizationinterval();
	}
	
	public void selectAnnualCaptivate() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		annualCaptivateField.click();
	}
	
	public void addAdditinoalUsers() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		plusSymbol.click();
		GenericMethods.sychronizationinterval();
		plusSymbol.click();
		GenericMethods.sychronizationinterval();
		priceDropdownIcon.click();
	}
	
	public void clickOnNextButton() throws Throwable
	{
		nextButton.click();
	}
	
	public void clickOnPriceDropDown()
	{
		priceDropdownIcon.click();
	}
	
	public void createTeamWorkSpace(String workSpaceName) throws Throwable
	{
		GenericMethods.sychronizationinterval();
		teamWorkSpaceNameField.sendKeys(workSpaceName);
		GenericMethods.sychronizationinterval();
		createWorkspaceButton.click();
		GenericMethods.sychronizationinterval();
		addLaterButton.click();
	}
	
	public void selectAnnualEngage() throws Throwable
	{
		GenericMethods.sychronizationinterval();
	}
	
	public void selectAnnualManage() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		annualManageField.click();
	}
	
	public void selectManageProductItem() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		manageField.click();
		GenericMethods.sychronizationinterval();
		nextButton.click();
	}
	
	public void continuePopUp() {
		
		continueButton.click();	
	}
	
}
