package com.PigeonholeLive.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class ProfilePage extends GenericMethods {

	// Page Elements section
	@FindBy(how = How.XPATH, using = "//h1[contains(text(),'Team Profile')]")
	public static WebElement teamProfile;
	
	@FindBy(how = How.CSS, using = "li:nth-child(5) > a")
	public static WebElement securityButton;
	
	// Page Commands section
	public void clickOnSecurityButton() {
		
		securityButton.click();
	}

}
