package com.PigeonholeLive.Pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;

public class AdminPanelPage extends GenericMethods {

	// Page Elements section
	@FindBy(how = How.XPATH, using = "//div[@class='panel-type']/div[2]")
	public static WebElement adminPanelVerifyTitle;
	
	@FindBy(how = How.XPATH, using = "(//div[contains(text(), 'sacrificing quality?')]/../../../..//div[contains(text(),'Dismiss')])[1]")
	public static WebElement dissmissButton;

	@FindBy(how = How.XPATH, using = "(//div[@class=\"nav-list-item \"])[3]/a/div[text()=\"Dismissed\"]")
	public static WebElement dismissLabel;

	@FindBy(how = How.XPATH, using = "(//span[@class=\"icon icon-more-options\"])[1]")
	public static WebElement moreOptions;

	@FindBy(how = How.XPATH, using = "(//div[@class=\"more-options-item admin-icon-button question-hidden-button \"]/div[@class=\"hide-text\"])[2]")
	public static WebElement hideOption;

	@FindBy(how = How.XPATH, using = "(//div[@class=\"allow-user-select question-text-line\"]/div[1])[1]")
	public static WebElement hideVerifyQuestion;

	@FindBy(how = How.XPATH, using = "(//div[@class=\"more-options-item admin-icon-button question-edit-button  \"]/div[@class=\"edit-text\"])[1]")
	public static WebElement editOption;

	@FindBy(how = How.CSS, using = ".modal-header.allow-user-select")
	public static WebElement editQuestionVerifyTitle;

	@FindBy(how = How.CSS, using = "[name=\"message-input\"]")
	public static WebElement editQuestionField;

	@FindBy(how = How.CSS, using = ".button-submit")
	public static WebElement saveQuestionButton;

	@FindBy(how = How.XPATH, using = "//div[@class=\"content\"]/span[@class=\"edited-question\"]")
	public static WebElement editedVerifyText;

	@FindBy(how = How.XPATH, using = "(//div[@class=\"active-text\"])[1]")
	public static WebElement activeButton;

	@FindBy(how = How.XPATH, using = "(//span[@class=\"normal-icon icon-active\"])[1]")
	public static WebElement activeVerifyColour;

	@FindBy(how = How.XPATH, using = "(//span[@class=\"normal-icon icon-answered\"])[1]")
	public static WebElement answeredButton;
	
	@FindBy(how = How.XPATH, using = "//a//div[@class='sl-name']")
	public static WebElement matchSessionName;
	
	@FindBy(how = How.XPATH, using = "//span[2]//div[1]//span")
	public static WebElement addAnswerButton;
	
	@FindBy(how = How.CSS, using = ".message-input")
	public static WebElement answerTextbox;
	
	@FindBy(how = How.CSS, using = ".button-submit")
	public static WebElement addAnswerButtonTwo;
	
	@FindBy(how = How.XPATH, using = "//ul//div[2]/div[2]")
	public static WebElement unisexProfileImage;
	
	@FindBy(how = How.XPATH, using = "(//span[contains(text(),\"Technology and Corporate Communications\")])[4]")
	public static WebElement eventName;

	@FindBy(how = How.CSS, using = "[data-routename=\"question_awaiting\"]")
	public static WebElement pendingLabel;

	@FindBy(how = How.XPATH, using = "//div[contains(text(), 'sacrificing quality?')]")
	public static WebElement pendingQuestion;

	@FindBy(how = How.XPATH, using = "//div[contains(text(), 'sacrificing quality?')]")
	public static WebElement approvedQuestion;

	@FindBy(how = How.XPATH, using = "(//div[contains(text(), 'sacrificing quality?')]/../../../..//div[contains(text(),'Allow')])[1]")
	public static WebElement allowButton;

	@FindBy(how = How.XPATH, using = "(//div[text()='Allowed'])[1]")
	public static WebElement allowedLabel;


	// Page Commands section
	public void clickOnEvent() throws Throwable {

		eventName.click();
	}

	public void selectPendingLabel() throws Throwable {

		pendingLabel.click();
	}

	public void clickOnDissmissOption() throws Throwable {

		GenericMethods.sychronizationinterval();
		dissmissButton.click();
		dismissLabel.click();
	}

	public void selectAllowedLabel() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		allowButton.click();
		GenericMethods.sychronizationinterval();
		allowedLabel.click();
	}

	public void adminPanelActions() throws Throwable {

		GenericMethods.sychronizationinterval();
		Actions actions = new Actions(driver);
		actions.moveToElement(moreOptions).click().perform();
		hideOption.click();
	}

	public void editQuestion() {

		editOption.click();
	}

	public void editQuestionText(String question) {

		editQuestionField.sendKeys(question);
		saveQuestionButton.click();
	}

	public void clickOnActive() {

		activeButton.click();
	}

	public void clickOnOrangeActive() {

		activeVerifyColour.click();
	}

	public void clickOnAnsweredButton() {

		answeredButton.click();
	}

	public void clickOnOrangeAnswered() {

		answeredButton.click();
	}
	
	public void questionAndAnswers() throws Throwable {

		driver.manage().window().maximize();
		eventName.click();
		GenericMethods.sychronizationinterval();
		pendingLabel.click();
	}

	public void clickOnAllowButton() {

		allowButton.click();
	}

	public void clickOnAllowedLabel() {

		allowedLabel.click();
	}
	
	public void clickOnVerifiedSession() {
		
		matchSessionName.click();
		GenericMethods.maximizeWindow();
		
	}
	
	public void clickOnAddAnswer() throws Throwable {
		
		addAnswerButton.click();
	}
	
	public void enterAnswer(String answer) {
		
		answerTextbox.sendKeys(answer);
	}
	
	public void clickOnAddAnswerButton() {
		
		addAnswerButtonTwo.click();
	}
}
