package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.PurchasePage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class UpgradeBasicToCaptivatePigeonhole_Test {

	// Objects Declaration Section

	public DashboardPage dashboardPage;
	public RunEventsPage runEventsPage;
	public PurchasePage purchasePage;
	public AgendaPage agendaPage;
	public TestDataGenerator randomDataGenerator;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	String url = "basicPlanUrl";
	public String countryName ="Singapore";
	public String expectedTitle = "Billing Information";
	public String expectedPaymentValue = "928.00  USD";
	public String cardNumber = " 4111111111111111";
	public String expireDate = " 10/30";
	public String cvv = " 123";

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(UpgradeBasicToCaptivatePigeonhole_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		runEventsPage = new RunEventsPage();
		purchasePage = new PurchasePage();
		agendaPage = new AgendaPage();
		randomDataGenerator = new TestDataGenerator();
		elementsInitialization = new PageElementsInitialization();
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.runEventsPageObjectory();
		elementsInitialization.agendaPageObjectory();
		elementsInitialization.purchasePageObjectory();
	}

	// select event name : 2018 Asia Leadership Conference
	// select upgrade link text
	@Test(priority = 1, description = "select event")
	public void upgradeToCaptivate() throws Throwable {

		GenericMethods.checkIfButtonExistsAndClick(DashboardPage.gotItButton);
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnEvent();
		Logs.debug("Successfully Selected 2018 Asia Leadership Conference");
		GenericMethods.sychronizationinterval();
		runEventsPage.clickOnUpgradePigeonhole();
		Logs.debug("Successfully Selected Upgrade Link Text");
		GenericMethods.sychronizationinterval();
	}

	// Select captivate pigeonHole
	// See the Total Payable as "928.00 USD"
	@Test(priority = 2, description = "Upgrade to captivate")
	public void selectCaptivate() throws Throwable {

		runEventsPage.selectCaptivatePigeonhole();
		Logs.debug("Successfully Selected captivate pigeonHole");
		GenericMethods.sychronizationinterval();
		String obtainedUpgradeTitle = RunEventsPage.upgradeVerifyTitle.getText();
		Assert.assertEquals(obtainedUpgradeTitle, expectedTitle, "Obtained title did not match");
		Logs.debug("Billing Information Title was found");
		String obtainedPaymentValue = RunEventsPage.totalVerifyPayment.getText();
		Assert.assertEquals(obtainedPaymentValue, expectedPaymentValue, "Obtained value did not match");
		Logs.debug("Total Payable as 928.00 USD was found");
		GenericMethods.sychronizationinterval();
	}

	// Add Billing Details
	// Click on the pay
	@Test(priority = 3, description = "Add Billing Details")
	public void EnterBillingInformation() throws Throwable {
		GenericMethods.sychronizationinterval();
		runEventsPage.upgradePaymentDetails(TestDataGenerator.randomAddress, TestDataGenerator.randomCity,
				TestDataGenerator.randomState, TestDataGenerator.randomZipCode, countryName);
		Logs.debug("Successfully filled the Billing deatails ");
		runEventsPage.clickPayButton();
	}

	// Add the Credit Card Payment Details
	// Able to see "Congratulations, your Pigeonhole has been upgraded! "
	@Test(priority = 4, description = "Credit Card Payment")
	public void EnterPaymentDetais() throws Throwable {
		GenericMethods.sychronizationinterval();
		purchasePage.fillPaymentDetails(cardNumber, TestDataGenerator.randomName, expireDate, cvv);
		purchasePage.submitPaymentDetails();
		Logs.debug("Successfully filled the Payment deatails ");
		GenericMethods.waitForPageLoad();
		Thread.sleep(9000);// Synchronization required to display pop up
		Assert.assertTrue(GenericMethods.elementToBePresent(PurchasePage.congratulationsVerifyMessage));
		Logs.debug("Congratulations, your Pigeonhole has been upgraded!   Text was found in page");
		purchasePage.continuePopUp();
		Logs.debug("Successfully closed the congratulations, your Pigeonhole has been upgraded! pop up ");
	}

	// Go to Agenda Page.
	// Click on Add Session.
	// see an unselected checkbox: Answers
	@Test(priority = 5, description = "Answers checkbox was unselected")
	public void upgradeCaptivatePigeonHole() throws Throwable {
		
		agendaPage.selectAddSession();
		Logs.debug("Successfully clicked on the Agenda and Add Session Button ");
		Assert.assertTrue(AgendaPage.answersVerifyCheckBox.isDisplayed(), "answers check box is not visible.");
		Assert.assertTrue(!AgendaPage.answersVerifyCheckBox.isSelected(), "answers check box is not Enable.");
		Logs.debug("Successfully found Answers checkBox was unselected ");	
	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}

}
