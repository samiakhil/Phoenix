package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class TeamRedeemAPigeonhole_Test extends GenericMethods {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public AgendaPage agendaPage;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	public String url = "templateSessionUrl";
	public String eventName = TestDataGenerator.randomEventName;

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) throws Exception {

		Logs.initLogs(TeamRedeemAPigeonhole_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		agendaPage = new AgendaPage();
		elementsInitialization = new PageElementsInitialization();

		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.agendaPageObjectory();

	}

	// Click the button: Got it. Click on the three person icon
	// Click the orange button: Add Pigeonhole. click the grey plus icon
	@Test(priority = 1)
	public void teamRedem() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(DashboardPage.youHaveJoinedTeam));
		Logs.debug("You've joined the Team text was found");
		dashboardPage.clickOnGotItButtonOne();
		Logs.debug("Got It Button clicked successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnMyTeamWorkSpace();
		Logs.debug("Selected My Team Workspace Successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnAddPigeonHole();
		Logs.debug("clicked on AddPigeonhole successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnGreyPlusIcon();
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(DashboardPage.setUpEvent));
		Logs.debug("Set Up Your Event text was found");

	}

	// Set Up Your Event- enter event name click on the use random passcode and
	// click on continue.
	@Test(priority = 2)
	public void setUpYourEvent() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		dashboardPage.fillEventName(eventName);
		Logs.debug("Event name entered successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnRandomPassCode();
		Logs.debug("Clicked on random passcode successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnContinueButton();
		Logs.debug("Clicked on continue button successfully");
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(AgendaPage.redeemMessage));
		Logs.debug("Start creating a Q&A, Poll or Survey by adding a session? text was found.");
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
		
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}
}