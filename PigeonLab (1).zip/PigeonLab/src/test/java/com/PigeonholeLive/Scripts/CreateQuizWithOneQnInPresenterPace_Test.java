package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class CreateQuizWithOneQnInPresenterPace_Test {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public SessionPage sessionPage;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	String url = "createSessionUrl";
	String expectedPollBorder = "#f07424";
	public String sessionName = TestDataGenerator.randomSessionName;

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(CreateQuizWithOneQnInPresenterPace_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		sessionPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();

	}

	// Select an event 2018 Asia Leadership Conference,
	// Add new Session Type "poll: Quiz"
	@Test(priority = 1, description = "Create a session")
	public void addSession() throws Throwable {

		dashboardPage.addSession();
		Assert.assertEquals(ApplicationTittles.agendaPageTitle, GenericMethods.titleValidation(),
				"Title validation failed");
		Logs.debug("Navigated to agendaPage and contains header like 'Agenda > Sessions > New Session' ");
		GenericMethods.elementToBePresent(SessionPage.headerText);
		sessionPage.addNewSession(sessionName);
		Logs.debug("Successfully added  new Session Type poll: Quiz");
		Assert.assertEquals(expectedPollBorder, GenericMethods.getColourOfElement(SessionPage.clickOnPollQuiz));
		Logs.debug(" 1.Tick and orange outline was found");

	}

	// Add Question with Options
	// select Presenter pace with option 30s
	// Able to See the Session in the Session page
	@Test(priority = 2, description = "Create a Quiz with 1qn in presenter pace and 30s")
	public void createQuiz() throws Throwable {
		sessionPage.addQuestion(TestDataGenerator.question, TestDataGenerator.firstOption,
				TestDataGenerator.secondOption);
		Logs.debug(" Successfully added Question with options");
		sessionPage.addPresenterPace();
		Logs.debug("Successfully select Presenter pace with option 30s");
		Thread.sleep(3000); // Synchronization required to load the page
		String obtainedSessionName = GenericMethods.getTextOfElement(AgendaPage.sessionNameTextField);
		Assert.assertEquals(obtainedSessionName, sessionName, "Obtained session Name did not match");
		Logs.debug("Successfully Added Session can see in the session page");

	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}

}
