package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class CreateNewTeamTemplatesPollMCQ_Test extends GenericMethods {

	/* Objects Declaration Section */
	public DashboardPage dashboardPage;
	public SessionPage agendaPage;
	public TestDataGenerator testDataGeneratorPage;
	public PageElementsInitialization elementsInitialization;

	/* Test Input Data Section */
	String url = "templateSessionUrl";
	String sessionName = "My poll mcq session";
	String description = "My description";
	String locationName = "My location";
	String PollQuestion = "What is your favourate colour?";
	String optionOne = "RED";
	String optionTwo = "PINK";
	String lableName = "Poll";
	String buttonText = "Join Poll";
	String sampleText = TestDataGenerator.textMessage;

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(CreateNewTeamTemplatesPollMCQ_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		agendaPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();
	}

	/*
	 * Creating a new Template MultipleChoiceQuestion by adding details like
	 * AgendaInformation, MultipleChoiceQuestion
	 */
	@Test(priority = 1)
	public void addTemplatePollMCQ() throws Throwable {

		GenericMethods.sychronizationinterval();
		dashboardPage.navigatingToTeamDashboard();
		GenericMethods.sychronizationinterval();
		agendaPage.fillUpAgendaInformation(sessionName, description, locationName);
		agendaPage.clickOnaddaddQuestionButton();
		agendaPage.addMultipleChoiceQuestion(PollQuestion, optionOne, optionTwo);
		Assert.assertTrue((GenericMethods.checkIfElementExists(SessionPage.toastMessageNotification)));
		GenericMethods.elementToBePresent(SessionPage.questionFiled);
		Logs.debug("Inserted the MultipleChoice poll question");
	}

	/* Performing Duplicate and deletion operations on added Question Poll */
	@Test(priority = 2)
	public void AddAndDeleteDuplicateMCQ() throws Throwable {

		GenericMethods.sychronizationinterval();
		agendaPage.addDuplicateQuestion();
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.checkIfElementExists(SessionPage.DuplicateQuestionText));
		Assert.assertFalse(GenericMethods.elementToBeSelect(SessionPage.CommentsCheckField));
		Logs.debug("The Comments checkbox disabled under poll settings");
		agendaPage.deleteDuplicateQuestion();
	}

	/* Filling up AdvancedCustomisation details */
	@Test(priority = 3)
	public void fillAdvancedCustomisation() throws Throwable {

		GenericMethods.sychronizationinterval();
		agendaPage.addAdvanceCustomisation(lableName, buttonText);
		Logs.debug("displayed Poll and Join Poll on the Audience Web App preview");
		agendaPage.addPrePollText(sampleText);
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(sessionName, GenericMethods.getTextOfElement(SessionPage.templateSessionTextField),
				"Template session not added");
		Logs.debug("Template session name added in the sessions page");
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());

	}

}
