package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AdminPanelPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class ApproveAPendingQuestionOnAdminPanel_Test {
	
	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public RunEventsPage runEventsPage;
	public AdminPanelPage adminPanelPage;

	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	public String url = "approvePendingQuestionUrl";
	public String aprovedQuestion = "How would you describe the culture of your organisation?";
	public int adminPannel = 2;
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) throws Exception {

		Logs.initLogs(ApproveAPendingQuestionOnAdminPanel_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		runEventsPage = new RunEventsPage();
		adminPanelPage = new AdminPanelPage();
		elementsInitialization = new PageElementsInitialization();

		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.runEventsPageObjectory();
		elementsInitialization.adminPannelPageObjectory();

	}

	// Click on the Pigeonhole: 2018 Asia Leadership Conference.
	// Are you on the page: Run Your Event? (If you see a dark grey pop-up,
	// click: Got it)
	// click on the button: Run links. You should see a dropdown list, click the
	// text: Admin Panel.
	// Do you see a new page: Admin Panel ?
	@Test(priority = 1)
	public void runYourEvent() throws Throwable {
		
		dashboardPage.clickOnGotItButton();
		Logs.debug("Clicked on Got It button successfully");
		dashboardPage.clickOnEvent();
		Logs.debug("Clicked on event name successfully");
		runEventsPage.clickOnToolTip();
		Logs.debug("Clicked on toolTop successfully");
		runEventsPage.clickOnRunLinkButton();
		Logs.debug("Clicked on run links button successfully");
		runEventsPage.clickOnAdminPannelButton();
		Logs.debug("Clicked on Admin panel successfully");
		GenericMethods.switchToNewWindow(adminPannel);
		Logs.debug("switched to admin pannel successfully");

	}

	// Click on the Q&A session, click on "Pending" label.
	// Click the cross (x) next to the label
	// Click on any of the "Allow" button on the right side of the screen.
	// Click on "Allowed" label on the left of the screen under "QUESTIONS" tab.
	// Do you see the question which you have just allowed?
	@Test(priority = 2)
	public void approvePendingQuestion() throws Throwable {
		
		Logs.debug("admin pannel Title Validated successfully");
		adminPanelPage.questionAndAnswers();
		Logs.debug("Clicked on Pending label successfully");
		GenericMethods.sychronizationinterval();
		String pendingQuestion = AdminPanelPage.pendingQuestion.getText();
		Logs.debug("Noted pending question successfully");
		GenericMethods.sychronizationinterval();
		adminPanelPage.clickOnAllowButton();
		Logs.debug("Clicked on allow button successfully");
		adminPanelPage.clickOnAllowedLabel();
		Logs.debug("Clicked on allowed label successfully");
		GenericMethods.sychronizationinterval();
		String approvedQuestion = AdminPanelPage.approvedQuestion.getText();
		Assert.assertEquals(pendingQuestion, approvedQuestion);
		Logs.debug("Pending question approved successfully");
	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}
}