package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class CreateQuizWithFiveQnInPresenterPaceOnBasicPlan_Test {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public SessionPage sessionPage;
	public PageElementsInitialization elementsInitialization;
	public TestDataGenerator randomDataGenerator;

	// Test Input Data Section
	String url = "basicPlanUrl";
	String expectedPollBorder = "#f07424";
	String expectedErrorMessage = "Quiz requires a correct answer for every question. Please select a correct answer for each text-based question.";


	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(CreateQuizWithFiveQnInPresenterPaceOnBasicPlan_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		sessionPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();

	}

	// Select the event 2018 Asia, In agenda,
	// select poll quiz, check for the error
	// message. Edit already existing poll Quiz
	@Test(priority = 1, description = "selecting poll Quiz")
	public void CreatingQuizInPresenterPaceOnBasicPlan() throws Throwable {

		GenericMethods.checkIfButtonExistsAndClick(DashboardPage.gotItButton);
		dashboardPage.clickOnEvent();
		Logs.debug("Successfully Selected 2018 Asia Leadership Conference");
		sessionPage.presenterPaceOnBasicPlan();
		Logs.debug("Successfully selected Type poll: Quiz");
		Assert.assertEquals(expectedPollBorder, GenericMethods.getColourOfElement(SessionPage.clickOnPollQuiz));
		Logs.debug("Tick and orange outline was found");
		String obtainedMessage = SessionPage.errorMessageText.getText();
		Assert.assertEquals(obtainedMessage, expectedErrorMessage, "Obtained message did not match");
		Logs.debug("Successfully found error message");
		sessionPage.editPollQuiz();

	}

	// Add five questions,
	// Click on Save
	// look for the lock icon
	// Click on the button: Add question.
	@Test(priority = 2, description = "Add five questions")
	public void addPollQuestion() throws Throwable {

		GenericMethods.sychronizationinterval();
		sessionPage.addQuestion(TestDataGenerator.question, TestDataGenerator.firstOption,
				TestDataGenerator.secondOption);
		GenericMethods.sychronizationinterval();
		sessionPage.addQuestion(TestDataGenerator.question, TestDataGenerator.firstOption,
				TestDataGenerator.secondOption);
		GenericMethods.sychronizationinterval();
		sessionPage.addQuestion(TestDataGenerator.question, TestDataGenerator.firstOption,
				TestDataGenerator.secondOption);
		GenericMethods.sychronizationinterval();
		sessionPage.addQuestion(TestDataGenerator.question, TestDataGenerator.firstOption,
				TestDataGenerator.secondOption);
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(SessionPage.addQuestionLocked.isDisplayed(), "lock icon not visible.");
		Logs.debug("Successfully found lock icon");
		GenericMethods.sychronizationinterval();
		Logs.debug("Successfully five questions");
		sessionPage.clickOnLockedButton();
		GenericMethods.sychronizationinterval();
		Logs.debug("Successfully Upgrade Pigeonhole was found");
	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}

}
