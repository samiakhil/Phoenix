package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AdminPanelPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class DismissQuestionAndAllowDismissedQuestionOnAdminPanel_Test {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public RunEventsPage runEventsPage;
	public AdminPanelPage adminPanelPage;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	String url = "EditDismissUrl";
	String expectedTitle = "Admin Panel";
	int adminPanel_Page = 2;

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(DismissQuestionAndAllowDismissedQuestionOnAdminPanel_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		runEventsPage = new RunEventsPage();
		adminPanelPage = new AdminPanelPage();
		elementsInitialization = new PageElementsInitialization();
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.runEventsPageObjectory();
		elementsInitialization.adminPannelPageObjectory();
	}

	// select event name : 2018 Asia Leadership Conference
	// In Run Links Page choose Admin Panel
	@Test(priority = 1, description = "click On Admin Panel Page")
	public void selectEvent() throws Throwable {
		GenericMethods.checkIfButtonExistsAndClick(DashboardPage.gotItButton);
		dashboardPage.clickOnEvent();
		Logs.debug("Successfully Selected 2018 Asia Leadership Conference");
		GenericMethods.sychronizationinterval();
		runEventsPage.clickOnAdminPanel();
		Logs.debug("Successfully selected Admin Panel");
	}

	// Switch to Admin Panel Page
	// Verify the title
	// Click on the Q&A session
	@Test(priority = 2, description = "Admin Panel Page Actions")
	public void adminPanelActions() throws Throwable {
		GenericMethods.switchToNewWindow(adminPanel_Page);
		Logs.debug("Successfully reached to Admin Panel Page");
		GenericMethods.maximizeWindow();
		GenericMethods.sychronizationinterval();
		String obtainedTitle = AdminPanelPage.adminPanelVerifyTitle.getText();
		Assert.assertEquals(obtainedTitle, expectedTitle, "Obtained title did not match");
		Logs.debug("Admin Panel title was found");
		adminPanelPage.clickOnEvent();
		Logs.debug("Successfully clicked on Q&A session");
	}

	// Click On Pending
	// Dismiss a question by clicking on any of the "Dismiss" button
	// Click on Dismissed label on the left of the screen
	// Click on the green "Allow" button on the right side of the question
	// Click on "Allowed" label on the left of the screen
	// see the question which you have just allowed
	@Test(priority = 3, description = "Dissmiss the Question in Admin Panel")
	public void dismissQuestionInAdminPage() throws Throwable {
		GenericMethods.sychronizationinterval();
		adminPanelPage.selectPendingLabel();
		Logs.debug("Successfully clicked on pending Label");
		adminPanelPage.clickOnDissmissOption();
		Logs.debug("Successfully Dismiss a question by clicking on Dismiss option");
		adminPanelPage.selectAllowedLabel();
		Logs.debug("Successfully Allowed a question to dissmiss.");
	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}

}
