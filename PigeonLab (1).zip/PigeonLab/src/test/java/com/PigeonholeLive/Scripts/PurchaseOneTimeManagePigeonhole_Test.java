package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.PurchasePage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class PurchaseOneTimeManagePigeonhole_Test extends GenericMethods {

	
	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public PageElementsInitialization elementsInitialization;
	public PurchasePage purchasePage;
	public TestDataGenerator randomDataGenerator;
	
	//Test Inputs
	public String url = "dashboardUrl";
	public String countryName ="Singapore";
	public String promoCode="TESTING-100";
	public String cardNumber =" 4111111111111111";
	public String expireDate =" 10/30";
	public String cvv=" 123";		
	
	
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch( String browser) {
 
		Logs.initLogs(PurchaseOneTimeManagePigeonhole_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());
		
		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		elementsInitialization = new PageElementsInitialization();
		purchasePage = new PurchasePage();
		randomDataGenerator=new TestDataGenerator();

		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.adminPannelPageObjectory();
		elementsInitialization.AWAPageObjectory();
		elementsInitialization.projecterPageObjectory();
		elementsInitialization.agendaPageObjectory();
		elementsInitialization.purchasePageObjectory();	
	}
	
	//Click on the "Add Pigeonhole" dropdown
	//Next, click on option "Premium Pigeonhole".
	//Do you see a new page with the text: 1. Select a Pigeonhole?
	@Test(priority = 1)
	public void SelectPremiumPigeonHole() throws Throwable
	{
		dashboardPage.clickOnPremiumPigeonHole();
		Logs.debug("Successfully Selected the Premium pigeonHole");
		GenericMethods.sychronizationinterval();
		Thread.sleep(3000);
		Assert.assertTrue(GenericMethods.elementToBePresent(PurchasePage.selectAPigeonHoleField));
		Logs.debug("USD 338.00 Text was found");
	}
	
	//Click on the orange box with the text "Engage USD 338".
	@Test(priority =2)
	public void SelectManageProduct() throws Throwable
	{
		
		purchasePage.selectManageProductItem();
		Logs.debug("Successfully Selected the Engage product");
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(PurchasePage.priceDropdownIcon));
		Logs.debug("Successfully Selected the Manage product");
	}
	
	//Enter the billing details
	//Add promocode
	@Test(priority =3)
	public void EnterBillingInformation() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		purchasePage.fillBillingDetails(TestDataGenerator.randomAddress, TestDataGenerator.randomCity, TestDataGenerator.randomState, TestDataGenerator.randomZipCode, countryName);
		Logs.debug("Successfully filled the Billing deatails ");
		GenericMethods.sychronizationinterval();
		purchasePage.addPromoCode(promoCode);
		Logs.debug("Successfully added the PromoCode");
		GenericMethods.sychronizationinterval();
		purchasePage.clickPayButton();
	
	}
	//Enter Payment Details
	//Do you see a popup with the text: Thank you for purchasing a new Pigeonhole
	@Test(priority=4)
	public void EnterPaymentDetais() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		purchasePage.fillPaymentDetails(cardNumber, TestDataGenerator.randomName, expireDate, cvv);
		purchasePage.submitPayment();
		Logs.debug("Successfully filled the Payment deatails ");	
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());	
	}

}
