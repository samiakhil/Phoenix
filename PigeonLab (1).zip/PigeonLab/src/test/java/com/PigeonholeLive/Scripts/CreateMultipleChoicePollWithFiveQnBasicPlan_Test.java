package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;


public class CreateMultipleChoicePollWithFiveQnBasicPlan_Test extends GenericMethods {

	/* Objects Declaration Section */
	public DashboardPage dashboardPage;
	public AgendaPage agendaPage;
	public SessionPage sessionPage;
	public RunEventsPage runEventPage;
	public TestDataGenerator testDataGeneratorPage;
	public PageElementsInitialization elementsInitialization;

	/* Test Input Data Section */
	String url = "basicPlanUrl";	
	String pollQuestion = "What is your favourite fruit?";
	String optionOne = "Guava";
	String optionTwo = "Apple";	
	String lableName = "Poll";
	String buttonText = "Join Poll";


	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {
		
		Logs.initLogs(CreateAnOpenTextPollSession_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());
		
		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		agendaPage = new AgendaPage();
		sessionPage = new SessionPage();
		runEventPage = new RunEventsPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.agendaPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.runEventsPageObjectory();
	}
	
	/* Create MultipleChoicePoll With 5Qn on BasicPlan */
	@Test(priority =1)
	public void createMultipleChoicePoll() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		DashboardPage.asiaLeadershipConferenceLink.click();
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.checkIfElementExists(RunEventsPage.runYourEventHeader));
		Logs.debug("Navigated to 2018 Asia Leadership Conference Run Your Event Page");
		agendaPage.clickOnAgendaLinkButton();
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.checkIfElementExists(SessionPage.sessionTab));
		Logs.debug("Navigated to session Page and was found titled MCQ (1 Qn)");
	}
	
	/* Adding MultipleChoicePoll With 5Qn on BasicPlan */
	@Test(priority =2)
	public void addMCPWithFiveQn() throws Throwable {
		GenericMethods.sychronizationinterval();
		sessionPage.clickOnEditButton();
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.checkIfElementExists(SessionPage.pollQuestionTittled));
		sessionPage.addingFiveMCPQuestions(pollQuestion, optionOne, optionTwo);
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(SessionPage.upgradingThePlanPopUp));
		Logs.debug("Pop-up about Upgrading the Plan was displayed on screen");
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
		
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
		
	}

}

