package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class CreateAnOpenTextPollSession_Test extends GenericMethods{

	/* Objects Declaration Section */
	public DashboardPage dashboardPage;
	public SessionPage sessionPage;
	public TestDataGenerator testDataGeneratorPage;
	public PageElementsInitialization elementsInitialization;
	
	/* Test Input Data Section */
	String url ="createSessionUrl";
	String expectedPollBorder = "#f07424";
	String sessionName = TestDataGenerator.randomSessionName;
	String description = TestDataGenerator.description;
	String locationName = TestDataGenerator.randomAddress;	
	String question = "What is your favourite movie?";
	String lableName = "Suggestions";
	String buttonText = "Post Suggestions";
	
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {
		
		Logs.initLogs(CreateAnOpenTextPollSession_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());
		
		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		sessionPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();
	}
	
	
	/* Creating OpenEnded Poll Session and filling up AgendaInformation*/
	@Test(priority =1)
	public void createOpenEndedPollSession() throws Throwable {
		
		dashboardPage.addSession();
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(ApplicationTittles.agendaPageTitle, GenericMethods.titleValidation(), "Title validation failed");
		Logs.debug("Navigated to agendaPage and contains header like 'Agenda > Sessions > New Session' ");
		GenericMethods.elementToBePresent(SessionPage.headerText);
		sessionPage.clickOnPollOpenEnded();
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(expectedPollBorder,
				GenericMethods.getColourOfElement(SessionPage.pollOpenEndedButton));
		Logs.debug("Poll: Open-ended box is ticked and orange outlined");
		sessionPage.fillUpAgendaInformation(sessionName, description, locationName);
		
	}
	
	/* Filling up details regarding PollOpenEnded session like PollQuestion, AdvanceCustomisation */
	@Test(priority =2 )
	public void fillOpenTextSession() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		sessionPage.addPollQuestion(question);
		sessionPage.addAdvanceCustomisation(lableName, buttonText);
		Logs.debug("Suggestions and Post Suggestions displayed on the Audience Web App preview");
		sessionPage.clickOnaddOpenEndedPollButton();
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(sessionName, GenericMethods.getTextOfElement(AgendaPage.sessionNameTextField));
		Logs.debug("OpenTextPoll session name added in the sessions page");
	}
	
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
		
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());	
	
	}

}
