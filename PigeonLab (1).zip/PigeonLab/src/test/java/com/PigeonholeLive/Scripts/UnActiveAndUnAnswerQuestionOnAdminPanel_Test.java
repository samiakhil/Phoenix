package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AdminPanelPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class UnActiveAndUnAnswerQuestionOnAdminPanel_Test {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public RunEventsPage runEventsPage;
	public AdminPanelPage adminPanelPage;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	String url = "EditDismissUrl";
	String expectedTitle = "Admin Panel";
	int adminPanel_Page = 2;
	String expectedOrangeBorder = "#f39124";
	String expectedGreyBorder = "#c3c3c9";

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(UnActiveAndUnAnswerQuestionOnAdminPanel_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		runEventsPage = new RunEventsPage();
		adminPanelPage = new AdminPanelPage();
		elementsInitialization = new PageElementsInitialization();
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.runEventsPageObjectory();
		elementsInitialization.adminPannelPageObjectory();
	}

	// select event name : 2018 Asia Leadership Conference
	// select Admin Panel Page
	@Test(priority = 1, description = "select event")
	public void selectEvent() throws Throwable {

		GenericMethods.checkIfButtonExistsAndClick(DashboardPage.gotItButton);
		dashboardPage.clickOnEvent();
		Logs.debug("Successfully Selected 2018 Asia Leadership Conference");
		GenericMethods.sychronizationinterval();
		runEventsPage.clickOnAdminPanel();
		Logs.debug("Successfully selected Admin Panel");
	}

	// Switch to Admin Panel Page
	// Verify the title
	// Click on the Q&A session
	@Test(priority = 2, description = "Admin Panel Page Actions")
	public void adminPanelActions() throws Throwable {

		GenericMethods.switchToNewWindow(adminPanel_Page);
		Logs.debug("Successfully reached to Admin Panel Page");
		GenericMethods.maximizeWindow();
		GenericMethods.sychronizationinterval();
		String obtainedTitle = AdminPanelPage.adminPanelVerifyTitle.getText();
		Assert.assertEquals(obtainedTitle, expectedTitle, "Obtained title did not match");
		Logs.debug("Admin Panel title was found");
		adminPanelPage.clickOnEvent();
		Logs.debug("Successfully clicked on Q&A session");
	}

	// Click On Active Button
	// Verify the colour of Active Button
	// Again Click on Active Button
	// Verify the colour of Active Button
	@Test(priority = 3, description = "Actions On Active Button")
	public void activeActions() throws Throwable {

		GenericMethods.sychronizationinterval();
		adminPanelPage.clickOnActive();
		Logs.debug("Successfully clicked on Active");
		Assert.assertEquals(expectedOrangeBorder, GenericMethods.getColourOfElement(AdminPanelPage.activeVerifyColour));
		Logs.debug("Active Button changed to orange outline was found");
		adminPanelPage.clickOnOrangeActive();
		Logs.debug("Successfully clicked on orange Active Button");
		Assert.assertEquals(expectedGreyBorder, GenericMethods.getColourOfElement(AdminPanelPage.activeVerifyColour));
		Logs.debug("Successfully Active Button changed to grey outline was found");
	}

	// Click on Answered Button
	// Verify the colour of the button to be in orange
	// Again Click on the Answered Button
	// Verify the colour of the button to be in Grey
	@Test(priority = 4, description = "Answered Button Actions")
	public void answeredActions() throws Throwable {

		adminPanelPage.clickOnAnsweredButton();
		Logs.debug("Successfully clicked Answered Button");
		Assert.assertEquals(expectedOrangeBorder,
				GenericMethods.getColourOfElement(AdminPanelPage.answeredButton));
		Logs.debug("Answered Button organe outline was found");
		adminPanelPage.clickOnOrangeAnswered();
		Assert.assertEquals(expectedGreyBorder, GenericMethods.getColourOfElement(AdminPanelPage.answeredButton));
		Logs.debug("Successfully Answered Button changed to grey outline was found");
	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}

}
