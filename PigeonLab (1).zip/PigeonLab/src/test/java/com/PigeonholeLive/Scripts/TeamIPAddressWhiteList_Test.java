package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.ProfilePage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Pages.SecurityPage;
import com.PigeonholeLive.Pages.AppearancePage;
import com.PigeonholeLive.Pages.AudienceWebAppPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class TeamIPAddressWhiteList_Test extends GenericMethods {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public ProfilePage profilePage;
	public SecurityPage securityPage;
	public RunEventsPage runEventsPage;
	public AppearancePage appearancePage;
	public AudienceWebAppPage audienceWebAppPage;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	public String url = "templateSessionUrl";
	public String ipAddress = "8.8.8.8";
	public int audienceWebApp = 2;
	public int dashboard = 1;

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) throws Exception {

		Logs.initLogs(TeamIPAddressWhiteList_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		profilePage = new ProfilePage();
		securityPage = new SecurityPage();
		runEventsPage = new RunEventsPage();
		appearancePage = new AppearancePage();
		audienceWebAppPage = new AudienceWebAppPage();
		elementsInitialization = new PageElementsInitialization();

		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.profilePageObjectory();
		elementsInitialization.securityPageObjectory();
		elementsInitialization.runEventsPageObjectory();
		elementsInitialization.appearancePageObjectory();
		elementsInitialization.AWAPageObjectory();
	}

	// Click the button: Got it. Click on the three person icon
	// On the top left corner, click on the 3 person icons.
	// in that list click on "Team Settings".Are you on a page with title "Team Profile"?
	@Test(priority = 1)
	public void teamWorkspace() throws Throwable {

		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(DashboardPage.youHaveJoinedTeam));
		Logs.debug("You've joined the Team text was found");
		dashboardPage.clickOnGotItButtonOne();
		Logs.debug("Clicked Got It Button successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnMyTeamWorkSpace();
		Logs.debug("Selected My Team Workspace Successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnTeamWorkspaceLogo();
		Logs.debug("Clicked on my team workspace logo successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnTeamSettings();
		Logs.debug("Clicked on team settings successfully");
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(ProfilePage.teamProfile));
		Logs.debug("Team Profile text was found");
	}

	// Click on "Security" 
	// Under the IP Address Whitelist section, type "8.8.8.8"  and save it.
	// Click on "Pigeonholes" link from navigation bar at the top.
	// Click on event "Ongoing pigeonhole" from the event list table.
	@Test(priority = 2)
	public void ipAddress() throws Throwable {

		GenericMethods.sychronizationinterval();
		profilePage.clickOnSecurityButton();
		Logs.debug("Clicked on security button successfully");
		GenericMethods.sychronizationinterval();
		securityPage.enterIpAddress(ipAddress);
		Logs.debug("Entered IP Address successfully");
		GenericMethods.sychronizationinterval();
		securityPage.clickOnSaveButton();
		Logs.debug("IP Address saved successfully");
		securityPage.clickOnPigeonholesButton();
		Logs.debug("Clicked on Pigeonholes successfully ");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnOngoingPigeonhole();
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(RunEventsPage.ongoingPigeonhole));
		Logs.debug("Ongoing Pigeonhole text was found ");
	}

	// Click on "More settings"  then select the "Security" tab.
	// Are you on a page with orange section titled "IP Address Whitelist"?
	// click on "Run links", you will see a drop-down list. Then click on
	// "Audience Web App" link in the menu.
	// Do you see a page with an agenda?
	// Return to previous tab (the url should show the word dashboard).
	@Test(priority = 3)
	public void audienceWebAppAgenda() throws Throwable {

		runEventsPage.clickOnMoreSettingsButton();
		Logs.debug("Clicked on more setings successfully ");
		appearancePage.clickOnSecurityButton();
		Logs.debug("Clicked on security button successfully ");
		GenericMethods.sychronizationinterval();
		securityPage.clickOnToolTipButton();
		Logs.debug("Clicked on toolTip button successfully");
		GenericMethods.sychronizationinterval();
		securityPage.clickOnRunLinks();
		Logs.debug("Clicked on runlinks successfully ");
		securityPage.clickOnAudienceWebApp();
		Logs.debug("Clicked on Audience web app successfully ");
		GenericMethods.sychronizationinterval();
		GenericMethods.switchToNewWindow(audienceWebApp);
		Logs.debug("Switched to Audience web app successfully");
		Assert.assertTrue(GenericMethods.elementToBePresent(AudienceWebAppPage.agenda));
		Logs.debug(" agenda was found");
		GenericMethods.sychronizationinterval();
		GenericMethods.closeWindow();
		GenericMethods.switchToNewWindow(dashboard);
		Logs.debug("switched to dshboard page successfully");
	}

	
	// Click on the checkbox "Enable IP address whitelist for this event", then save it.
	// click on "Run links", you will see a drop-down list. Then click on "Audience Web App" link in the menu.
	// Do you see a page with error message "This Pigeonhole is not accessable from your current network."? 
	@Test(priority = 4)
	public void ipWhieList() throws Throwable {
		
		
		GenericMethods.sychronizationinterval();
		securityPage.clickOnIPWhiteList();
		Logs.debug("Clicked on IPWhiteList successfully ");
		GenericMethods.sychronizationinterval();
		securityPage.clickOnSaveIP();
		Logs.debug("saved IPWhitelist successfully");
		GenericMethods.sychronizationinterval();
		securityPage.clickOnRunLinks();
		Logs.debug("Clicked on runlinks successfully ");
		GenericMethods.sychronizationinterval();
		securityPage.clickOnAudienceWebApp();
		Logs.debug("Clicked on Audience web app successfully ");
		GenericMethods.sychronizationinterval();
		GenericMethods.titleValidation();
		Logs.debug("Pigeonhole Live title was found");
	}
	/* Method for quit driver session */
	
	  @AfterClass public void quitDriversession() {
	  
	  GenericMethods.CloseDriverSession();
	  Logs.endTestCase(this.getClass().getSimpleName());
	  
	   }
}
