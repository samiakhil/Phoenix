package com.PigeonholeLive.Scripts;

import java.util.Iterator;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.LoginPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class ChangePassword_Test extends GenericMethods {
	
	/* Objects Declaration Section */
	public DashboardPage dashboardPage;
	public LoginPage loginPage;
	public TestDataGenerator testDataGeneratorPage;
	public PageElementsInitialization elementsInitialization;
	
	/* Test Input Data Section */
	//String url = "loginPageUrl";
	String url ="Demo_URL";
	String passwordText = "123Ab";
	String randomPassword = passwordText+ TestDataGenerator.randomTestName;
	String emaildonail = "@gmail.com";
	String email = TestDataGenerator.question+emaildonail;
	
	@Test
	
	public void testing() {
		
		
		
		System.out.println(email);
		
		
		
	}
	
	
}
	/* Launch the browser and navigate the Application 
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {
		
		Logs.initLogs(ChangePassword_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());
		
		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		loginPage = new LoginPage();
		
		elementsInitialization = new PageElementsInitialization();
		elementsInitialization.loginPageObjectory();
		elementsInitialization.dashBoardPageObjectory();
	}

	 Verify the functionality of Login authentication and change password 
	@Test
	public void changePassword() throws Throwable  {

		loginPage.clickOnLoginpageButton();	
		GenericMethods.sychronizationinterval();
		loginPage.logintoPigeonholeLiveAccount();
		GenericMethods.sychronizationinterval();
		Logs.debug("Successfully log into Pigeonhole Account");
		Assert.assertEquals(ApplicationTittles.dashBoardTitle, GenericMethods.titleValidation(), "Navigating to dashboardPage failed");	
		GenericMethods.sychronizationinterval();
		dashboardPage.changeToNewPassword(randomPassword);
		Logs.debug("Password changed successfully");
		GenericMethods.sychronizationinterval();
		DashboardPage.logoutFromDashboard();
		dashboardPage.validateLoginAuthentication(randomPassword);
		Logs.debug("Sucessfully login with newly changed password");
		Assert.assertEquals(ApplicationTittles.dashBoardTitle, GenericMethods.titleValidation(), "Login Authentication Failed");
		GenericMethods.sychronizationinterval();
		DashboardPage.logoutFromDashboard();
	}
	
	 Method for quit driver session 
	@AfterClass
	public void quitDriversession() {
		
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());	
	}

}*/
