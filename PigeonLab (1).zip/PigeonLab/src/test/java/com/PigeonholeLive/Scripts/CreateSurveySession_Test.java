package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class CreateSurveySession_Test {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public SessionPage sessionPage;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	String url = "createSessionUrl";
	String expectedSurveyBorder = "#f07424";
	public String sessionName = TestDataGenerator.randomSessionName;
	public String surveyQuestionOne = "Which is your favourite food?";
	public String questionOneOptionOne = "mango";
	public String questionOneOptionTwo = "beetroot";
	public String expectedSurveyTitle = "Add Survey Question";
	public String surveyQuestionTwo = "What is your favourite movie?";
	public String expectedQuestionsCount = "Questions (2) *";
	public String sessionLabel = "Feedback";
	public String buttonText = "Share my feedback";

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(CreateSurveySession_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		sessionPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();

	}

	// click on event : 2018 Asia Leadership Conference.
	// Add Session, with type Survey
	// Select Survey Box.
	@Test(priority = 1, description = "creating Sesssion")

	public void surveySession() throws Throwable {

		dashboardPage.addSession();
		Assert.assertEquals(ApplicationTittles.agendaPageTitle, GenericMethods.titleValidation(),
				"Title validation failed");
		Logs.debug("Navigated to agendaPage and contains header like 'Agenda > Sessions > New Session' ");
		GenericMethods.elementToBePresent(SessionPage.headerText);
		sessionPage.createSurveySession(sessionName);
		Logs.debug("Successfully created Session with type survey");
		Assert.assertEquals(expectedSurveyBorder, GenericMethods.getColourOfElement(SessionPage.clickOnSurveyBox));
		Logs.debug("Tick and orange outline was found");
		sessionPage.addQuestionButton();

	}

	// Add Survey Question for multiple choice
	// verify Survey title
	@Test(priority = 2, description = "Add Survey Question type multiple choice")
	public void addSurveyQuestion() throws Throwable {

		GenericMethods.sychronizationinterval();
		String obtainedMessage = SessionPage.surveyVerifyTitle.getText();
		Assert.assertEquals(obtainedMessage, expectedSurveyTitle, "Obtained Title did not match");
		Logs.debug("Add Survey Question was found");
		GenericMethods.sychronizationinterval();
		sessionPage.addSurveyQuestionAndAnswer(surveyQuestionOne, questionOneOptionOne, questionOneOptionTwo);
		Logs.debug("Successfully created Question for multiple choice");
		Thread.sleep(4000); // Synchronization required
		sessionPage.addQuestionButton();
		GenericMethods.sychronizationinterval();
		obtainedMessage = GenericMethods.getTextOfElement(SessionPage.surveyVerifyTitle);
		Assert.assertEquals(obtainedMessage, expectedSurveyTitle, "Obtained Title did not match");
		Logs.debug("Add Survey Question was found");
		GenericMethods.sychronizationinterval();

	}

	// Add Survey Question for open text
	// verify survey question count
	@Test(priority = 3, description = "Add survey question type open text")
	public void surveyQuestionOpenText() throws Throwable {

		sessionPage.addSurveyQuestionTwo(surveyQuestionTwo);
		Logs.debug("Successfully created Question for open text");
		String obtainedQuestionsCount = GenericMethods.getTextOfElement(SessionPage.surveyQuestionsVerifyCount);
		Assert.assertEquals(obtainedQuestionsCount, expectedQuestionsCount, "Obtained count did not match");
		Logs.debug("Successfully added Multiple choice question and open text Question");

	}

	// Add Advance Customization
	// Add text in session label, and button text
	@Test(priority = 4, description = "Setup Advance Customization")
	public void advanceCustomization() throws Throwable {

		GenericMethods.sychronizationinterval();
		sessionPage.addAdvanceCustomisation(sessionLabel, buttonText);
		Logs.debug("Successfully added Session label and button text");
		String obtainedSessionLabelText = SessionPage.sessionLabelVerifyText.getText();
		Assert.assertEquals(obtainedSessionLabelText, sessionLabel, "Obtained label did not match");
		Logs.debug("Successfully found Session label text");
		sessionPage.addSurvey();
		Logs.debug("Successfully added Survey Question");
		Thread.sleep(3000); // Synchronization required to load the page
		String obtainedSessionName = GenericMethods.getTextOfElement(AgendaPage.sessionNameTextField);
		Assert.assertEquals(obtainedSessionName, sessionName, "Obtained session Name text did not match");
		Logs.debug("Successfully Added Session Name,  able to see in the session page");
	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}

}
