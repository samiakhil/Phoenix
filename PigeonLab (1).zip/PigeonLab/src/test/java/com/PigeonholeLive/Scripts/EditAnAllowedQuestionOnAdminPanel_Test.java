package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AdminPanelPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class EditAnAllowedQuestionOnAdminPanel_Test {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public RunEventsPage runEventsPage;
	public AdminPanelPage adminPanelPage;
	public PageElementsInitialization elementsInitialization;

	//Test Input Data Section
	String url = "EditDismissUrl";
	String expectedTitle = "Admin Panel";
	int adminPanel_Page = 2;
	public String expectedQuestionColour = "#e2e2e5";
	public String expectedEditQuestionTitle = "Edit question";
	public String question = TestDataGenerator.question;
	public String expectedEditedText = "(edited)";

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(EditAnAllowedQuestionOnAdminPanel_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		runEventsPage = new RunEventsPage();
		adminPanelPage = new AdminPanelPage();
		elementsInitialization = new PageElementsInitialization();
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.runEventsPageObjectory();
		elementsInitialization.adminPannelPageObjectory();
	}

	// select event name : 2018 Asia Leadership Conference
	// In Run Links Page choose Admin Panel
	@Test(priority = 1, description = "click On Admin Panel Page")
	public void selectEvent() throws Throwable {

		GenericMethods.checkIfButtonExistsAndClick(DashboardPage.gotItButton);
		dashboardPage.clickOnEvent();
		Logs.debug("Successfully Selected 2018 Asia Leadership Conference");
		GenericMethods.sychronizationinterval();
		runEventsPage.clickOnAdminPanel();
		Logs.debug("Successfully selected Admin Panel");
	}

	// Switch to Admin Panel Page
	// Verify the title
	// Click on the Q&A session
	@Test(priority = 2, description = "Admin Panel")
	public void adminPanelActions() throws Throwable {

		GenericMethods.switchToNewWindow(adminPanel_Page);
		Logs.debug("Successfully reached to Admin Panel Page");
		GenericMethods.sychronizationinterval();
		GenericMethods.maximizeWindow();
		GenericMethods.sychronizationinterval();
		String obtainedTitle = AdminPanelPage.adminPanelVerifyTitle.getText();
		Assert.assertEquals(obtainedTitle, expectedTitle, "Obtained title did not match");
		Logs.debug("Admin Panel title was found");
		adminPanelPage.clickOnEvent();
		Logs.debug("Successfully clicked on Q&A session");
	}

	// click on more options
	// Hide the question
	// verify hide question text colour become lighter
	@Test(priority = 3, description = "Allow Question")
	public void allowQuestionInAdminPanel() throws Throwable {

		adminPanelPage.adminPanelActions();
		Logs.debug("Successfully hide the first question");
		Assert.assertEquals(expectedQuestionColour,
				GenericMethods.getColourOfElement(AdminPanelPage.hideVerifyQuestion));
		Logs.debug("Question text colour become lighter was found");
	}

	// click on edit option
	// Verify the title: Edit question
	@Test(priority = 4, description = "Verify Edit Question Title")
	public void editHideQuestion() {

		adminPanelPage.editQuestion();
		Logs.debug("Successfully clicked on the edit option");
		String obtainedEditQuestionTitle = AdminPanelPage.editQuestionVerifyTitle.getText();
		Assert.assertEquals(obtainedEditQuestionTitle, expectedEditQuestionTitle, "Obtained title did not match");
		Logs.debug("Successfully found Edit question title");
	}

	// Edit Hide Question
	// Save the edited Question
	@Test(priority = 5, description = "Edit Hide Question")
	public void addEditQuestion() throws Throwable {

		adminPanelPage.editQuestionText(question);
		Logs.debug("Successfully edited and save the Question");
		GenericMethods.sychronizationinterval();
		String obtainedEditedText = AdminPanelPage.editedVerifyText.getText();
		Assert.assertEquals(obtainedEditedText, expectedEditedText, "Obtained edited Question did not match");
		Logs.debug("Successfully found Edited question");
	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());

	}

}
