package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.AudienceWebAppPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;
public class PostAnswerAnonymouslyInOpenEndedSessionAndVote_Test extends GenericMethods {

	/* Objects Declaration Section */
	public DashboardPage dashboardPage;
	public AgendaPage agendaPage;
	public SessionPage sessionPage;
	public AudienceWebAppPage audienceWebAppPage;
	public RunEventsPage runEventPage;
	public TestDataGenerator testDataGeneratorPage;
	public PageElementsInitialization elementsInitialization;

	/* Test Input Data Section */
	String url ="Q&A_URL";
	String expectedPollBorder = "#f07424";
	int voteCount = 1;
	String textMessage = TestDataGenerator.textAnswer;
	
	
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {
		
		Logs.initLogs(CreateAnOpenTextPollSession_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());
		
		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		runEventPage = new 	RunEventsPage();
		audienceWebAppPage = new AudienceWebAppPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.agendaPageObjectory();
		elementsInitialization.AWAPageObjectory();
		elementsInitialization.runEventsPageObjectory();
	}
	
	
	/* Navigating to Audience Web Application */
	@Test(priority = 1)
	public void navigateToAWA() throws Throwable {
		
		GenericMethods.checkIfButtonExistsAndClick(DashboardPage.asiaLeadershipConferenceLink);
		dashboardPage.clickOnGotItButton();
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(ApplicationTittles.runEventsTitle, GenericMethods.titleValidation());
		Logs.debug("navigated to Run Your Event Page");
		runEventPage.accessAWAFromRunLinks();
		Logs.debug("navigated to 2018 Asia Leadership Conference AWA Page");
	}
	
	/* Post And Vote Answer In open-text Session for 2018 Asia Leadership Conference Event*/
	@Test(priority = 2)
	public void PostAnswerAndVoteInOpenEndedSession() throws Throwable {
		
		GenericMethods.sychronizationinterval();
		audienceWebAppPage.clickOnOpenSessionLink();
		GenericMethods.sychronizationinterval();
		audienceWebAppPage.setAnswer(textMessage);
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(textMessage, GenericMethods.getTextOfElement(AudienceWebAppPage.textName));
		GenericMethods.checkIfButtonExistsAndClick(AudienceWebAppPage.submitButtonTwo);
		Logs.debug("THANK YOU confirmation popup was found");
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(textMessage, GenericMethods.getTextOfElement(AudienceWebAppPage.answerText));
		GenericMethods.checkIfButtonExistsAndClick(AudienceWebAppPage.upIconButton);
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(expectedPollBorder,
				GenericMethods.getColourOfElement(AudienceWebAppPage.upIconButton));
		Logs.debug("up icon turned into orange and the vote changed from 0 to 1");
		
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
		
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	
	}

	
}
