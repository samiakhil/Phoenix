package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class CreateWordCloudSession_Test {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public SessionPage sessionPage;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	String url = "createSessionUrl";
	String expectedWordCloudBorder = "#f07424";
	public String sessionName = TestDataGenerator.randomSessionName;
	public String descriptionLinkText = "Lorem_ipsum";
	public String pollQuestion = "Which is your favourite fruit?";

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(CreateWordCloudSession_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");

		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		sessionPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();

	}

	// click on event : 2018 Asia Leadership Conference.
	// Add Session, with type word cloud
	@Test(priority = 1, description = "Creating Word Cloud Session")
	public void wordCloudSession() throws Throwable {

		dashboardPage.addSession();
		Assert.assertEquals(ApplicationTittles.agendaPageTitle, GenericMethods.titleValidation(),
				"Title validation failed");
		Logs.debug("Navigated to agendaPage and contains header like 'Agenda > Sessions > New Session' ");
		GenericMethods.elementToBePresent(SessionPage.headerText);
		sessionPage.createWordCloudSession(sessionName);
		Logs.debug("Successfully created Session");
		Assert.assertEquals(expectedWordCloudBorder, GenericMethods.getColourOfElement(SessionPage.clickOnWordCloud));
		Logs.debug("Tick and orange outline was found");

	}

	// Add description link text
	// Add question
	@Test(priority = 2, description = "Add question")
	public void wordCloudQuestion() throws Throwable {

		sessionPage.addWordCloudSessionQuestion(descriptionLinkText, pollQuestion);
		Logs.debug("Successfully added Description Link Text and poll Question");
		Thread.sleep(3000); // Synchronization required to load the page
		String obtainedSessionName = GenericMethods.getTextOfElement(AgendaPage.sessionNameTextField);
		Assert.assertEquals(obtainedSessionName, sessionName, "Obtained session Name did not match");
		Logs.debug("Successfully Added Session able to see in the session page");

	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}

}
