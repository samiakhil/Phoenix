package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AdminPanelPage;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class AddAnAnswerToAnAllowedQuestionWithoutSpeakersInAdminPanel_Test {
	
	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public RunEventsPage runEventsPage;
	public AgendaPage agendaPage;
	public AdminPanelPage adminPanelPage;
	
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	public String url = "AddAnAnswerToAnAllowedQuestionUrl";
	public String password = "PigeonholeTest@123";
	public String firstAnswer = TestDataGenerator.description;
	public int adminPannel = 2;
	public static String obtainedSessionName;
	
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) throws Exception {

		Logs.initLogs(AddAnAnswerToAnAllowedQuestionWithoutSpeakersInAdminPanel_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		runEventsPage = new RunEventsPage();
		agendaPage = new AgendaPage();
		adminPanelPage = new AdminPanelPage();
		elementsInitialization = new PageElementsInitialization();

		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.runEventsPageObjectory();
		elementsInitialization.agendaPageObjectory();
		elementsInitialization.adminPannelPageObjectory();

	}
	
	// click the Got It button**.Are you taken to a page titled Run Your Even
	//From the left panel, click AGENDA.
	//Click on the EDIT button for the first available session.
	//Scroll down to the Q&A SETTINGS section. 
	//Tickmark the ANSWERS checkbox. Then click the SAVE Q&A button.
	@Test(priority = 1)
	public void runYourEvent() throws Throwable {
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnGotItButton();
		Logs.debug("Clicked on Got It button successfully");
		GenericMethods.sychronizationinterval();
		dashboardPage.clickOnEvent();
		Logs.debug("Clicked on event name successfully");
		GenericMethods.sychronizationinterval();
		runEventsPage.clickOnAgenda();
		Logs.debug("Clicked on agenda  successfully");
		GenericMethods.sychronizationinterval();
		obtainedSessionName = AgendaPage.getSessionName.getText();
		Logs.debug("Noted session name successfully");
		GenericMethods.sychronizationinterval();
		agendaPage.clickOnEditButton();
		Logs.debug("Clicked on edit button successfully");
	}
	
	//Scroll down to the Q&A SETTINGS section. 
	//Tickmark the ANSWERS checkbox. Then click the SAVE Q&A button.
	@Test(priority = 2)
	public void runEventSettings() throws Throwable {
		GenericMethods.sychronizationinterval();
		agendaPage.clickOnAnswersCheckbox();
		Logs.debug("Clicked on answers checkbox");
		GenericMethods.sychronizationinterval();
		agendaPage.clickOnSaveQA();
		Logs.debug("Clicked on SaveQA successfully");
	}	
	//Click the RUN LINKS drop-down in the top-right.
	//Then click ADMIN PANEL from the drop-down menu.
	//Are you taken to the ADMIN PANEL page?
	//Click on the session (you took note earlier).
	//Are you redirected to a page with the title: Allowed Questions.
	@Test(priority = 3)
	public void runLinks() throws Throwable {	
		GenericMethods.sychronizationinterval();
		agendaPage.clickOnToolTip();
		Logs.debug("Clicked on tooltip button successfully");
		GenericMethods.sychronizationinterval();
		agendaPage.clickOnRunLinkButton();
		Logs.debug("Clicked on run links button successfully");
		GenericMethods.sychronizationinterval();
		agendaPage.clickOnAdminPanel();
		Logs.debug("Clicked on Admin panel successfully");
		GenericMethods.switchToNewWindow(adminPannel);
		Logs.debug("switched to Admin pannel window successfully");
		GenericMethods.sychronizationinterval();
		String expectedSessionName = AdminPanelPage.matchSessionName.getText();
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(obtainedSessionName,expectedSessionName);	
		Logs.debug("Session name was verified successfully");
		GenericMethods.sychronizationinterval();
		adminPanelPage.clickOnVerifiedSession();
		Logs.debug("Redirected to allowed questions page");
	}
	
	//Click on the ADD ANSWER link for any of the question(s) displayed on the page.
	//enter the answers to the questions
	//Make sure "Admin" is selected in the ANSWER BY drop-down. Then click the ADD ANSWER button.
	//Can you see the answer that you just added with a unisex profile image and the text ADMIN? 
	@Test(priority = 4)
	public void addAnswersToTheQuestion() throws Throwable {	
		GenericMethods.sychronizationinterval();
		adminPanelPage.clickOnAddAnswer();
		Logs.debug("Clicked on add answer successfully");
		GenericMethods.sychronizationinterval();
		adminPanelPage.enterAnswer(firstAnswer);
		Logs.debug("Entered answer to the question successfully");
		GenericMethods.sychronizationinterval();
		adminPanelPage.clickOnAddAnswerButton();
		Logs.debug("Clicked on Add Answer button successfully");
		GenericMethods.sychronizationinterval();
		Assert.assertTrue(GenericMethods.elementToBePresent(AdminPanelPage.unisexProfileImage));
		Logs.debug("unisex profile image and the text ADMIN? was found");
	
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}
}
