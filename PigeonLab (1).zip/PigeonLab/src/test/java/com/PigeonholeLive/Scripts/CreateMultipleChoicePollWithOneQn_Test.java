package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class CreateMultipleChoicePollWithOneQn_Test extends GenericMethods{

	/* Objects Declaration Section */
	public DashboardPage dashboardPage;
	public SessionPage sessionPage;
	public TestDataGenerator testDataGeneratorPage;
	public PageElementsInitialization elementsInitialization;

	/* Test Input Data Section */
	String url = "createSessionUrl";	
	String expectedPollBorder = "#f07424";
	String sessionName = TestDataGenerator.randomSessionName;
	String pollQuestion = "What is your favourite animal?";
	String optionOne = "Lion";
	String optionTwo = "Tiger";
	String lableName = "Poll";
	String buttonText = "Join Poll";
		
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {
		
		Logs.initLogs(CreateMultipleChoicePollWithOneQn_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());
		
		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		sessionPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();
	}
	
	/* adding Poll: Multiple Choice Session */
	@Test(priority =1)
	public void createMultipleChoicePollSession() throws Throwable {
		
		dashboardPage.addSession();
		Assert.assertEquals(ApplicationTittles.agendaPageTitle, GenericMethods.titleValidation(), "Title validation failed"); 
		Logs.debug("Navigated to agendaPage and contains header like 'Agenda > Sessions > New Session' ");
		GenericMethods.elementToBePresent(SessionPage.headerText);
		sessionPage.clickOnpollMultpleChoicButton();
		Assert.assertEquals(expectedPollBorder,
				GenericMethods.getColourOfElement(SessionPage.pollMultipleChoiceButton));
		Logs.debug("Poll: Multiple Choice box was ticked and orange outlined");	
		
	}
	
	/* Filling up details regarding onpollMultpleChoiceQuestion Session like MultipleChoiceQuestion, AdvanceCustomisation*/
	@Test(priority = 2)
	public void fillMCQsession() throws Throwable {
		
		sessionPage.addingSessionName(sessionName);
		sessionPage.clickOnaddaddQuestionButton();
		Assert.assertTrue(GenericMethods.checkIfElementExists(SessionPage.popUpTittleField));
		Logs.debug("Displayed pop-up with title: Add Poll Question?");
		sessionPage.addMultipleChoiceQuestion(pollQuestion, optionOne, optionTwo);
		GenericMethods.sychronizationinterval();
		sessionPage.addAdvanceCustomisation(lableName, buttonText);
		GenericMethods.sychronizationinterval();
		sessionPage.clickOnAddQAButton();
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(sessionName, GenericMethods.getTextOfElement(AgendaPage.sessionNameTextField));
		Logs.debug("QA session name added in the sessions page");
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
	
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}
	

}
