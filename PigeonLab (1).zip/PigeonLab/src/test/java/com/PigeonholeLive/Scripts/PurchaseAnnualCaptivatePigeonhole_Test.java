package com.PigeonholeLive.Scripts;

import static org.testng.Assert.assertTrue;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.PurchasePage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class PurchaseAnnualCaptivatePigeonhole_Test extends GenericMethods{
	
	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public PageElementsInitialization elementsInitialization;
	public PurchasePage purchasePage;
	public TestDataGenerator randomDataGenerator;
	
	//Test Inputs
	public String url = "dashboardUrl";
	public String countryName ="Singapore";
	public String promoCode="TESTING-100";
	public String cardNumber =" 4111111111111111";
	public String expireDate =" 10/30";
	public String cvv=" 123";	
	public String teamWorkSpace ="TeamApple";
	public String expectedTeamTitle = teamWorkSpace.concat("'s Pigeonholes");
	
	
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch( String browser) {
 
		Logs.initLogs(PurchaseAnnualCaptivatePigeonhole_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());
		
		Logs.info("App Url Navigated");
		GenericMethods.openBrowser("chrome");
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		elementsInitialization = new PageElementsInitialization();
		purchasePage = new PurchasePage();
		randomDataGenerator=new TestDataGenerator();

		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.adminPannelPageObjectory();
		elementsInitialization.AWAPageObjectory();
		elementsInitialization.projecterPageObjectory();
		elementsInitialization.agendaPageObjectory();
		elementsInitialization.purchasePageObjectory();	
	}
	
	//click on the button "Get an Annual Plan".
	@Test(priority = 1)
	public void SelectannualPlan() throws Throwable
	{
		dashboardPage.clickOnGotItButton();
		dashboardPage.clickOnAnnualPlan();
		Logs.debug("Successfully Selected the annual plan");
		GenericMethods.sychronizationinterval();
	}
	
	//Click on the white box with the text "Annual Captivate".
	//Do you see "USD 600 per user / year" under Additional users?
	//Scroll down and look for Additional users. Click the plus button twice to add 2 users
	//Click on the down arrow next to the amount.
	//Do you see a light grey box and the text "Additional users x 2"?
	//In the grey box, look for Total payable.
	//Next to total payable, do you see the amount "3,900.00" or "5,758.74"?
	//Click Next.
	@Test(priority =2)
	public void SelectAnnaulCaptivateProduct() throws Throwable
	{
		purchasePage.selectAnnualCaptivate();
		Logs.debug("Successfully Selected the annual captivate product");
		GenericMethods.sychronizationinterval();
		assertTrue(GenericMethods.elementToBePresent(PurchasePage.additionalUserField));
		Logs.debug("USD 600 per user / year text field found in page");
		GenericMethods.sychronizationinterval();
		purchasePage.addAdditinoalUsers();
		GenericMethods.sychronizationinterval();
		assertTrue(GenericMethods.elementToBePresent(purchasePage.additionalUsersTwoTextField));
		Logs.debug("Additional users x 2 text field found in page");
		GenericMethods.sychronizationinterval();
		assertTrue(GenericMethods.elementToBePresent(PurchasePage.totalPaybleamountField));
		Logs.debug("the amount 3,900.00 text field found in page");
		purchasePage.clickOnNextButton();;
	}
	
	//Enter the billing details
	//Add promocode
	@Test(priority =3)
	public void EnterBillingInformation() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		purchasePage.fillBillingDetails(TestDataGenerator.randomAddress, TestDataGenerator.randomCity, TestDataGenerator.randomState, TestDataGenerator.randomZipCode, countryName);
		Logs.debug("Successfully filled the Billing deatails ");
		GenericMethods.sychronizationinterval();
		purchasePage.clickOnPriceDropDown();
		purchasePage.addPromoCode(promoCode);
		Logs.debug("Successfully added the PromoCode");
		GenericMethods.sychronizationinterval();
		purchasePage.clickPayButton();
		Thread.sleep(6000); // wait required to page load
	}
	
	//Enter Payment Details
	@Test(priority=4)
	public void EnterPaymentDetais() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		purchasePage.fillPaymentDetails(cardNumber, TestDataGenerator.randomName, expireDate, cvv);
		purchasePage.submitPayment();
		Logs.debug("Successfully filled the Payment deatails");
	}
	
	//Set up your Team Workspace
	@Test(priority=5)
	public void SetUpTeamWorkSpace() throws Throwable
	{
		GenericMethods.sychronizationinterval();
		Thread.sleep(6000); // wait required
		purchasePage.clickOnNextButton();
		GenericMethods.sychronizationinterval();
		purchasePage.createTeamWorkSpace(teamWorkSpace);
		Logs.debug("Team workspace" + teamWorkSpace + "setup done successfully");
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(PurchasePage.teamTitle.getText(), expectedTeamTitle);
		Logs.debug("Team workspace title matched with expected title");
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());	
	}

}
