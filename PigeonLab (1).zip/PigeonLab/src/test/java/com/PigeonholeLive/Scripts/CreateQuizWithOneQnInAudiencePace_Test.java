package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class CreateQuizWithOneQnInAudiencePace_Test extends GenericMethods {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public SessionPage sessionPage;
	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	String url = "createSessionUrl";
	String expectedPollBorder = "#f07424";
	public String sessionName = TestDataGenerator.randomSessionName;
	public String sessionLabel = "Pop Quiz";
	public String buttonText = "Join Pop Quiz";

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(CreateQuizWithOneQnInAudiencePace_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		sessionPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();

	}

	// Select an event 2018 Asia Leadership Conference,
	// Add new Session Type "poll: Quiz"
	// Creating Quiz With One Q&A In AudiencePace
	@Test(priority = 1, description = "Create Session")
	public void createSession() throws Throwable {

		dashboardPage.addSession();
		Assert.assertEquals(ApplicationTittles.agendaPageTitle, GenericMethods.titleValidation(),
				"Title validation failed");
		Logs.debug("Navigated to agendaPage and contains header like 'Agenda > Sessions > New Session' ");
		GenericMethods.elementToBePresent(SessionPage.headerText);
		sessionPage.addNewSession(sessionName);
		Logs.debug("Successfully added  new Session Type poll: Quiz");
		Assert.assertEquals(expectedPollBorder, GenericMethods.getColourOfElement(SessionPage.clickOnPollQuiz));
		Logs.debug("Tick and orange outline was found");

	}

	// Add question
	// Click on Advanced Customisation
	// Fill session Label: "Pop Quiz" and Button Text : "Join Pop Quiz"
	@Test(priority = 2, description = "Question and Answer in Audience Pace")
	public void quizInAudiencePace() throws Throwable {
		sessionPage.addQuestion(TestDataGenerator.question, TestDataGenerator.firstOption,
				TestDataGenerator.secondOption);
		Logs.debug(" Successfully Added Question");
		sessionPage.audiencePeace(sessionLabel, buttonText);
		Logs.debug(" Successfully Added Session Label And Button Text");
		String obtainedSessionLabel = GenericMethods.getTextOfElement(SessionPage.sessionLabelField);
		Assert.assertEquals(obtainedSessionLabel, sessionLabel, "Obtained text did not match");
		Logs.debug("Found Session Label Text");
		String obtainedButtonLabel = GenericMethods.getTextOfElement(SessionPage.ButtonTextField);
		Assert.assertEquals(obtainedButtonLabel, buttonText, "Obtained text did not match");
		Logs.debug("Found Button Text");

	}

	// click on : Add Quiz.
	// Able to see session Name in the sessions page
	@Test(priority = 3, description = "Submit Quiz")
	public void addQuiz() throws Throwable {

		sessionPage.submitQuiz();
		Logs.debug("Successfully Submited the Quiz");
		Thread.sleep(3000); // Synchronization required to load the page
		String obtainedSessionName = GenericMethods.getTextOfElement(AgendaPage.sessionNameTextField);
		Assert.assertEquals(obtainedSessionName, sessionName, "Obtained session Name did not match");
		Logs.debug("Successfully Added Session able to see in the session page");

	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}

}
