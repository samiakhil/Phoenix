package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.DataHelper.TestDataGenerator;
import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.AgendaPage;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.SessionPage;
import com.PigeonholeLive.Utilities.ApplicationTittles;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;
import com.github.javafaker.Faker;

public class CreateQAsession_Test extends GenericMethods{
	
	/* Objects Declaration Section */
	public DashboardPage dashboardPage;
	public SessionPage sessionPage;
	public TestDataGenerator testDataGeneratorPage;
	public PageElementsInitialization elementsInitialization;
	Faker faker = new Faker();
	
	/* Test Input Data Section */
	//String url ="createSessionUrl";
	String url ="Demo_URL";
	String sessionName = TestDataGenerator.randomSessionName;
	String description = TestDataGenerator.description;
	String locationName = TestDataGenerator.randomAddress;
	String tagFieldTextOne = "Apple";
	String tagFieldTextTwo = "StrawBerry";
	String lableName = "Panel Discussion";
	String buttonText = "Join Panel Discussion";
	
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {
		
		Logs.initLogs(CreateQAsession_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());
		
		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);
		
		dashboardPage = new DashboardPage();
		sessionPage = new SessionPage();
		elementsInitialization = new PageElementsInitialization();
		
		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.sessionPageObjectory();
		elementsInitialization.agendaPageObjectory();
	}
	
	/*Creating QA Session */
	@Test(priority = 1)
	public void creatingQAsession() throws Throwable {
		
		dashboardPage.addSession();
		Assert.assertEquals(ApplicationTittles.agendaPageTitle, GenericMethods.titleValidation(), "Title validation failed"); 
		GenericMethods.elementToBePresent(SessionPage.headerText);
		Logs.debug("Navigated to agendaPage");
	}
	
	/* filling up details regarding QA Session like AgendaInformation, Tags, AdvanceCustomisation */
	@Test(priority = 2)
	public void fillNewQAsession() throws Throwable {
		
		sessionPage.fillUpAgendaInformation(sessionName,description,locationName);
		sessionPage.addTags(tagFieldTextOne, tagFieldTextTwo);
		sessionPage.addAdvanceCustomisation(lableName, buttonText);
		sessionPage.clickOnAddQAButton();
		GenericMethods.sychronizationinterval();
		Assert.assertEquals(sessionName, GenericMethods.getTextOfElement(AgendaPage.sessionNameTextField));
		Logs.debug("Created Q&A session name in the agenda list");
	}
	
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {
		
		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	
	}

}
