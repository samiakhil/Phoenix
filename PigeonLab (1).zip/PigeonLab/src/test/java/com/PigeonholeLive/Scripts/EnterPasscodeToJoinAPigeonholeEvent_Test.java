package com.PigeonholeLive.Scripts;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.PigeonholeLive.FunctionalLibrary.GenericMethods;
import com.PigeonholeLive.Pages.DashboardPage;
import com.PigeonholeLive.Pages.RunEventsPage;
import com.PigeonholeLive.Utilities.Logs;
import com.PigeonholeLive.pageFactoryInitilization.PageElementsInitialization;

public class EnterPasscodeToJoinAPigeonholeEvent_Test {

	// Objects Declaration Section
	public DashboardPage dashboardPage;
	public RunEventsPage runEventsPage;

	public PageElementsInitialization elementsInitialization;

	// Test Input Data Section
	public String url = "Q&A_URL";
	public String expectedPasscodeColor = "#f07424";
	public int  stagingWindow= 2;
	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) throws Exception {

		Logs.initLogs(EnterPasscodeToJoinAPigeonholeEvent_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		Logs.info("App Url Navigated");
		GenericMethods.openBrowser(browser);
		GenericMethods.navigateAppUrl(url);

		dashboardPage = new DashboardPage();
		runEventsPage = new RunEventsPage();
		elementsInitialization = new PageElementsInitialization();

		elementsInitialization.dashBoardPageObjectory();
		elementsInitialization.runEventsPageObjectory();
	}

	// Click on the Pigeonhole with the name: 2018 Asia Leadership Conference.
	// Are you on the page: Run Your Event?
	@Test(priority = 1)
	public void runYourEvent() throws Throwable {
		
		dashboardPage.clickOnGotItButton();
		Logs.debug("Clicked on Got It button successfully");
		dashboardPage.clickOnEvent();
		Logs.debug("Clicked on 2018 Asia Leadership Conference event successfully");
	}

	// Find the six characters passcode at the top left of the screen.
	// The text colour should be orange.
	// Open a new tab and input the URL [[copy({{test_urls.staging_app}})]]
	// Type the passcode in the textfield and click the arrow icon
	@Test(priority = 2)
	public void fillPasscodeField() throws Throwable {
		
		String passcode = RunEventsPage.capturePasscode.getText();
		Logs.debug("Captured passcode successfully");
		Assert.assertEquals(expectedPasscodeColor, GenericMethods.getColourOfElement(RunEventsPage.capturePasscode));
		Logs.debug("passcode color was found orange");
		runEventsPage.openNewTab();
		Logs.debug("Opened new tab and entered staging url successfully");
		GenericMethods.switchToNewWindow(stagingWindow);
		Logs.debug("Switched to Staging window successfully");
		GenericMethods.sychronizationinterval();
		runEventsPage.enterPasscode(passcode);
		Logs.debug("Entered passcode successfully");
		GenericMethods.sychronizationinterval();
		runEventsPage.clickOnArrow();
		Logs.debug("Clicked on Arrow button successfully");
	}

	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}
}