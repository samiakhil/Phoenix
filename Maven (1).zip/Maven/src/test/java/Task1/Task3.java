package Task1;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Task3 extends WriteFilexl{
	//static WebDriver driver;

	public static void setup() throws Exception {
		WebDriverManager.chromedriver().setup();
		 driver = new ChromeDriver();
		driver.manage().window().maximize();
		Reporter.log("Screen has been maximized");
	}
	@Test
	 public void readeringfile() throws Exception {
	FileReader reader=new FileReader("C:\\Users\\dt21271\\eclipse-workspace\\Maven\\config.properties");
	Properties props=new Properties();
	props.load(reader);
	setup();
	   driver.get(props.getProperty("Url"));
		WebElement c =driver.findElement(By.xpath("(//input[@type='text'])[1]"));
		read(1,0,c);
		Reporter.log("The data has been entered into the application");
		screenshot();
		Reporter.log("successfully snapshoted");
}
}