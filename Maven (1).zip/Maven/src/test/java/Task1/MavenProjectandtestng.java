package Task1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MavenProjectandtestng extends WriteFilexl{
	//public static String baseUrl ="https://demoqa.com/";
	//public static String baseUrl1="http://omayo.blogspot.com/";
	//public String baseUrl2="https://demo.automationtesting.in/Register.html";
	static WebDriver driver;
	
	
	
@BeforeTest
public static void setup() throws Exception {
	WebDriverManager.chromedriver().setup();
	 driver = new ChromeDriver();
	driver.manage().window().maximize();
	 openNewTab(driver, "https://demoqa.com/",1);
	 String gettitle = driver.getTitle();
	 System.out.println(gettitle);
	 wrtxl(gettitle,0,7);
	 openNewTab(driver, "http://omayo.blogspot.com/",2);
	 String gettitle2 = driver.getTitle();
	 System.out.println(gettitle2);
	 wrtxl(gettitle2,1,4);
	  openNewTab(driver, "https://demo.automationtesting.in/Register.html",3);
	  String gettitle3 = driver.getTitle();
	  System.out.println(gettitle3);
	  wrtxl(gettitle3,2,5);
		/*
		 * driver.get(baseUrl); System.out.println(driver.getTitle());
		 * //driver.navigate().to(baseUrl1); System.out.println(driver.getTitle());
		 */
}



  public static void openNewTab(WebDriver driver, String url, int position) throws FileNotFoundException {
	// TODO Auto-generated method stub
	  ((JavascriptExecutor) driver).executeScript("window.open()");

	    ArrayList<String>  tabs = new ArrayList<String>(driver.getWindowHandles());
	    System.out.println("tabs : " + tabs.size() + " >position: " + position + " >\t" + url );
	
	    driver.switchTo().window(tabs.get(position));

	driver.get(url);
	 //System.out.println(driver.getTitle());  
	//String gettitle = driver.getTitle();
	//System.out.println(gettitle);
//}
/*
 @Test
 public void write_the_data_xl() throws FileNotFoundException {
 
	
	File file = new File("C:\\Users\\dt21271\\Desktop\\create.xlsx");
	XSSFWorkbook wb = new XSSFWorkbook();
	XSSFSheet    sh = wb.createSheet();
	sh.createRow(0).createCell(0).setCellValue(gettitle);
	//sh.getRow(0).createCell(1).setCellValue(69);

	FileOutputStream fos = new FileOutputStream(file);
	try {
		wb.write(fos);
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}*/
}


/*
 * @Test public void VerifyHomePage() { String expectedtitle ="ToolsQA"; String
 * actualtitle= driver.getTitle();
 * Assert.assertEquals(actualtitle,expectedtitle);
 * 
 * }
 */
  @AfterTest
  public void endsession() {
	  //driver.quit();
  }
 
}
