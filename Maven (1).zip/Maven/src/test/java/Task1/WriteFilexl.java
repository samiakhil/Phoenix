package Task1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

public class WriteFilexl {
	public static WebDriver driver;

	public static  void wrtxl(String s, int i ,int j) throws Exception {
		File file = new File("C:\\Users\\dt21271\\Desktop\\create.xlsx");
	    FileInputStream inputStream = new FileInputStream(file);
	    XSSFWorkbook wb=new XSSFWorkbook(inputStream);
	    XSSFSheet sheet=wb.getSheet("divya");
	    Row row = sheet.createRow(i);
	    Cell cell = row.createCell(j);
	    cell.setCellValue(s);
	    FileOutputStream fos = new FileOutputStream("C:\\Users\\dt21271\\Desktop\\create.xlsx");
	    wb.write(fos);
	    wb.close();
		
	}

public static void read(int i, int j,WebElement a) throws IOException {
	FileInputStream fis = new FileInputStream("C:\\Users\\dt21271\\Desktop\\Input.xlsx");
	XSSFWorkbook workbook = new XSSFWorkbook(fis);
	XSSFSheet sheet = workbook.getSheet("divya");
//I have added test data in the cell A1 as "SoftwareTestingMaterial.com"
//Cell A1 = row 0 and column 0. It reads first row as 0 and Column A as 0.
	Row row = sheet.getRow(i);
	Cell cell = row.getCell(j);
	//System.out.println(cell);

	for(j=0;j<1;j++)
	{
		a.sendKeys(sheet.getRow(i).getCell(j).getStringCellValue());
	}

	System.out.println(sheet.getRow(i).getCell(j));

	//String cellval = cell.getStringCellValue();

	//System.out.println(cellval);

	 

	}
public static void screenshot() throws Exception {
	 File screen = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
	 File Destination = new File("C:\\Users\\dt21271\\eclipse-workspace\\Maven\\Screenshots\\3.png");
     FileUtils.copyFile(screen, Destination);
//     String filepath = Destination.toString();
//     String path = "<br><img src='\"+filepath+\"' height='1000' width='1000'/><br>";

Reporter.log("\"<a href="+ Destination.getAbsolutePath() +"> <img src="+ Destination.getAbsolutePath() + " height='100' width='100'/> </a>\"");
}
}

