package com.Insider.pageFactoryInitilization;

import org.openqa.selenium.support.PageFactory;

import com.Insider.FunctionalLibrary.GenericMethods;
import com.Insider.Pages.CareerPage;
import com.Insider.Pages.HomePage;
import com.Insider.Pages.LeverAppFormPage;





public class PageElementsInitialization extends GenericMethods {


	// Home page elements initialization
	public void homePageObjectory() {

		PageFactory.initElements(driver, HomePage.class);
	}
	
	// Career page elements initialization
		public void careerPageObjectory() {

			PageFactory.initElements(driver, CareerPage.class);
		}

	// Liver Application Form page elements initialization
	public void leverFormPageObjectory() {

		PageFactory.initElements(driver, LeverAppFormPage.class);
	}

}
