package com.Insider.Utilities;

public class ConstantUtils {

	public static String projectPath = System.getProperty("user.dir");

    
	/* Paths Section */
	public static final String screenShotPath = projectPath + "/ScreenShots/";

	public static final String propertyFilePath = "./Object_Repository/EnvironmentProperties.properties";

	public static final String extentReportsPath = "./ExtentReports/ ";

	public static final String ieServerPath = projectPath + "/BrowserServers/IEDriverServer.exe";
	
	public static final String launchFakeMailSite = "window.open('https://www.fakemail.net/','_blank');";
	
	public static final String launchStagingApp = "window.open('https://staging-app.pigeonlab.tech','_blank');";
	
	public static final String locatorOkPath = projectPath + "/LocatorImages/OK.jpg";
	
	public static final String locatorSetNewPasswordPath = projectPath + "/LocatorImages/SetNewPassword.jpg";
	
	public static final String locatorVerifyYourEmailPath = projectPath + "/LocatorImages/VerifyYourEmail.jpg";
	
	public static final String locatorLogoutDropdownPath = projectPath + "/LocatorImages/logoutDropdown.jpg";
	
	public static final String launchAccountApp = "window.open('https://staging-dashboard.pigeonlab.tech/account/setting')";
	
	public static final String switchToFakeMailSite = "https://www.fakemail.net";
	
	public static final String launchNewTabWithImage = "window.open('https://www.google.com/search?q=dogs+images&rlz=1C1CHBF_enIN892IN892&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjc2MX36urpAhXUlOYKHdCwCLIQ_AUoAXoECBMQAw&cshid=1591365704228837&biw=982&bih=710&dpr=1.25','_blank');";
	
    public static final String imagePath = projectPath +"\\Images\\saved.png";
	
	public static final String cdImageURL = "window.open('https://f.rainforestqa.com/141192?mac=Rye07n')";

	public static final String avacodoImageURL = "window.open('https://f.rainforestqa.com/141193?mac=cCyoLR')";

	public static final String carrotImageURL = "window.open('https://f.rainforestqa.com/141194?mac=AIDPNL')";

	public static final String tomotoImageURL = "window.open('https://f.rainforestqa.com/141195?mac=TrERpA')";

	public static final String cucumberImageURL = "window.open('https://f.rainforestqa.com/141196?mac=d3iL97')";

	public static final String questionImageURL = "window.open('https://f.rainforestqa.com/141197?mac=N%2FkGJ0')";
	
	public static final String answerOneImageURL = "window.open('https://f.rainforestqa.com/141200?mac=e%2B3fFZ')";
	
	public static final String answerTwoImageURL = "window.open('https://f.rainforestqa.com/141199?mac=OW%2FEs3')";
	
	public static final String answerThreeImageURL = "window.open('https://f.rainforestqa.com/141202?mac=vcbawx')";
	
	public static final String answerFourImageURL = "window.open('https://f.rainforestqa.com/141204?mac=Cy6fSu')";
	
	public static final String answerFiveImageURL = "window.open('https://f.rainforestqa.com/141203?mac=svDKC8')";

	public static final String locatorOpenPath ="./LocatorImages/Open.jpg";
	
	public static final String locatorSavePath = "./LocatorImages/save.png";
	
	public static final String locatorSaveAsPath = "./LocatorImages/SaveAsImg.png";
	
	public static final String wordCloudExcelSaveLocation = projectPath + "\\ExcelDocuments\\WordcloudSession.xlsx";
	
	public static final String quizPresenterExcelDownloadsLocation = projectPath + "\\ExcelDocuments\\QuizPresenter.xlsx";
	
	public static final String quizPresenterExcelReadDownloadsFile = projectPath + "\\ExcelDocuments\\QuizPresenter.xlsx";
	
	public static final String quizPresenterExcelSaveLocation = projectPath + "\\ExcelDocuments";
	
	public static final String quizPresenterPDFSaveLocation = projectPath + "\\PDFDocuments\\QuizPresenter.pdf";


	/* Test Inputs */
	public static final String waitTime = "300";

	public static final int sychronizationTime = 2000;

	public static final int timeOut = 20;
	
}
