package com.Insider.Utilities;

public class ApplicationTittles {
	
	public static final String homePageTitle = "Insider personalization engine for seamless customer experiences";
	public static final String carreerPageTitle = "2018 Asia Leadership Conference - Agenda - Pigeonhole Live Dashboard";
}
