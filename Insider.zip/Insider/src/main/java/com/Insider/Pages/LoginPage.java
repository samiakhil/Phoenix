package com.Insider.Pages;

import com.Insider.FunctionalLibrary.GenericMethods;

public class LoginPage extends GenericMethods {
	
	

}
