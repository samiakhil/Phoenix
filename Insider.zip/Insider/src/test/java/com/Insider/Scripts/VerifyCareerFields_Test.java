package com.Insider.Scripts;

import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.Insider.DataHelper.TestDataGenerator;
import com.Insider.FunctionalLibrary.GenericMethods;
import com.Insider.Pages.CareerPage;
import com.Insider.Utilities.Logs;
import com.Insider.pageFactoryInitilization.PageElementsInitialization;


public class VerifyCareerFields_Test extends GenericMethods {

	/* Objects Declaration Section */
	public CareerPage careerPage;
	public PageElementsInitialization elementsInitialization;

	/* Test Input Data Section */
	String url = "insider_url";
	String sessionName = TestDataGenerator.randomSessionName;
	String description = TestDataGenerator.description;
	String locationName = TestDataGenerator.randomAddress;
	String tagFieldTextOne = "Apple";
	String tagFieldTextTwo = "StrawBerry";
	String lableName = "Panel Discussion";
	String buttonText = "Join Panel Discussion";

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		System.out.println("Brower " + browser);
		Logs.initLogs(VerifyCareerFields_Test.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		GenericMethods.openBrowser(browser);
		GenericMethods.pageLoadTimeOuts();
		GenericMethods.implicitTimeOut();
		GenericMethods.navigateAppUrl(url);
		Logs.info("App Url Navigated");

		careerPage = new CareerPage();
		elementsInitialization = new PageElementsInitialization();

		elementsInitialization.homePageObjectory();
	
	}

	/* Check Locations and Insider Blocks on Career page */
	@Test(priority = 1)
	public void verifyCareerChecks() throws Throwable {
		
		careerPage.checkLocations();
		GenericMethods.sychronizationinterval();
		/*Assert.assertEquals( GenericMethods.titleValidation(),ApplicationTittles.carreerPageTitle,
				"Title validation failed");
		GenericMethods.waitForElementToVisible(CareerPage.locationsHeaderText);
		GenericMethods.elementToBePresent(CareerPage.locationsHeaderText);
		Assert.assertEquals(sessionName, GenericMethods.getTextOfElement(CareerPage.locationsTextField));
		Logs.debug("Navigated to careerPage and contains header like 'Our Locations'");*/
	}

	/* filling up details regarding QA Session like AgendaInformation, Tags,
	  AdvanceCustomisation */
	/*@Test(priority = 2)
	public void fillNewQAsession() throws Throwable {

		sessionPage.fillUpAgendaInformation(sessionName, description, locationName);
		Logs.debug("Entered all details like sessionName, description, locationName");
		GenericMethods.waitForElementToVisible(SessionPage.tagsFiled);
		Logs.debug("Two tags fields was found");
		sessionPage.addTags(tagFieldTextOne, tagFieldTextTwo);
		Logs.debug("Two tags have been added");
		sessionPage.addAdvanceCustomisation(lableName, buttonText);
		Logs.debug("Displayed 'Panel Discussion' and 'Join Panel Discussion' on the Audience Web App preview");
		sessionPage.clickOnAddQAButton();
		GenericMethods.waitForElementToVisible(AgendaPage.sessionNameTextField);
		Assert.assertEquals(sessionName, GenericMethods.getTextOfElement(AgendaPage.sessionNameTextField));
		Logs.debug("Created Q&A session name in the agenda list");
	}
*/
	/* Method for quit driver session */
	@AfterClass
	public void quitDriversession() {

		GenericMethods.CloseDriverSession();
		Logs.endTestCase(this.getClass().getSimpleName());
	}
}
