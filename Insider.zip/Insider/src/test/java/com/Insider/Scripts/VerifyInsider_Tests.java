package com.Insider.Scripts;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.Insider.FunctionalLibrary.GenericMethods;
import com.Insider.Pages.CareerPage;
import com.Insider.Pages.HomePage;
import com.Insider.Pages.LeverAppFormPage;
import com.Insider.Utilities.ApplicationTittles;
import com.Insider.Utilities.Logs;
import com.Insider.pageFactoryInitilization.PageElementsInitialization;


public class VerifyInsider_Tests extends GenericMethods {
	
	/* Objects Declaration Section */
	public HomePage homePage;
	public CareerPage careerPage;
	public LeverAppFormPage leverAppFormPage;
	public PageElementsInitialization elementsInitialization;


	/* Test Input Data Section */
	String url = "insider_url";

	/* Launch the browser and navigate the Application */
	@BeforeClass
	@Parameters("browser")
	public void appLaunch(String browser) {

		Logs.initLogs(VerifyInsider_Tests.class.getName());
		Logs.startTestCase(this.getClass().getSimpleName());

		GenericMethods.openBrowser(browser);
		GenericMethods.pageLoadTimeOuts();
		GenericMethods.implicitTimeOut();
		GenericMethods.navigateAppUrl(url);
		Logs.info("App Url Navigated");

		homePage = new HomePage();
		careerPage = new CareerPage();
		leverAppFormPage = new LeverAppFormPage();
		
		
		elementsInitialization = new PageElementsInitialization();
		elementsInitialization.homePageObjectory();
		elementsInitialization.careerPageObjectory();
		elementsInitialization.leverFormPageObjectory();
	
	}
	
	/* Verify the Home page Title */
	@Test(priority =1)
	public void verifyHomePage() throws Throwable {
		System.out.println("Title: = " + GenericMethods.titleValidation());
		Assert.assertEquals( GenericMethods.titleValidation(),ApplicationTittles.homePageTitle,
				"Title validation failed");
		Logs.debug("Successfully naviagted to Home page");
	}

	/* Verify the Career Page: Locations, Teams and Life at Insider blocks */
	@Test(priority = 2)
	public void verifyCareerChecks() throws Throwable {
		
		careerPage.checkLocations();
		GenericMethods.sychronizationinterval();		
	}
}
