package package1;

import java.util.Scanner;

//Program to Find the Largest and Smallest Word in a String
public class Task11 {
	
	public static void largest_smallest(String str)
	{
		int max=0;
		int min=str.length();
		String lw="";
		String sw="";
		String[] s=str.split(" ");
		for(String s1:s)
		{
			System.out.println(s1+":"+s1.length());
		}
		
		for(int i=0;i<s.length;i++)
		{
				if(s[i].length()>max)
				{
					max=s[i].length();
					lw=s[i];
					
				}
				if(s[i].length()<min)
				{
					min=s[i].length();
					sw=s[i];
					
		        }	
		}	
		System.out.println("The largest length of the word is:"+lw);
		System.out.println("The smallest length of the word is:"+sw);
		
	}
	

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		largest_smallest(str);

	}

}
