package package1;

import java.util.Scanner;

//Program to Swap two String Variables Without Using Third or Temp Variable

public class Task12 {
	
	public void swapping(String str,String str1)
	{
		System.out.println("The original strings are:"+str+" "+str1);
		str=str+str1;
		str1=str.substring(0,(str.length()-str1.length()));
		str=str.substring(str1.length());
		System.out.println("After swapping the strings are:"+str+" "+str1);
	}

	public static void main(String[] args) {
		Task12 obj=new Task12();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first string:");
		String first_string = sc.nextLine();
		System.out.println("Enter second string:");
		String second_string = sc.nextLine();
		obj.swapping( first_string,second_string);

	}

}
