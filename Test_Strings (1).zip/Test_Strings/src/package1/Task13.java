package package1;

import java.util.Scanner;

//Write a Java program to get the character at the given index within the String
public class Task13 {
	
	public static void character_index(String str,int index)
	{
		char[] c=str.toCharArray();
		System.out.print("The character at "+" "+index+" "+"the index is:");
		for(int i=0;i<str.length();i++)
		{
			if(i==index)
			System.out.println(c[i]);
		}
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter index of a string:");
	     int index = sc1.nextInt();
		character_index(str,index);

	}

}
