package package1;

import java.util.Scanner;

//Program to Find Reverse of a String

public class Task7 {
	
	public static void reverse_string(String str)
	{
		String rev="";
		
		for(int i=str.length()-1;i>=0;i--)
		{
			rev=rev+str.charAt(i);
		}
		System.out.println("The reverse string is:"+rev);
	}

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String str=sc.next();
		reverse_string(str);
		

	}

}
