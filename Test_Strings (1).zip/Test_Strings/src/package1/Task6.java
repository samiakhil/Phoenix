package package1;

import java.util.Scanner;

//Program to Find Maximum and Minimum Occurring Character in a String
public class Task6 {
	
	public static void maxiumMinium(String str)

	{
		char[] c=str.toCharArray();
		int count;
		for(int i=0;i<str.length();i++)
		{
			for(int j=i+1;j<str.length();j++) {
			count =0;
			if(c[i]==c[j])
			{
				count++;
				
			}		
		 }
			
		}
		
	}
	

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		maxiumMinium(str);
		

	}

}
