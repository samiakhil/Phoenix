package package1;

//Program to remove all the white spaces from a string
public class Task1_Removewhitespaces {
	
	public void remove_Spaces()
	{
		String s = "Java   Program";
		int c=0;
		String[] s1 = s.split(" ");
		for (String s2:s1) {
			
			System.out.print(s2);
			
		}
	}

	public static void main(String[] args) {

		Task1_Removewhitespaces obj=new Task1_Removewhitespaces();
		obj.remove_Spaces();

	}

}
