package package1;

import java.util.Scanner;

//Write a Java program to replace all the 'd' characters with 'f'
public class Task14 {
	
	public static String replace(String str)
	{
		str=str.replace("d","f");
		return str;
		
	}

	public static void main(String[] args) {
		
		Task14 obj=new Task14();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		System.out.println("The replace of a string is:"+replace(str));

	}

}
