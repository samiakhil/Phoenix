package package1;

import java.util.Arrays;
import java.util.Scanner;

//Write a Java program to find the second most frequent character in a given string
public class Task15 {

	public static void second_frequency_characters(String str) {

		char[] c = str.toCharArray();
		int newarray[]=new int[str.length()];
		int count;
		System.out.print("The frequency of  characters in a given string is:");
		for (int i = 0; i < str.length(); i++) {
			 count = 0;
			 newarray[i]=1;
			for (int j = i + 1; j < str.length(); j++) {
				if (c[i] == c[j]) {
					count++;
					newarray[i]++;
					c[j]='&';
				}
			}
		}
		
       for(int i=0;i<newarray.length;i++)
       {
		 if (newarray[i]!=' '&& c[i]!='&') 
		 {
			 System.out.print(c[i] + ":"+newarray[i]+" ");
			Arrays.toString(newarray);
			 
		 }
		 
	 }
       System.out.println();
       System.out.println("The second frequency of  characters in a given string is:"+newarray[1]);
		
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		second_frequency_characters(str);
		
		
		
		
	}

}
