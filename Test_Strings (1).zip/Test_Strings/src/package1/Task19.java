package package1;

import java.util.Scanner;

//Java Program to remove Special Characters From Given String

public class Task19 {
	
	public static void remove_Special(String str)
	{
		char[] c=str.toCharArray();
		System.out.print("After removing of special characters is:");
		for(int i=0;i<str.length();i++)
		{
			int alpha= (int)c[i];
			if(alpha>=97&&alpha<=122)
			{
				System.out.print(c[i]);
			}
			else if(alpha>=65&&alpha<=90)
			{
				System.out.print(c[i]);
			}
		}
		
	}

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		remove_Special(str);

	}

}
