package package1;

import java.util.Scanner;

//Program to Determine Whether a Given String is Palindrome
public class Task5 {
	
	public static void palindrome(String str)
	{
		String rev="";
		
		for(int i=str.length()-1;i>=0;i--)
		{
			rev=rev+str.charAt(i);
		}
		System.out.println("The reverse string is:"+rev);
		
		if(str.equalsIgnoreCase(rev))
		{
			System.out.println("The given string is palindrome");
			
		}
		else 
		{
			System.out.println("The given string is  not palindrome");
			
		}
		
	}

	public static void main(String[] args) {
		
		Task5 obj=new Task5();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String str=sc.next();
		obj.palindrome(str);

	}

}
