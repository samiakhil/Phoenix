package package1;

import java.util.Arrays;
import java.util.Scanner;

//Java Program to Find First Not Repeated Character

public class Test24 {

	public static void nonrepeated_characters(String str) {
	
		int count;
		char x=' ';
		System.out.print("The first non repeated character in a given string is:");
		for (int i = 0; i < str.length(); i++) {
			 count = 0;
			 x=str.charAt(i);
			for (int j = 0; j < str.length(); j++) {
				if (x==str.charAt(j)) {
					count++;
					
				}
			}
			if(count==1)
			{
				break;
			}
			count=0;
		}
		System.out.println(x);
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		nonrepeated_characters(str);
		
		
		

	}

}
