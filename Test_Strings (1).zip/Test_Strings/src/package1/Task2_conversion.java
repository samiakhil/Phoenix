package package1;

import java.util.Scanner;

/*
  Program to replace lower-case characters with upper-case and vice 
versa
*/
public class Task2_conversion {
	
	public  String lowerCase(String str)
	{
		String s=str.toLowerCase();
		
		return s;
	}
	public  String upperCase(String str)
	{
		String s=str.toUpperCase();
		
		return s;
	}
	
	public static void main(String[] args) {
		
		Task2_conversion obj=new Task2_conversion();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String str=sc.next();
		System.out.println("The lower case of string is:"+obj.lowerCase(str));
		System.out.println("The upper case of string is:"+obj.upperCase(str));
		
		
	}
	
	
	

}
