package package1;

import java.util.Scanner;

//Program to Count the Total Number of Characters in a String
public class Task4 {

	public static void total_Characters(String s) {

		int c = 1;
		String s1 = s.replaceAll("\\s","");
		for (int i = 0; i < s1.length()-1; i++) {
			c++;

		}
		System.out.print("The total number of characters in a given string:" + c);
	}

	public static void main(String[] args) {

		Task4 obj = new Task4();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		total_Characters(str);

	}

}
