package package1;

import java.util.Scanner;

//Program to replace the spaces of a string with a specific character

public class Task3 {
	
	public static void replace_spaces(String str)
	{
		str = str.replace(" ","-");
		System.out.println(str);
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		replace_spaces(str);

	}

}
