package package1;

import java.util.Scanner;

// Program to Find the Duplicate Words in a String
public class Task9 {

	public static void duplicate_words(String str) {
         
		int count ;
		String str1[]=str.split(" ");
		//System.out.print("The duplicate words in a given string is:");
		for (int i = 0; i < str1.length; i++) {
			 count = 1;
			for (int j = i + 1; j < str1.length; j++) {
				if (str1[i].equals(str1[j])) 
				{
					count++;
					str1[j]="&";
				}
			}
			System.out.print("The duplicate words in a given string is:");
			     if (count>1&&str1[i]!="&") 
			      {
				     System.out.print(str1[i] + " ");
			      }
			     else
			     {
			    	 System.out.println("No duplicates");
			    	 break;
			     }
		 }			
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		duplicate_words(str);

}
}
