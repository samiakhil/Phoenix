package package1;

import java.util.Arrays;
import java.util.Scanner;

//Java Program to replace Character with its occurrence
public class Task25 {

	public static void replace_characters(String str) {

		char[] c = str.toCharArray();
		int newarray[]=new int[str.length()];
		int count;
		System.out.println("Replace of  characters with its occurance:");
		for (int i = 0; i < str.length(); i++) {
			 count = 0;
			 newarray[i]=1;
			for (int j = i + 1; j < str.length(); j++) {
				if (c[i] == c[j]) {
					count++;
					newarray[i]++;
					c[j]='&';
				}
			}
		}
       for(int i=0;i<newarray.length;i++)
       {
		 if (newarray[i]!=' '&& c[i]!='&') 
		 {
			 System.out.print(newarray[i]);
		 }
	 }

		
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		replace_characters(str);
		
		
	}
}
