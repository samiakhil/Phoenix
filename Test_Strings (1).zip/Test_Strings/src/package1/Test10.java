package package1;

import java.util.Scanner;

//Program to Find the Frequency of Characters
public class Test10 {

	public static void frequency_characters(String str) {

		char[] c = str.toCharArray();
		int newarray[]=new int[str.length()];
		int count;
		System.out.println("The frequency of  characters in a given string is:");
		for (int i = 0; i < str.length(); i++) {
			 count = 0;
			 newarray[i]=1;
			for (int j = i + 1; j < str.length(); j++) {
				if (c[i] == c[j]) {
					count++;
					newarray[i]++;
					c[j]='&';
				}
			}
		}
       for(int i=0;i<newarray.length;i++)
       {
		 if (newarray[i]!=' '&& c[i]!='&') 
		 {
			 System.out.print(c[i] + ":"+newarray[i]+" ");
		 }
	 }

		
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		frequency_characters(str);
		
		
	}
}
