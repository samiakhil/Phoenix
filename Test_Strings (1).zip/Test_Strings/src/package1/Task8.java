package package1;

import java.util.Arrays;
import java.util.Scanner;

// Program to Find the Duplicate Characters in a String

public class Task8 {

	public static void duplicate_characters(String str) {

		char[] c = str.toCharArray();
		System.out.print("The duplicate characters in a given string is:");
		for (int i = 0; i < str.length(); i++) {
			int count = 0;
			for (int j = i + 1; j < str.length(); j++) {
				if (c[i] == c[j]) {
					count++;
					c[j]='&';
				}
			}

		 if (count!=0&& c[i]!='&') 
		 {
			 System.out.print(c[i] + " ");
		}
		 }
	}

	public static void main(String[] args) {

		Task8 obj = new Task8();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.next();
		duplicate_characters(str);

	}

}
