package package1;

import java.util.Scanner;

//How to Reverse A string 4 Different ways in java?
public class Task18 {
	

	public static void reverse_string(String str)
	{
		String rev="";
		
		for(int i=str.length()-1;i>=0;i--)
		{
			rev=rev+str.charAt(i);
		}
		System.out.println("The reverse string is:"+rev);
	}
	
	public static void reverse_Method(String str)
	{
		StringBuilder sb=new StringBuilder(str);
		System.out.println("The reverse string is:"+sb.reverse());
		
	}
	
	public static void reverse1(String str)
	{
		char[] c=str.toCharArray();
		String rev="";
		
		for(int i=0;i<str.length();i++)
		{
			rev=c[i]+rev;
		}
		System.out.print("The reverse string is:"+rev);			
	}

	public static void main(String[] args) {

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter string:");
		String str=sc.next();
		reverse_string(str);
		reverse_Method(str);
		reverse1(str);
	}

}
