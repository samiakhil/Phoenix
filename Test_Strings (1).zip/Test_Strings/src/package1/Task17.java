package package1;

/*Given Stiring replace 
Input : a b c d e f 
Output: a f c d e b*/

public class Task17 {

	public static void main(String[] args) {
		
		String s="abcdef";
		char[] str=s.toCharArray();
		
		for(int i=0;i<s.length();i++)
		{
			if(str[i]=='b')
			{
				str[i]='f';
			}
			else if(str[i]=='f')
			{
				str[i]='b';
			}
			System.out.print(str[i]);
		}

	}

}
