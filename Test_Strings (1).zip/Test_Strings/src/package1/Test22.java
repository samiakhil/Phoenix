package package1;

import java.util.Arrays;
import java.util.Scanner;

// Sort String Chracters in Alphabetical Order
public class Test22 {

	public static void sorting(String str)
	{
		char[] s=str.toCharArray();
		System.out.print("The sorting order is:");
		for(int i=0;i<str.length();i++) {	
			for(int j=i+1;j<str.length();j++)
			{
				char temp;
				
				if(s[i]>s[j])
				{
					temp=s[i];
					s[i]=s[j];
					s[j]=temp;
				}
		    }
			System.out.print(s[i]);
		}
		//Arrays.sort(s);
		//System.out.println(Arrays.toString(s));
	}
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string:");
		String str = sc.nextLine();
		sorting(str);

	}

}
