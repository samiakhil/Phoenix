/**
 * 
 */
/**
 * @author lm21187
 *
 */
module Test_Strings {
}