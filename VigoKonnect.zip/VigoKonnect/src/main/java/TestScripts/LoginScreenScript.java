package TestScripts;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.MarkupHelper;

import PageElements.VKT_UpdatePassword;
import Reusable.Customlisteners;
@Listeners(Customlisteners.class)
public class LoginScreenScript extends BASE{

	//----------------------------------------------Login Screen------------------------------------------------//

	@Test//(retryAnalyzer = Customlisteners.class)
	//1.Clicking on forgot password
	public void VKTTS05TC001() throws Exception {
		System.out.println("===============VKTTS05TC001 started =======================");
		OpenVKT_UsernameLogin();
		Click_Element(driver,VKT_ForgetPassword);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKTLoginPopUp");
		Assert_TextValue("Please contact your Admin",
				GetText(driver,VKT_ErrorMsg));
		Click_Element(driver,VKT_ContactAdminPopUp);

	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 2.Leaving all fields empty and click update.
	public void VKTTS05TC002() throws Exception {
		System.out.println("===============VKTTS05TC002 started =======================");
		OpenVKT_UsernameLogin();
		EnterText(driver, VKT_Username_TextBox, vspAssociateName);
		EnterData(driver, VKT_Password_TextBox, "VKPWD");
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		Click_Element(driver, VKT_LoginButton);
		implicitWait(driver,9000);
		TakeScreenshot(driver, "VKT_UpdatePasswordScreen");
		Click_Element(driver, VKT_UpdatePassword.VKT_UpdateButton);
		implicitWait(driver,1000);
		TakeScreenshot(driver, "VKT_UpdateNewPasswordAlert");
		Assert_TextValue("Please enter new password",
				GetText(driver, VKT_UpdatePassword.VKT_UpdateAlertNewPwd));
		Customlisteners.extenttest.pass("Validation success");
		driver.resetApp();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 3.Filling password with less than 6 characters and click update.
	public void VKTTS05TC003() throws Exception {
		System.out.println("===============VKTTS05TC003 started =======================");
		OpenVKT_UsernameLogin();
		EnterText(driver, VKT_Username_TextBox, vspAssociateName);
		EnterData(driver, VKT_Password_TextBox, "VKPWD");
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		Click_Element(driver, VKT_LoginButton);
		implicitWait(driver, 9000);
		TakeScreenshot(driver, "VKT_UpdatePasswordScreen");
		EnterText(driver, VKT_UpdatePassword.VKT_NewPassword, "chan");
		implicitWait(driver, 1000);
		EnterText(driver, VKT_UpdatePassword.VKT_ConfirmPassword, "chan");
		Click_Element(driver, VKT_UpdatePassword.VKT_UpdateButton);
		implicitWait(driver, 1000);
		TakeScreenshot(driver, "VKT_UpdateNewPasswordAlert");
		Assert_TextValue("New password length should be of minimum 6 characters",
				GetText(driver, VKT_UpdatePassword.VKT_UpdateAlertError));
		driver.resetApp();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 4.Filling with mismatch passwords and click update.
	public void VKTTS05TC004() throws Exception {
		System.out.println("===============VKTTS05TC004 started =======================");
		OpenVKT_UsernameLogin();
		EnterText(driver, VKT_Username_TextBox, vspAssociateName);
		EnterData(driver, VKT_Password_TextBox, "VKPWD");
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		Click_Element(driver, VKT_LoginButton);
		implicitWait(driver, 9000);
		TakeScreenshot(driver, "VKT_UpdatePasswordScreen");
		EnterText(driver, VKT_UpdatePassword.VKT_NewPassword, "change");
		implicitWait(driver, 1000);
		EnterText(driver, VKT_UpdatePassword.VKT_ConfirmPassword, "changeme");
		Click_Element(driver, VKT_UpdatePassword.VKT_UpdateButton);
		implicitWait(driver, 1000);
		TakeScreenshot(driver, "VKT_UpdateNewPasswordAlert");
		Assert_TextValue("New password and confirm password are not matching",
				GetText(driver, VKT_UpdatePassword.VKT_UpdateAlertMismatchError));
		driver.resetApp();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 5.Logging in with valid credentials , password update -filling one 
	//field(new password or confirm password) and click update.
	public void VKTTS05TC005() throws Exception {
		System.out.println("===============VKTTS05TC005 started =======================");
		OpenVKT_UsernameLogin();
		EnterText(driver, VKT_Username_TextBox, vspAssociateName);
		EnterData(driver, VKT_Password_TextBox, "VKPWD");
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		Click_Element(driver, VKT_LoginButton);
		implicitWait(driver, 9000);
		TakeScreenshot(driver, "VKT_UpdatePasswordScreen");
		EnterText(driver, VKT_UpdatePassword.VKT_NewPassword, "changeme");
		implicitWait(driver, 1000);
		Click_Element(driver, VKT_UpdatePassword.VKT_UpdateButton);
		implicitWait(driver, 3000);
		TakeScreenshot(driver, "VKT_UpdateNewPasswordAlert");
		Assert_TextValue("Please enter confirm password",
				GetText(driver, VKT_UpdatePassword.VKT_UpdateAlertConfirmNewPwd));
		EnterText(driver, VKT_UpdatePassword.VKT_NewPassword, "");
		EnterText(driver, VKT_UpdatePassword.VKT_ConfirmPassword, "changeme");
		Click_Element(driver, VKT_UpdatePassword.VKT_UpdateButton);
		implicitWait(driver, 1000);
		TakeScreenshot(driver, "VKT_UpdateNewPasswordAlert");
		Assert_TextValue("Please enter new password",
				GetText(driver, VKT_UpdatePassword.VKT_UpdateAlertNewPwd));
		driver.resetApp();
	}

	@Test////(retryAnalyzer = Customlisteners.class)
	// 6.Filling all fields with valid input , click login ,enter valid password
	public void Login_Vsp() throws Exception {
		System.out.println("===============Login_Vsp (VKTTS05TC006) started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 7.Filling all fields with valid inputs and click login 
	public void VKTTS05TC007() throws Exception {
		System.out.println("===============VKTTS05TC007 started =======================");
		OpenVKT_UsernameLogin();
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 8.Leaving one field empty and click login.
	public void VKTTS05TC008() throws Exception {
		System.out.println("===============VKTTS05TC008 started =======================");
		OpenVKT_UsernameLogin();
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		EnterText(driver, VKT_Username_TextBox, vspAssociateName);
		Click_Element(driver, VKT_LoginButton);
		implicitWait(driver, 1000);
		TakeScreenshot(driver, "VKT_LoginErrorAlert");
		Assert_TextValue("Please enter password",
				GetText(driver,VKT_PasswordError));
		EnterText(driver, VKT_Username_TextBox, "");
		EnterText(driver, VKT_Password_TextBox, "changeme");
		Click_Element(driver, VKT_LoginButton);
		implicitWait(driver, 1000);
		TakeScreenshot(driver, "VKT_LoginErrorAlert");
		Assert_TextValue("Please enter username",
				GetText(driver,VKT_UserNameError));
		EnterText(driver, VKT_Password_TextBox, "");
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 9.Leaving all fields empty and click login.
	public void VKTTS05TC009() throws Exception {
		System.out.println("===============VKTTS05TC009 started =======================");
		OpenVKT_UsernameLogin();
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		Click_Element(driver, VKT_LoginButton);
		implicitWait(driver, 1000);
		TakeScreenshot(driver, "VKT_LoginErrorAlert");
		Assert_TextValue("Please enter username", GetText(driver, VKT_UserNameError));
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 10.Filling one field with wrong input and click login.
	public void VKTTS05TC010() throws Exception {
		System.out.println("===============VKTTS05TC010 started =======================");
		OpenVKT_UsernameLogin();
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		EnterText(driver, VKT_Username_TextBox, vspAssociateName);
		EnterText(driver, VKT_Password_TextBox, "change");
		Click_Element(driver, VKT_LoginButton);
		Thread.sleep(3000);
		TakeScreenshot(driver, "VKT_LoginErrorAlert1");
		Assert_TextValue("Incorrect password. Please try again.", 
				GetText(driver, VKT_IncorrectPwd));
		Thread.sleep(1000);
		EnterText(driver, VKT_Username_TextBox, "userDoesnotExistTest");
		EnterText(driver, VKT_Password_TextBox, "changeme");
		Click_Element(driver, VKT_LoginButton);
		Thread.sleep(3000);
		TakeScreenshot(driver, "VKT_LoginErrorAlert2");
		Assert_TextValue("User Doesn't Exist.", 
				GetText(driver, VKT_UserDoesnotExistError));

	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 11.Filling all valid credentials for VSE Admin and login and update password
	public void Login_Vse() throws Exception {
		System.out.println("===============Login_Vse (VKTTS05TC011) started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}



	//Mobile Number
	@Test//(retryAnalyzer = Customlisteners.class)
	//12. Leaving empty mobile number and login
	public void VKTTS05TC012() throws Exception{
		System.out.println("===============VKTTS05TC012 started =======================");
		Thread.sleep(1000);
		Click_Element(driver,VKT_Mobile_Number_Button);
		TakeScreenshot(driver,"VigoKonnectLoginScreen");
		Click_Element(driver,VKT_LoginButton);
		implicitWait(driver, 1000);
		Assert_TextValue("Please enter a valid mobile number",GetText(driver,VKT_ErrorMsg));
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//13. Filling mobile number with 9 or less numbers and login
	public void VKTTS05TC013() throws Exception{
		System.out.println("===============VKTTS05TC013 started =======================");
		Thread.sleep(1000);
		Click_Element(driver,VKT_Mobile_Number_Button);
		EnterRandomData(driver, VKT_MobileNumber_TextBox, "", "", 0, 9);
		TakeScreenshot(driver,"VigoKonnectLoginScreen");
		Click_Element(driver,VKT_LoginButton);
		//implicitWait(driver, 1000);
		Thread.sleep(1000);
		Assert_TextValue("Please enter a valid mobile number",GetText(driver,VKT_ErrorMsg));
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//14. Filling mobile number with 10 random numbers and login
	public void VKTTS05TC014() throws Exception{
		System.out.println("===============VKTTS05TC014 started =======================");
		Thread.sleep(1000);
		Click_Element(driver,VKT_Mobile_Number_Button);
		EnterRandomData(driver, VKT_MobileNumber_TextBox, "", "", 0, 10);
		TakeScreenshot(driver,"VigoKonnectLoginScreen");
		Click_Element(driver,VKT_LoginButton);
		implicitWait(driver, 1000);
		Assert_TextValue("User doesn't exist. Please contact Support Team.",GetText(driver,VKT_UserNotExist_Error));
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//15. Filling valid mobile number and login, OTP and verify
	public void VKTTS05TC015() throws Exception{
		System.out.println("===============VKTTS05TC015 started =======================");
		Thread.sleep(1000);
		Click_Element(driver,VKT_Mobile_Number_Button);
		EnterRandomData(driver, VKT_MobileNumber_TextBox, "VKT_MOBILE", "", 0, 0);
		TakeScreenshot(driver,"VigoKonnectLoginScreen");
		Click_Element(driver,VKT_LoginButton);
		implicitWait(driver, 1000);
		TakeScreenshot(driver,"VigoKonnectSendingOTPPage");
		driver.resetApp();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 16.Filling all valid credentials for Doctor and login
	public void Login_Doctor() throws Exception {
		System.out.println("===============Login_Doctor (VKTTS05TC016) started =======================");
		Login_VigoKonnect_Username(prop.getProperty("VKT_DOCTOR_UN"),"pass1234");
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}
}
