package TestScripts;

import org.testng.annotations.Test;

import com.google.common.collect.ImmutableMap;

import CommonPages.CaseCreation;
import PageElements.VKT_AddHospital;
import PageElements.VKT_DashboardPage;
import PageElements.VKT_PatientDetails;
import PageElements.VKT_RegisterPatient_Page;
import PageElements.VKT_Service_Pages;
import PageElements.VKT_SideMenu;
import PageElements.VKT_UpdatePassword;
import PageElements.VKT_LoginOTP_Page;
import PageElements.VKT_LogoutPage;

import static Reusable.Reusable.driver;
import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import java.time.Duration;
import java.util.Properties;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Ignore;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.json.JSONObject;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;


import Reusable.*;
import Reusable.Reusable.*;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.appium.java_client.TouchAction;

@Listeners(Customlisteners.class)
public class RegisterPatientScript extends BASE {
	String caseId;
	String pname;
	/*
	 * 			VSE Admin
	 */

	@Test//(retryAnalyzer = Customlisteners.class)  
	//1. Filling all fields, mobile number is not registered earlier and creating a case
	public void vse_Admin_Registerpatient() throws Exception{
		System.out.println("===============vse_Admin_Registerpatient (VKTTS03TC001) started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		caseId=getVSEPatientCaseId(obj.firstName);
		Logout_VigoKonnect();
		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)	 
	//2.Filling only mandatory fields and creating a case
	public void VKTTS03TC002() throws Exception{
		System.out.println("===============VKTTS03TC002 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Thread.sleep(1000);
		//Register patient with mandatory fields only
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		obj.lastName="";
		obj.pincode="";
		RegisterPatient(obj);
		caseCreationSuccessPage();
		//for case id verificaion 
		caseId=getVSEPatientCaseId(obj.firstName);
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//3. Filling all fields, mobile number registered earlier and has no monitoring, and creating a case
	public void vse_Admin_existing_mobile_number_with_new_patientid () throws Exception {
		System.out.println("===============vse_Admin_existing_mobile_number_with_new_patientid (VKTTS03TC003) started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj= new CaseCreation();
		obj.doctor = vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		caseId=getVSEPatientCaseId(obj.firstName);
		caseDeletion(caseId);
		CMS_Logout();

		//Again opening Register patient tab
		obj.firstName = "automat"+Random_AlphaNumeric(4,0);
		RegisterPatient(obj);
		TakeScreenshot(driver, "Reopened Registerpatient page opened");
		caseCreationSuccessPage();

		caseId=getVSEPatientCaseId(obj.firstName);		
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class) 
	//4. Filling all fields, mobile number registered earlier and has monitoring
	public void VKTTS03TC004 () throws Exception {
		System.out.println("===============VKTTS03TC004 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj= new CaseCreation();
		obj.doctor = vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		//again entering mobile number 
		Click_Element(driver,VKT_RegisterPatient);
		Thread.sleep(1000);
		obj.FillMobileNumber();
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//5. Filling all fields and entering mobile number to which already cases are registered and there are currently no monitorings and we should be able to use the existing case ID.
	public void vse_Admin_existing_mobile_number_with_old_patientid () throws Exception {
		System.out.println("===============vse_Admin_existing_mobile_number_with_old_patientid (VKTTS03TC005) started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj= new CaseCreation();
		obj.doctor = vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		caseId=getVSEPatientCaseId(obj.firstName);
		caseDeletion(caseId);
		CMS_Logout();

		//Again opening Register patient tab
		obj.firstName ="";
		obj.lastName ="";
		RegisterPatient(obj);
		TakeScreenshot(driver, "Reopened Registerpatient page opened");
		caseCreationSuccessPage();

		caseId=getVSEPatientCaseId(obj.firstName);		
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//6. Filling all fields and number entered with 0 followed by mobile number
	public void VKTTS03TC006() throws Exception{
		System.out.println("===============VKTTS03TC006 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		//
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		obj.mobile="0"+obj.mobile;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		//for case id verificaion 
		caseId=getVSEPatientCaseId(obj.firstName);		
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)	 
	//7. Filling all fields and number entered with 0 followed by 9 numbers
	public void VKTTS03TC007() throws Exception{
		System.out.println("===============VKTTS03TC007 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		obj.mobile = 0 + "414"+Random_AlphaNumeric(0,6);
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter a valid mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();


	}

	@Test//(retryAnalyzer = Customlisteners.class)  
	//8. Filling all fields and enter number with 9 numbers or less
	public void VKTTS03TC008() throws Exception{
		System.out.println("===============VKTTS03TC008 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		int rvalue = Integer.parseInt(Random_AlphaNumeric(0,1));
		obj.mobile ="4"+Random_AlphaNumeric(0,rvalue-1);
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter a valid mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));

		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//9. Filling all fields and entered all same numbers for mobile number 
	public void VKTTS03TC009() throws Exception{
		System.out.println("===============VKTTS03TC009 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		obj.mobile="0000000000";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter a valid mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}

	@Test//(retryAnalyzer = Customlisteners.class)		 
	//10. Leaving all fields empty and creating a case
	public void VKTTS03TC010() throws Exception{
		System.out.println("===============VKTTS03TC010 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj = new CaseCreation();
		obj.EmptyAllFields();
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		TakeScreenshot(driver,"RegistrationPageWithEmptyDetails");
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}
	
	@Test//(retryAnalyzer = Customlisteners.class)  
	//11. filling only optional fields and creating a case
	public void VKTTS03TC011() throws Exception{
		System.out.println("===============VKTTS03TC011 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation obj = new CaseCreation();
		obj.EmptyAllFields();
		obj.lastName="test";
		obj.pincode="123456";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//12. Filling all fields, leaving one mandatory field and creating a case
	public void VKTTS03TC012() throws Exception{
		System.out.println("===============VKTTS03TC012 started =======================");
		Login_VigoKonnect_Username(vseAdminName);

		//Phone number not entered
		CaseCreation obj =new CaseCreation();
		obj.mobile="";
		obj.doctor=vseDoctorName;
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//first name is empty
		Login_VigoKonnect_Username(vseAdminName);
		obj.mobile= "414"+Random_AlphaNumeric(0,7);
		obj.firstName = "";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter first name",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//doctor not selected
		Login_VigoKonnect_Username(vseAdminName);
		obj.firstName = getTextFromProperties("VK_FNAME")+Random_AlphaNumeric(4,0);
		obj.doctor="";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please select a doctor",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//service not selected
		Login_VigoKonnect_Username(vseAdminName);
		obj.doctor = vseDoctorName;
		obj.service = "";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please select service",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//13. Filling all fields and service dropdown being empty as VSE haven’t subscribed to services.	
	public void VKTTS03TC013() throws Exception{
		System.out.println("===============VKTTS03TC013 started =======================");
		//API for unsubscribe
		String reqbody="{\"services\" : []}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.put("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vseid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully unsubscribed services");
		//
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation cobj = new CaseCreation();
		cobj.doctor=vseDoctorName;
		cobj.service= "";
		RegisterPatient(cobj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please select service",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//
		//API for subscription
		reqbody="{\"services\" : ["
				+ "{"
				+ "\"id\":\"6322ae6b1af70d0021da7e3e\","
				+ "\"name\":\"BBPBSPO2\""
				+ "},"
				+ "{"
				+ "\"id\":\"6369e3bf3c61f80022966520\","
				+ "\"name\":\"Vigo Life\""
				+ "},"
				+ "{"
				+ "\"id\":\"6396cc15aa09ed00249e6401\","
				+ "\"name\":\"testService\""
				+ "},"
				+ "{"
				+ "\"id\":\"6166b6c474eba30020255322\","
				+ "\"name\":\"SmartHeart\""
				+ "},"
				+ "{"
				+ "\"id\":\"611b8ec12e29f40020dac640\","
				+ "\"name\":\"BSM_Viatom\""
				+ "}]}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.put("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vseid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully subscribed services again");
		//
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//14. Filling all fields and no doctor in the dropdown to select and creating a case
	public void VKTTS03TC014() throws Exception{
		System.out.println("===============VKTTS03TC014 started =======================");
		String random4Dig=RandomStringUtils.random(4, false, true);
		//creating a VSE dummy
		String reqbody = "{"
				+ "\"firstName\":\"apiVSEDummy"+random4Dig+"\","
				+ "\"lastName\":\"\","
				+ "\"name\":\"apiVSEDummy"+random4Dig+"\","
				+ "\"licenseNumber\":\"123456\","
				+ "\"addressLine1\":\"addr1\","
				+ "\"addressLine2\":\"\","
				+ "\"pinCode\":\"123456\","
				+ "\"id\":\"\","
				+ "\"email\":\"\","
				+ "\"isServiceEnabler\":true,"
				+ "\"isActive\":true,"
				+ "\"loginId\":\"apiVSEDummy"+random4Dig+"\","
				+ "\"password\":\"changeme\","
				+ "\"website\":\"\","
				+ "\"location\":\"\","
				+ "\"reportPassword\":\"changeme\","
				+ "\"country\":\"INDIA\","
				+ "\"mobile\":"
				+ "{\"countryCode\":\"91\","
				+ "\"number\":\"9595959595\"},"
				+ "\"alternateMobile\":"
				+ "{\"countryCode\":\"\",\"number\":\"\"},"
				+ "\"note\":"
				+ "{\"reason\":\"\"},"
				+ "\"services\":[]}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/")
				.then()
				.statusCode(HttpStatus.SC_CREATED)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		String vseidDummy=obj.getString("_id");
		String serviceEnabler=obj.get("serviceEnabler").toString();
		String vseNameDummy=new JSONObject(serviceEnabler).getString("name");
		System.out.println("VSE Dummy name\t:"+vseNameDummy);

		//API for unlink doctor from VSE

		//mobile number from doctor VSE
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				//body()
				when()
				.header("Authorization","Bearer "+accessToken)
				.get("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vseDoctorId)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		String mobileNumber=obj.getJSONObject("mobile").getString("number");	//obj.get("mobile").toString();

		reqbody="{"
				+ "   \"businessPartners\": ["
				+ "        {"
				+ "            \"businessPartnerId\": \""+vseidDummy+"\","
				+ "            \"businessPartnerName\": \""+vseNameDummy+"\","
				+ "            \"displayName\": \""+vseDoctorName+"\","
				+ "            \"speciality\": \"Cardiology\","
				+ "            \"email\": \"\","
				+ "            \"isActive\": true,"
				+ "            \"location\": \"\","
				+ "            \"roles\": ["
				+ "                {"
				+ "                    \"role\": \"INTERNAL_DOCTOR\""
				+ "                }"
				+ "            ],"
				+ "            \"isDeleted\": false,"
				+ "            \"deletedBy\": {},"
				+ "            \"providerNumber\": \"\","
				+ "            \"isServiceEnabler\": false,"
				+ "            \"country\": \"INDIA\""
				+ "        }"
				+ "    ],"
				+ "    \"mobile\": {"
				+ "        \"countryCode\": \"91\","
				+ "        \"number\": \""+mobileNumber+"\""
				+ "    }"
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vseDoctorId)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully unlinked doctor");
		//
		Login_VigoKonnect_Username(vseAdminName);
		CaseCreation cobj= new CaseCreation();
		cobj.doctor="";
		RegisterPatient(cobj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please select a doctor",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//
		//API for link again
		reqbody="{"
				+ "   \"businessPartners\": ["
				+ "        {"
				+ "            \"businessPartnerId\": \""+vseid+"\","
				+ "            \"businessPartnerName\": \""+vseName+"\","
				+ "            \"displayName\": \""+vseDoctorName+"\","
				+ "            \"speciality\": \"Cardiology\","
				+ "            \"email\": \"\","
				+ "            \"isActive\": true,"
				+ "            \"location\": \"\","
				+ "            \"roles\": ["
				+ "                {"
				+ "                    \"role\": \"INTERNAL_DOCTOR\""
				+ "                }"
				+ "            ],"
				+ "            \"isDeleted\": false,"
				+ "            \"deletedBy\": {},"
				+ "            \"providerNumber\": \"\","
				+ "            \"isServiceEnabler\": false,"
				+ "            \"country\": \"INDIA\""
				+ "        }"
				+ "    ],"
				+ "    \"mobile\": {"
				+ "        \"countryCode\": \"91\","
				+ "        \"number\": \""+mobileNumber+"\""
				+ "    }"
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vseDoctorId)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully linked doctor again");
		//

		//deleting the dummy VSE
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.delete("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vseidDummy)
				.then()
				.statusCode(HttpStatus.SC_NO_CONTENT)
				.extract()
				.response();

	}
	/*
	 * 		VSE Associate
	 */


	@Test//(retryAnalyzer = Customlisteners.class)  
	//1. Filling all fields, mobile number is not registered earlier and creating a case
	public void vse_Associate_Registerpatient() throws Exception{
		System.out.println("===============vse_Associate_Registerpatient (VKTTS04TC001) started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		caseId=getVSEPatientCaseId(obj.firstName);
		Logout_VigoKonnect();
		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)	 
	//2.Filling only mandatory fields and creating a case
	public void VKTTS04TC002() throws Exception{
		System.out.println("===============VKTTS04TC002 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		Thread.sleep(1000);
		//Register patient with mandatory fields only
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		obj.lastName="";
		obj.pincode="";
		RegisterPatient(obj);
		caseCreationSuccessPage();
		//for case id verificaion 
		caseId=getVSEPatientCaseId(obj.firstName);
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//3. Filling all fields, mobile number registered earlier and has no monitoring, and creating a case
	public void vse_Associate_existing_mobile_number_with_new_patientid() throws Exception {
		System.out.println("===============vse_Associate_existing_mobile_number_with_new_patientid (VKTTS04TC003) started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj= new CaseCreation();
		obj.doctor = vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		caseId=getVSEPatientCaseId(obj.firstName);
		caseDeletion(caseId);
		CMS_Logout();

		//Again opening Register patient tab
		obj.firstName = "automat"+Random_AlphaNumeric(4,0);
		RegisterPatient(obj);
		TakeScreenshot(driver, "Reopened Registerpatient page opened");
		caseCreationSuccessPage();

		caseId=getVSEPatientCaseId(obj.firstName);		
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class) 
	//4. Filling all fields, mobile number registered earlier and has monitoring
	public void VKTTS04TC004 () throws Exception {
		System.out.println("===============VKTTS04TC004 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj= new CaseCreation();
		obj.doctor = vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		//again entering mobile number 
		Click_Element(driver,VKT_RegisterPatient);
		Thread.sleep(1000);
		obj.FillMobileNumber();
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//5. Filling all fields and entering mobile number to which already cases are registered and there are currently no monitorings and we should be able to use the existing case ID.
	public void vse_Associate_existing_mobile_number_with_old_patientid () throws Exception {
		System.out.println("===============vse_Associate_existing_mobile_number_with_old_patientid (VKTTS04TC005) started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj= new CaseCreation();
		obj.doctor = vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		caseId=getVSEPatientCaseId(obj.firstName);
		caseDeletion(caseId);
		CMS_Logout();

		//Again opening Register patient tab
		obj.firstName ="";
		obj.lastName ="";
		RegisterPatient(obj);
		TakeScreenshot(driver, "Reopened Registerpatient page opened");
		caseCreationSuccessPage();

		caseId=getVSEPatientCaseId(obj.firstName);		
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//6. Filling all fields and number entered with 0 followed by mobile number
	public void VKTTS04TC006() throws Exception{
		System.out.println("===============VKTTS04TC006 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		//
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		obj.mobile="0"+obj.mobile;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		//for case id verificaion 
		caseId=getVSEPatientCaseId(obj.firstName);		
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)	 
	//7. Filling all fields and number entered with 0 followed by 9 numbers
	public void VKTTS04TC007() throws Exception{
		System.out.println("===============VKTTS04TC007 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		obj.mobile = 0 + "414"+Random_AlphaNumeric(0,6);
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter a valid mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();


	}

	@Test//(retryAnalyzer = Customlisteners.class)  
	//8. Filling all fields and enter number with 9 numbers or less
	public void VKTTS04TC008() throws Exception{
		System.out.println("===============VKTTS04TC008 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		int rvalue = Integer.parseInt(Random_AlphaNumeric(0,1));
		obj.mobile ="4"+Random_AlphaNumeric(0,rvalue-1);
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter a valid mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));

		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//9. Filling all fields and entered all same numbers for mobile number 
	public void VKTTS04TC009() throws Exception{
		System.out.println("===============VKTTS04TC009 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		obj.mobile="0000000000";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter a valid mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}

	@Test//(retryAnalyzer = Customlisteners.class)		 
	//10. Leaving all fields empty and creating a case
	public void VKTTS04TC010() throws Exception{
		System.out.println("===============VKTTS04TC010 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj = new CaseCreation();
		obj.EmptyAllFields();
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		TakeScreenshot(driver,"RegistrationPageWithEmptyDetails");
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}
	
	@Test//(retryAnalyzer = Customlisteners.class)  
	//11. filling only optional fields and creating a case
	public void VKTTS04TC011() throws Exception{
		System.out.println("===============VKTTS04TC011 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation obj = new CaseCreation();
		obj.EmptyAllFields();
		obj.lastName="test";
		obj.pincode="123456";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//12. Filling all fields, leaving one mandatory field and creating a case
	public void VKTTS04TC012() throws Exception{
		System.out.println("===============VKTTS04TC012 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);

		//Phone number not entered
		CaseCreation obj =new CaseCreation();
		obj.mobile="";
		obj.doctor=vseDoctorName;
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter mobile number",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//first name is empty
		Login_VigoKonnect_Username(vseAssociateName);
		obj.mobile= "414"+Random_AlphaNumeric(0,7);
		obj.firstName = "";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please enter first name",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//doctor not selected
		Login_VigoKonnect_Username(vseAssociateName);
		obj.firstName = getTextFromProperties("VK_FNAME")+Random_AlphaNumeric(4,0);
		obj.doctor="";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please select a doctor",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//service not selected
		Login_VigoKonnect_Username(vseAssociateName);
		obj.doctor = vseDoctorName;
		obj.service = "";
		RegisterPatient(obj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please select service",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//13. Filling all fields and service dropdown being empty as VSE haven’t subscribed to services.	
	public void VKTTS04TC013() throws Exception{
		System.out.println("===============VKTTS04TC013 started =======================");
		//API for unsubscribe
		String reqbody="{\"services\" : []}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.put("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vseid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully unsubscribed services");
		//
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation cobj = new CaseCreation();
		cobj.doctor=vseDoctorName;
		cobj.service = "";
		RegisterPatient(cobj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please select service",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//
		//API for subscription
		reqbody="{\"services\" : ["
				+ "{"
				+ "\"id\":\"6322ae6b1af70d0021da7e3e\","
				+ "\"name\":\"BBPBSPO2\""
				+ "},"
				+ "{"
				+ "\"id\":\"6369e3bf3c61f80022966520\","
				+ "\"name\":\"Vigo Life\""
				+ "},"
				+ "{"
				+ "\"id\":\"6396cc15aa09ed00249e6401\","
				+ "\"name\":\"testService\""
				+ "},"
				+ "{"
				+ "\"id\":\"6166b6c474eba30020255322\","
				+ "\"name\":\"SmartHeart\""
				+ "},"
				+ "{"
				+ "\"id\":\"611b8ec12e29f40020dac640\","
				+ "\"name\":\"BSM_Viatom\""
				+ "}]}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.put("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vseid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully subscribed services again");
		//
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//14. Filling all fields and no doctor in the dropdown to select and creating a case
	public void VKTTS04TC014() throws Exception{
		System.out.println("===============VKTTS04TC014 started =======================");
		String random4Dig=RandomStringUtils.random(4, false, true);
		//creating a VSE dummy
		String reqbody = "{"
				+ "\"firstName\":\"apiVSEDummy"+random4Dig+"\","
				+ "\"lastName\":\"\","
				+ "\"name\":\"apiVSEDummy"+random4Dig+"\","
				+ "\"licenseNumber\":\"123456\","
				+ "\"addressLine1\":\"addr1\","
				+ "\"addressLine2\":\"\","
				+ "\"pinCode\":\"123456\","
				+ "\"id\":\"\","
				+ "\"email\":\"\","
				+ "\"isServiceEnabler\":true,"
				+ "\"isActive\":true,"
				+ "\"loginId\":\"apiVSEDummy"+random4Dig+"\","
				+ "\"password\":\"changeme\","
				+ "\"website\":\"\","
				+ "\"location\":\"\","
				+ "\"reportPassword\":\"changeme\","
				+ "\"country\":\"INDIA\","
				+ "\"mobile\":"
				+ "{\"countryCode\":\"91\","
				+ "\"number\":\"9595959595\"},"
				+ "\"alternateMobile\":"
				+ "{\"countryCode\":\"\",\"number\":\"\"},"
				+ "\"note\":"
				+ "{\"reason\":\"\"},"
				+ "\"services\":[]}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/")
				.then()
				.statusCode(HttpStatus.SC_CREATED)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		String vseidDummy=obj.getString("_id");
		String serviceEnabler=obj.get("serviceEnabler").toString();
		String vseNameDummy=new JSONObject(serviceEnabler).getString("name");
		System.out.println("VSE Dummy name\t:"+vseNameDummy);

		//API for unlink doctor from VSE

		//mobile number from doctor VSE
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				//body()
				when()
				.header("Authorization","Bearer "+accessToken)
				.get("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vseDoctorId)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		String mobileNumber=obj.getJSONObject("mobile").getString("number");	//obj.get("mobile").toString();

		reqbody="{"
				+ "   \"businessPartners\": ["
				+ "        {"
				+ "            \"businessPartnerId\": \""+vseidDummy+"\","
				+ "            \"businessPartnerName\": \""+vseNameDummy+"\","
				+ "            \"displayName\": \""+vseDoctorName+"\","
				+ "            \"speciality\": \"Cardiology\","
				+ "            \"email\": \"\","
				+ "            \"isActive\": true,"
				+ "            \"location\": \"\","
				+ "            \"roles\": ["
				+ "                {"
				+ "                    \"role\": \"INTERNAL_DOCTOR\""
				+ "                }"
				+ "            ],"
				+ "            \"isDeleted\": false,"
				+ "            \"deletedBy\": {},"
				+ "            \"providerNumber\": \"\","
				+ "            \"isServiceEnabler\": false,"
				+ "            \"country\": \"INDIA\""
				+ "        }"
				+ "    ],"
				+ "    \"mobile\": {"
				+ "        \"countryCode\": \"91\","
				+ "        \"number\": \""+mobileNumber+"\""
				+ "    }"
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vseDoctorId)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully unlinked doctor");
		//
		Login_VigoKonnect_Username(vseAssociateName);
		CaseCreation cobj= new CaseCreation();
		cobj.doctor="";
		RegisterPatient(cobj);
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		//Error message
		Assert_TextValue("Please select a doctor",GetText(driver,VKT_RegisterPatient_Page.ErrorMsg));
		//Tapping on Dashboard 
		Click_Element(driver,VKT_Dashboard);
		Logout_VigoKonnect();

		//
		//API for link again
		reqbody="{"
				+ "   \"businessPartners\": ["
				+ "        {"
				+ "            \"businessPartnerId\": \""+vseid+"\","
				+ "            \"businessPartnerName\": \""+vseName+"\","
				+ "            \"displayName\": \""+vseDoctorName+"\","
				+ "            \"speciality\": \"Cardiology\","
				+ "            \"email\": \"\","
				+ "            \"isActive\": true,"
				+ "            \"location\": \"\","
				+ "            \"roles\": ["
				+ "                {"
				+ "                    \"role\": \"INTERNAL_DOCTOR\""
				+ "                }"
				+ "            ],"
				+ "            \"isDeleted\": false,"
				+ "            \"deletedBy\": {},"
				+ "            \"providerNumber\": \"\","
				+ "            \"isServiceEnabler\": false,"
				+ "            \"country\": \"INDIA\""
				+ "        }"
				+ "    ],"
				+ "    \"mobile\": {"
				+ "        \"countryCode\": \"91\","
				+ "        \"number\": \""+mobileNumber+"\""
				+ "    }"
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vseDoctorId)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully linked doctor again");
		//

		//deleting the dummy VSE
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.delete("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vseidDummy)
				.then()
				.statusCode(HttpStatus.SC_NO_CONTENT)
				.extract()
				.response();

	}


	// ----------------------------------------------------------------------------------------------------//
	// ================Admin====================//
	@Test//(retryAnalyzer = Customlisteners.class)
	//1.filling all mandatory fields and creating a case.
	public void vsp_Admin_Registerpatient() throws Exception {
		System.out.println("===============vsp_Admin_Registerpatient (VKTTS01TC001) started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		implicitWait(driver,2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//2.leaving all mandatory fields and creating a case.
	public void VKTTS01TC002() throws Exception {
		System.out.println("===============VKTTS01TC002 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "", "", 4, 0);
		Thread.sleep(1000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		Assert_TextValue("Please enter mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_EnterMobileNumError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//3.Filling all fields, mobile number is not registered earlier and creating a case
	public void VKTTS01TC003() throws Exception {
		System.out.println("===============VKTTS01TC003 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		String patientLastName = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "", "", 4, 0);
		System.out.println("Hiii " + pname + " " + patientLastName);
		Thread.sleep(3000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		service = service.toUpperCase();
		Thread.sleep(3000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		implicitWait(driver,3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//4.Filling all fields, mobile number registered earlier and has no monitoring,
	//and creating a case using new patient.
	public void vsp_Admin_existing_mobile_number_with_new_patientid() throws Exception {
		System.out.println("===============vsp_Admin_existing_mobile_number_with_new_patientid (VKTTS01TC004) started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		String phno = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(2000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		caseDeletion(caseId);
		CMS_Logout();
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,phno);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_IdsFor_RegMobileNum");
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_Patient_AddNew);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(3000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(2000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		Thread.sleep(1000);
		CMS_Logout();
	}

	@Test(retryAnalyzer = Customlisteners.class)
	//5.Filling all fields, mobile number registered earlier and has monitoring
	public void VKTTS01TC005() throws Exception {
		System.out.println("===============VKTTS01TC005 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		String phno = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		implicitWait(driver,3000);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		caseVerfication(caseId);
		CMS_Logout();
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, phno);
		Thread.sleep(2000);
		Assert_TextValue(
				"The following patients in your hospital are associated with this " + phno
				+ " mobile number. Please select or add a new patient",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNewPopupText));
		TakeScreenshot(driver, "VKT_Patient_Cases_Of_RegisteredMobile");
		try {
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNew);
			Thread.sleep(4000);
			Assert_TextValue(
					"There is a monitoring already going on with this mobile number, please use a different mobile number",
					GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_PopUp));
			TakeScreenshot(driver, "VKT_Patient_PopUpMessage_Of_ExistingMobile");
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_OK);
		}
		catch(Exception e) {
			Assert_TextValue(
					"There is a monitoring already going on with this mobile number, please use a different mobile number",
					GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_PopUp));
			TakeScreenshot(driver, "VKT_Patient_PopUpMessage_Of_ExistingMobile");
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_OK);
			implicitWait(driver,2000);
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNew);
		}
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//6.Filling all fields and entering mobile number to which already cases are registered
	//and there are currently no monitorings and we should be able to use the existing case ID.
	public void vsp_Admin_existing_mobile_number_with_old_patientid() throws Exception {
		System.out.println("===============vsp_Admin_existing_mobile_number_with_old_patientid (VKTTS01TC006) started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		String phno = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(2000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		service = service.toUpperCase();
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		caseDeletion(caseId);
		CMS_Logout();
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,phno);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_IdsFor_RegMobileNum");
		Assert_TextValue(
				"The following patients in your hospital are associated with this " + phno
				+ " mobile number. Please select or add a new patient",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNewPopupText));
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_TopPaientId);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(3000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//7.filling all mandatory fields but leaving a single mandatory field empty and creating a case.
	public void VKTTS01TC007() throws Exception {
		System.out.println("===============VKTTS01TC007 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSPAdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "", "", 4, 0);
		Thread.sleep(3000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please select service",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_SelectServiceError");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "", "", 0, 0);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please enter mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_EnterMobileNumError");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "", "", 0, 0);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please enter first name",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_EnterFNameError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(2000);
		Logout_VigoKonnect();
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSPAdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please select a doctor",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_SelectDoctorError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(6000);
		Logout_VigoKonnect();
	}


	@Test//(retryAnalyzer = Customlisteners.class)
	//8.filling all mandatory fields but having no doctor in the dropdown to select and creating a case.
	//@SuppressWarnings({ "rawtypes", "deprecation" })
	public void VKTTS01TC008() throws Exception{
		System.out.println("===============VKTTS01TC008 started =======================");
		//vse creation
		String phno="9"+RandomStringUtils.random(9, false, true);
		String random4Dig=RandomStringUtils.random(4, false, true);
		String reqbody = "{" + "\"firstName\":\"apiVSEAdmin" + random4Dig + "\"," + "\"lastName\":\"\","
				+ "\"name\":\"apiVSE" + random4Dig + "\"," + "\"licenseNumber\":\"123456\","
				+ "\"addressLine1\":\"addr1\"," + "\"addressLine2\":\"\"," + "\"pinCode\":\"123456\"," + "\"id\":\"\","
				+ "\"email\":\"\"," + "\"isServiceEnabler\":true," + "\"isActive\":true," + "\"loginId\":\"apiVSEAdmin"
				+ random4Dig + "\"," + "\"password\":\"changeme\"," + "\"website\":\"\"," + "\"location\":\"\","
				+ "\"reportPassword\":\"changeme\"," + "\"country\":\"INDIA\"," + "\"mobile\":"
				+ "{\"countryCode\":\"91\"," + "\"number\":\"" + phno + "\"}," + "\"alternateMobile\":"
				+ "{\"countryCode\":\"\",\"number\":\"\"}," + "\"note\":" + "{\"reason\":\"\"}," + "\"services\":["
				+ "{" + "\"id\":\"6322ae6b1af70d0021da7e3e\"," + "\"name\":\"BBPBSPO2\"" + "}," + "{"
				+ "\"id\":\"6369e3bf3c61f80022966520\"," + "\"name\":\"Vigo Life\"" + "}," + "{"
				+ "\"id\":\"6396cc15aa09ed00249e6401\"," + "\"name\":\"testService\"" + "}," + "{"
				+ "\"id\":\"6166b6c474eba30020255322\"," + "\"name\":\"SmartHeart\"" + "}," + "{"
				+ "\"id\":\"611b8ec12e29f40020dac640\"," + "\"name\":\"BSM_Viatom\"" + "}]" + "}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/")
				.then()
				.statusCode(HttpStatus.SC_CREATED)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		String tempVseid=obj.getString("_id");
		String serviceEnabler=obj.get("serviceEnabler").toString();
		String tempVseName=new JSONObject(serviceEnabler).getString("name");
		System.out.println("Temporary VSE NAME : "+tempVseName);
		//doc assign to created vse
		reqbody="{"
				+ "\"businessPartners\": ["
				+ "        {"
				+ "            \"businessPartnerId\": \""+tempVseid+"\","
				+ "            \"businessPartnerName\": \""+tempVseName+"\","
				+ "            \"email\": \"\","
				+ "            \"layout\": ["
				+ "            ],"
				+ "            \"speciality\": \"Cardiology\","
				+ "            \"roles\": ["
				+ "                {"
				+ "                    \"role\": \"INTERNAL_DOCTOR\""
				+ "                }"
				+ "            ]}],"
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "}}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vspDoctorid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("doc assign to created temporary vse");
		//vkt flow
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		String patientLastName = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "", "", 4, 0);
		System.out.println("Hiii " + pname + " " + patientLastName);
		Thread.sleep(2000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(2000);
		TakeScreenshot(driver,"VKT_EmptyDoctorDropDown");
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_PatientReg_View);
		Thread.sleep(2000);
		TouchAction ts = new TouchAction(driver);
		ts.press(PointOption.point(536,796)).moveTo(PointOption.point(536, 1536)).release().perform();
		Thread.sleep(2000);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_PatientReg_View);
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		Assert_TextValue("Please select a doctor",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_SelectDoctorError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(6000);
		Logout_VigoKonnect();
		//reassign doc to old vsp
		reqbody="{"
				+ "\"businessPartners\": ["
				+ "        {"
				+ "            \"businessPartnerId\": \""+vspid+"\","
				+ "            \"businessPartnerName\": \""+vspName+"\","
				+ "            \"email\": \"\","
				+ "            \"layout\": ["
				+ "            ],"
				+ "            \"speciality\": \"Cardiology\","
				+ "            \"roles\": ["
				+ "                {"
				+ "                    \"role\": \"INTERNAL_DOCTOR\""
				+ "                }"
				+ "            ]}],"
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "}}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vspDoctorid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("doc re assign to  old vsp");
		//temporary vse deletion
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.delete("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+tempVseid)
				.then()
				.statusCode(HttpStatus.SC_NO_CONTENT)
				.extract()
				.response();
		System.out.println("temporary vse deleted successfully");
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//9.filling all mandatory fields and service drop down being empty as vsp haven’t subscribed to no services.
	public void VKTTS01TC009() throws Exception{
		System.out.println("===============VKTTS01TC009 started =======================");
		//un-subscribing services
		String reqbody="{\"services\" : []}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.put("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vspid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		System.out.print("successfully unsubscribed");
		//vkt login
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		String phno = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(2000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please select service",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_SelectServiceError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(6000);
		Logout_VigoKonnect();
		//re subscribing services
		reqbody="{\"services\" : ["
				+ "{"
				+ "\"id\":\"6322ae6b1af70d0021da7e3e\","
				+ "\"name\":\"BBPBSPO2\""
				+ "},"
				+ "{"
				+ "\"id\":\"6369e3bf3c61f80022966520\","
				+ "\"name\":\"Vigo Life\""
				+ "},"
				+ "{"
				+ "\"id\":\"6396cc15aa09ed00249e6401\","
				+ "\"name\":\"testService\""
				+ "},"
				+ "{"
				+ "\"id\":\"6166b6c474eba30020255322\","
				+ "\"name\":\"SmartHeart\""
				+ "},"
				+ "{"
				+ "\"id\":\"611b8ec12e29f40020dac640\","
				+ "\"name\":\"BSM_Viatom\""
				+ "}]}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.put("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vspid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully subscribed");		
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//10.filling all mandatory fields and entering mobile number less than 10 digits and creating a case
	public void VKTTS01TC010() throws Exception {
		System.out.println("===============VKTTS01TC010 started =======================");
		Random rn = new Random();
		int number = rn.nextInt(6);
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, number);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_ValidMobileError");
		Assert_TextValue("Please enter a valid mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert)
				.trim());
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(2000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//11.filling all mandatory fields and entering mobile number starting 
	//with 0 following 9 digits and creating a case
	public void VKTTS01TC011() throws Exception {
		System.out.println("===============VKTTS01TC011 started =======================");
		Random rn = new Random();
		String number = "0414" + Random_AlphaNumeric(0, 6);
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, number);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_ValidMobileError");
		Assert_TextValue("Please enter a valid mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert)
				.trim());
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//12.filling all mandatory fields and entering mobile number with 0 starting 
	//followed by 10 digits (doesn't start with 0) and creating a case.
	public void VKTTS01TC012() throws Exception {
		System.out.println("===============VKTTS01TC012 started =======================");
		Random rn = new Random();
		String number = "0414" + Random_AlphaNumeric(0, 7);
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, number);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		implicitWait(driver,3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//13.Filling all mandatory fields and entering mobile number with all zeros
	public void VKTTS01TC013() throws Exception {
		System.out.println("===============VKTTS01TC013 started =======================");
		Random rn = new Random();
		String number = "00000000000";
		number = number.substring(0, rn.nextInt(11) + 1);
		Login_VigoKonnect_Username(vspAdminName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AdminDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, number);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_ValidMobileError");
		Assert_TextValue("Please enter a valid mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert)
				.trim());
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	// ==================Associate====================//
	@Test//(retryAnalyzer = Customlisteners.class)
	//1.filling all mandatory fields and creating a case.
	public void vsp_Associate_Registerpatient() throws Exception {
		System.out.println("===============vsp_Associate_Registerpatient (VKTTS02TC001) started =======================");
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		service = service.toUpperCase();
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//2.leaving all mandatory fields and creating a case.
	public void VKTTS02TC002() throws Exception {
		System.out.println("===============VKTTS02TC002 started =======================");
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "", "", 4, 0);
		Thread.sleep(1000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(1000);
		Assert_TextValue("Please enter mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_EnterMobileNumError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//3.Filling all fields, mobile number is not registered earlier and creating a case
	public void VKTTS02TC003() throws Exception {
		System.out.println("===============VKTTS02TC003 started =======================");
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		String patientLastName = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "", "", 4, 0);
		System.out.println("Hiii " + pname + " " + patientLastName);
		Thread.sleep(3000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		implicitWait(driver,3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//4.Filling all fields, mobile number registered earlier and has no monitoring,
	//and creating a case using new patient.
	public void vsp_Associate_existing_mobile_number_with_new_patientid() throws Exception {
		System.out.println("===============vsp_Associate_existing_mobile_number_with_new_patientid (VKTTS02TC004) started =======================");
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		String phno = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(2000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		service = service.toUpperCase();
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		caseDeletion(caseId);
		CMS_Logout();
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,phno);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_IdsFor_RegMobileNum");
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_Patient_AddNew);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		service = service.toUpperCase();
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(3000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(2000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test(retryAnalyzer = Customlisteners.class)
	//5.Filling all fields, mobile number registered earlier and has monitoring
	public void VKTTS02TC005() throws Exception {
		System.out.println("===============VKTTS02TC005 started =======================");
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		String phno = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		implicitWait(driver,3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		caseVerfication(caseId);
		CMS_Logout();
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, phno);
		Thread.sleep(2000);
		Assert_TextValue(
				"The following patients in your hospital are associated with this " + phno
				+ " mobile number. Please select or add a new patient",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNewPopupText));
		TakeScreenshot(driver, "VKT_Patient_Cases_Of_RegisteredMobile");
		try {
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNew);
			Thread.sleep(4000);
			Assert_TextValue(
					"There is a monitoring already going on with this mobile number, please use a different mobile number",
					GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_PopUp));
			TakeScreenshot(driver, "VKT_Patient_PopUpMessage_Of_ExistingMobile");
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_OK);
		}
		catch(Exception e) {
			Assert_TextValue(
					"There is a monitoring already going on with this mobile number, please use a different mobile number",
					GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_PopUp));
			TakeScreenshot(driver, "VKT_Patient_PopUpMessage_Of_ExistingMobile");
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_OK);
			implicitWait(driver,2000);
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNew);
		}
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//6.Filling all fields and entering mobile number to which already cases are registered
	//and there are currently no monitorings and we should be able to use the existing case ID.
	public void vsp_Associate_existing_mobile_number_with_old_patientid() throws Exception {
		System.out.println("===============vsp_Associate_existing_mobile_number_with_old_patientid (VKTTS02TC006) started =======================");
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		String phno = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(2000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		service = service.toUpperCase();
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		caseDeletion(caseId);
		CMS_Logout();
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,phno);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_IdsFor_RegMobileNum");
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_TopPaientId);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		service = service.toUpperCase();
		Thread.sleep(3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(3000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//7.filling all mandatory fields but leaving a single mandatory field empty and creating a case.
	public void VKTTS02TC007() throws Exception {
		System.out.println("===============VKTTS02TC007 started =======================");
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSPAssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "", "", 4, 0);
		Thread.sleep(3000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please select service",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_SelectServiceError");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "", "", 0, 0);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please enter mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_EnterMobileNumError");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "", "", 0, 0);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please enter first name",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_EnterFNameError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(2000);
		Logout_VigoKonnect();
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSPAssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please select a doctor",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_SelectDoctorError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(6000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//8.filling all mandatory fields but having no doctor in the dropdown to select and creating a case.
	//@SuppressWarnings({ "rawtypes", "deprecation" })
	public void VKTTS02TC008() throws Exception{
		System.out.println("===============VKTTS02TC008 started =======================");
		//vse creation
		String phno="9"+RandomStringUtils.random(9, false, true);
		String random4Dig=RandomStringUtils.random(4, false, true);
		String reqbody = "{" + "\"firstName\":\"apiVSEAdmin" + random4Dig + "\"," + "\"lastName\":\"\","
				+ "\"name\":\"apiVSE" + random4Dig + "\"," + "\"licenseNumber\":\"123456\","
				+ "\"addressLine1\":\"addr1\"," + "\"addressLine2\":\"\"," + "\"pinCode\":\"123456\"," + "\"id\":\"\","
				+ "\"email\":\"\"," + "\"isServiceEnabler\":true," + "\"isActive\":true," + "\"loginId\":\"apiVSEAdmin"
				+ random4Dig + "\"," + "\"password\":\"changeme\"," + "\"website\":\"\"," + "\"location\":\"\","
				+ "\"reportPassword\":\"changeme\"," + "\"country\":\"INDIA\"," + "\"mobile\":"
				+ "{\"countryCode\":\"91\"," + "\"number\":\"" + phno + "\"}," + "\"alternateMobile\":"
				+ "{\"countryCode\":\"\",\"number\":\"\"}," + "\"note\":" + "{\"reason\":\"\"}," + "\"services\":["
				+ "{" + "\"id\":\"6322ae6b1af70d0021da7e3e\"," + "\"name\":\"BBPBSPO2\"" + "}," + "{"
				+ "\"id\":\"6369e3bf3c61f80022966520\"," + "\"name\":\"Vigo Life\"" + "}," + "{"
				+ "\"id\":\"6396cc15aa09ed00249e6401\"," + "\"name\":\"testService\"" + "}," + "{"
				+ "\"id\":\"6166b6c474eba30020255322\"," + "\"name\":\"SmartHeart\"" + "}," + "{"
				+ "\"id\":\"611b8ec12e29f40020dac640\"," + "\"name\":\"BSM_Viatom\"" + "}]" + "}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/")
				.then()
				.statusCode(HttpStatus.SC_CREATED)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		String tempVseid=obj.getString("_id");
		String serviceEnabler=obj.get("serviceEnabler").toString();
		String tempVseName=new JSONObject(serviceEnabler).getString("name");
		System.out.println("Temporary VSE NAME : "+tempVseName);
		//doc assign to created vse
		reqbody="{"
				+ "\"businessPartners\": ["
				+ "        {"
				+ "            \"businessPartnerId\": \""+tempVseid+"\","
				+ "            \"businessPartnerName\": \""+tempVseName+"\","
				+ "            \"email\": \"\","
				+ "            \"layout\": ["
				+ "            ],"
				+ "            \"speciality\": \"Cardiology\","
				+ "            \"roles\": ["
				+ "                {"
				+ "                    \"role\": \"INTERNAL_DOCTOR\""
				+ "                }"
				+ "            ]}],"
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "}}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vspDoctorid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("doc assign to created temporary vse");
		//vkt flow
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		String patientLastName = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "", "", 4, 0);
		System.out.println("Hiii " + pname + " " + patientLastName);
		Thread.sleep(2000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(2000);
		TakeScreenshot(driver,"VKT_EmptyDoctorDropDown");
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_PatientReg_View);
		Thread.sleep(2000);
		TouchAction ts = new TouchAction(driver);
		ts.press(PointOption.point(536,796)).moveTo(PointOption.point(536, 1536)).release().perform();
		Thread.sleep(2000);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_PatientReg_View);
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		Assert_TextValue("Please select a doctor",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_SelectDoctorError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(6000);
		Logout_VigoKonnect();
		//reassign doc to old vsp
		reqbody="{"
				+ "\"businessPartners\": ["
				+ "        {"
				+ "            \"businessPartnerId\": \""+vspid+"\","
				+ "            \"businessPartnerName\": \""+vspName+"\","
				+ "            \"email\": \"\","
				+ "            \"layout\": ["
				+ "            ],"
				+ "            \"speciality\": \"Cardiology\","
				+ "            \"roles\": ["
				+ "                {"
				+ "                    \"role\": \"INTERNAL_DOCTOR\""
				+ "                }"
				+ "            ]}],"
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "}}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/"+vspDoctorid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("doc re assign to  old vsp");
		//temporary vse deletion
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.delete("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+tempVseid)
				.then()
				.statusCode(HttpStatus.SC_NO_CONTENT)
				.extract()
				.response();
		System.out.println("temporary vse deleted successfully");
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//9.filling all mandatory fields and service drop down being empty as vsp haven’t subscribed to no services.
	public void VKTTS02TC009() throws Exception{
		System.out.println("===============VKTTS02TC009 started =======================");
		//un-subscribing services
		String reqbody="{\"services\" : []}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.put("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vspid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		System.out.print("successfully unsubscribed");
		//vkt login
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		String phno = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(2000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		Assert_TextValue("Please select service",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert).trim());
		TakeScreenshot(driver, "VKT_Patient_SelectServiceError");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(6000);
		Logout_VigoKonnect();
		//re subscribing services
		reqbody="{\"services\" : ["
				+ "{"
				+ "\"id\":\"6322ae6b1af70d0021da7e3e\","
				+ "\"name\":\"BBPBSPO2\""
				+ "},"
				+ "{"
				+ "\"id\":\"6369e3bf3c61f80022966520\","
				+ "\"name\":\"Vigo Life\""
				+ "},"
				+ "{"
				+ "\"id\":\"6396cc15aa09ed00249e6401\","
				+ "\"name\":\"testService\""
				+ "},"
				+ "{"
				+ "\"id\":\"6166b6c474eba30020255322\","
				+ "\"name\":\"SmartHeart\""
				+ "},"
				+ "{"
				+ "\"id\":\"611b8ec12e29f40020dac640\","
				+ "\"name\":\"BSM_Viatom\""
				+ "}]}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.put("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vspid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("successfully subscribed");		
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//10.filling all mandatory fields and entering mobile number less than 10 digits and creating a case
	public void VKTTS02TC010() throws Exception {
		System.out.println("===============VKTTS02TC010 started =======================");
		Random rn = new Random();
		int number = rn.nextInt(6);
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, number);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_ValidMobileError");
		Assert_TextValue("Please enter a valid mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert)
				.trim());
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(2000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//11.filling all mandatory fields and entering mobile number starting 
	//with 0 following 9 digits and creating a case
	public void VKTTS02TC011() throws Exception {
		System.out.println("===============VKTTS02TC011 started =======================");
		Random rn = new Random();
		String number = "0414" + Random_AlphaNumeric(0, 6);
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, number);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_ValidMobileError");
		Assert_TextValue("Please enter a valid mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert)
				.trim());
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//12.filling all mandatory fields and entering mobile number with 0 starting 
	//followed by 10 digits (doesn't start with 0) and creating a case.
	public void VKTTS02TC012() throws Exception {
		System.out.println("===============VKTTS02TC012 started =======================");
		Random rn = new Random();
		String number = "0414" + Random_AlphaNumeric(0, 7);
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, number);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		service = service.toUpperCase();
		Thread.sleep(2000);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		implicitWait(driver,3000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Service(service));
		Thread.sleep(2000);
		EnterText(driver, VKT_Service_Pages.VKT_Service_SearchBox, pname);
		Thread.sleep(2000);
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_Patient(pname));
		Thread.sleep(2000);
		caseId = GetText(driver, VKT_PatientDetails.VKT_PatientCaseId);
		Click_Element(driver, VKT_PatientDetails.VKT_PatientBackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//13.Filling all mandatory fields and entering mobile number with all zeros
	public void VKTTS02TC013() throws Exception {
		System.out.println("===============VKTTS02TC013 started =======================");
		Random rn = new Random();
		String number = "00000000000";
		number = number.substring(0, rn.nextInt(11) + 1);
		Login_VigoKonnect_Username(vspAssociateName);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_VSP_AssociateDashboard");
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_RegPatient);
		Thread.sleep(2000);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle).trim());
		WebElement registerpatient = driver.findElement(VKT_RegisterPatient);
		if (registerpatient.isSelected()) {
			System.out.println("VigoKonnect Register Patient is opened");
		} else {
			System.out.println("Unable to open VigoKonnect Register Patient");
		}
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_FormBefore");
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, number);
		Thread.sleep(1000);
		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName, "VK_FNAME", "", 4, 0);
		System.out.println("Hiii " + pname);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor, vspDoctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(5000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(3000);
		String service = Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);
		TakeScreenshot(driver, "VKT_Patient_FormAfter");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(2000);
		TakeScreenshot(driver, "VKT_Patient_ValidMobileError");
		Assert_TextValue("Please enter a valid mobile number",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patinet_Alert)
				.trim());
		Click_Element(driver, VKT_DashboardPage.VKT_VSP_AllMonitoring);
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}

	/**
	 * case creation using Doctor 
	 */

	@Test//(retryAnalyzer = Customlisteners.class)  
	//1. Filling all fields, mobile number is not registered earlier and creating a case
	public void Doctor_Registerpatient() throws Exception{
		System.out.println("===============Doctor_Registerpatient (VKTTS07TC001) started =======================");
		Login_VigoKonnect_Username(prop.getProperty("VKT_DOCTOR_UN"),"pass1234");
		CaseCreation obj = new CaseCreation();
		obj.doctor=GetText(driver,VKT_DashboardPage.VKT_NameOfTheUser).substring(4);
		RegisterPatient(obj);
		caseCreationSuccessPage();
		caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		System.out.println("The case id of patient \t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();
		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)	 
	//2.Filling only mandatory fields and creating a case
	public void VKTTS07TC002() throws Exception{
		System.out.println("===============VKTTS07TC002 started =======================");
		Login_VigoKonnect_Username(prop.getProperty("VKT_DOCTOR_UN"),"pass1234");
		//Register patient with mandatory fields only
		Thread.sleep(2000);
		String doctorName=GetText(driver,VKT_DashboardPage.VKT_NameOfTheUser).substring(4);
		Click_Element(driver, VKT_RegisterPatient);
		Thread.sleep(1000);
		isSelected(driver,VKT_RegisterPatient);	
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientTitle));	
		Thread.sleep(1000);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber, "VKAPNO", "", 0, 7);
		Thread.sleep(1000);

		//Patient name 
		pname = EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientFirstName,"VK_FNAME","",4,0);
		System.out.println("Hiii "+pname);

		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(2000);
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor,doctorName);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(1000);

		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		TakeScreenshot(driver,"CaseCreationWithPatientId");

		Thread.sleep(3000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		TakeScreenshot(driver,"CaseCreationWithPatientData");

		//for case id verificaion 
		caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		System.out.println("The case id of patient \t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Ignore
	//3. Filling all fields, mobile number registered earlier and has no monitoring, and creating a case
	public void Doctor_existing_mobile_number_with_new_patientid () throws Exception {
		System.out.println("===============Doctor_existing_mobile_number_with_new_patientid (VKTTS07TC003) started =======================");
		Login_VigoKonnect_Username(prop.getProperty("VKT_DOCTOR_UN"),"pass1234");
		Thread.sleep(3000);
		String doctorName=GetText(driver,VKT_DashboardPage.VKT_NameOfTheUser).substring(4);
		String Registerpatient_Text=GetText(driver, VKT_DashboardPage.VKT_RegisterPatient);
		Assert_TextValue("Register Patient", Registerpatient_Text);
		Click_Element(driver, VKT_RegisterPatient);
		Thread.sleep(4000);
		TakeScreenshot(driver, "Registerpatient page opened");
		String Mobilenumber=EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,"","", 0, 10);
		System.out.println("mobile number ="+Mobilenumber);
		Thread.sleep(1000);
		pname = EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientFirstName,"VK_FNAME","",4,0);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "test","",5, 0);
		Thread.sleep(2000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(2000);
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor,doctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(2000);
		TakeScreenshot(driver, "Entered All Details In RegisterCase");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		TakeScreenshot(driver, "Case created successfully");
		String CaseID=GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID);
		System.out.println(CaseID);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		System.out.println("The case id of patient \t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Thread.sleep(1000);
		caseDeletion(caseId);
		CMS_Logout();

		//Again opening Register patient tab
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient);
		Thread.sleep(4000);
		TakeScreenshot(driver, "Reopened Registerpatient page opened");
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,Mobilenumber);
		Thread.sleep(3000);
		TakeScreenshot(driver, "Previous cases pageopened");
		Assert_TextValue(
				"The following patients in your hospital are associated with this " + Mobilenumber
				+ " mobile number. Please select or add a new patient",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNewPopupText));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_VSE_NewPatient_Button);
		Thread.sleep(3000);

		pname = EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName,"VK_FNAME","",6,0);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "Patient","",5, 0);
		Thread.sleep(2000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(2000);
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor,doctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(2000);
		TakeScreenshot(driver, "Entered All Details In RegisterCase");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		TakeScreenshot(driver, "Case created successfully");
		CaseID=GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID);
		System.out.println(CaseID);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);

		//case ID verfifcation in cms
		
		caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		TakeScreenshot(driver, "Case Data with Id");
		System.out.println("The case id of patient \t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);		
		Thread.sleep(1000);
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}

	@Ignore
	//4. Filling all fields and entering mobile number to which already cases are registered and there are currently no monitorings and we should be able to use the existing case ID.
	public void Doctor_existing_mobile_number_with_old_patientid () throws Exception {
		System.out.println("===============Doctor_existing_mobile_number_with_old_patientid (VKTTS07TC004) started =======================");
		Login_VigoKonnect_Username(prop.getProperty("VKT_DOCTOR_UN"),"pass1234");
		Thread.sleep(3000);
		String doctorName=GetText(driver,VKT_DashboardPage.VKT_NameOfTheUser).substring(4);
		String Registerpatient_Text=GetText(driver, VKT_DashboardPage.VKT_RegisterPatient);
		Assert_TextValue("Register Patient", Registerpatient_Text);
		Click_Element(driver, VKT_RegisterPatient);
		Thread.sleep(4000);
		TakeScreenshot(driver, "Registerpatient page opened");
		String Mobilenumber=EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,"","", 0, 10);
		System.out.println("mobile number ="+Mobilenumber);
		Thread.sleep(1000);
		pname = EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientFirstName,"VK_FNAME","",4,0);
		EnterRandomData(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName, "test","",5, 0);
		Thread.sleep(2000);
		EnterRandomData(driver,VKT_RegisterPatient_Page.VKT_RegPatientPincode,"","",0,6);
		Thread.sleep(1000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(2000);
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor,doctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(2000);
		TakeScreenshot(driver, "Entered All Details In RegisterCase");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		TakeScreenshot(driver, "Case created successfully");
		String CaseID=GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID);
		System.out.println(CaseID);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		System.out.println("The case id of patient \t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Thread.sleep(1000);
		caseDeletion(caseId);
		CMS_Logout();

		//Again opening Register patient tab
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient);
		Thread.sleep(4000);
		TakeScreenshot(driver, "Reopened Registerpatient page opened");
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,Mobilenumber);
		Thread.sleep(3000);
		Assert_TextValue(
				"The following patients in your hospital are associated with this " + Mobilenumber
				+ " mobile number. Please select or add a new patient",
				GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNewPopupText));
		TakeScreenshot(driver, "Previous cases pageopened");

		Click_Element(driver,VKT_RegisterPatient_Page.VKT_TopPaientId);
		//
		Thread.sleep(3000);

		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		Thread.sleep(2000);
		EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor,doctorName);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		Thread.sleep(3000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_SelectVigoLife);
		Thread.sleep(2000);
		TakeScreenshot(driver, "Entered All Details In RegisterCase");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		Thread.sleep(3000);
		TakeScreenshot(driver, "Case created successfully");
		CaseID=GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID);
		System.out.println(CaseID);
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		
		//case ID verfifcation in cms
		caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		TakeScreenshot(driver, "Case Data with Id");
		System.out.println("The id of patient is\t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Thread.sleep(1000);
		Logout_VigoKonnect();

		//opening cms and checking caseId
		caseVerfication(caseId);
		CMS_Logout();
	}}
