package TestScripts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class HeartBeat_Cases extends BASE {

	@Test
	public static void sample() throws Exception {
		readpropertiesdata();
		// openCMS_WEB();
		// String parentwindow=dr.getWindowHandle();
		// System.out.println(parentwindow);

		// need to check how mobile and web both integratedly working.

		// Login_VigoKonnect_Username();
		Click_Element(driver, VKT_Username_Button);
		Thread.sleep(3000);
		EnterData(driver, VKT_Username_TextBox, "VKUID");
		EnterData(driver, VKT_Password_TextBox, "VKPWD");
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		Click_Element(driver, VKT_LoginButton);
		Thread.sleep(3000);
		// pageLoadTimeOut(driver, 10);
		TakeScreenshot(driver, "VigoKonnectHomePage");

	}
}
