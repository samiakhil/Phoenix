package TestScripts;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import PageElements.CMS_BusinessPartner;
import PageElements.CMS_Dashboard;
import PageElements.VKT_UpdatePassword;

public class deleteVSP extends BASE{
	//@Test
	public static void deletevsp() throws Exception {
		readpropertiesdata();
		openCMS_WEB();
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PartnerMangement);
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_BusinessPartner);
		EnterText(dr,CMS_BusinessPartner.Cms_BusinessPartner_Search,"apiVS");
		Click_Element(dr,CMS_BusinessPartner.Cms_BusinessPartner_SearchButton);
		WebElement html = dr.findElement(By.tagName("html"));
		html.sendKeys(Keys.chord(Keys.CONTROL, "67"));
		while(dr.findElements(By.xpath("//td/div[contains(text(),'apiVS')]")).size()>=1);
			{Delete_ClickOn_TrashBin();implicitWait(dr,1500);}
		html.sendKeys(Keys.chord(Keys.CONTROL, "100"));
		CMS_Logout();
	}
	
	
	public static void Login_VigoKonnect_Usernam(String uName,String password) throws Exception{
		Click_Element(driver, VKT_Username_Button);
		isSelected(driver,VKT_Username_Button);
		Thread.sleep(1000);
		EnterText(driver,VKT_Username_TextBox,uName);
		if(password!="")
		EnterText(driver, VKT_Password_TextBox, password);
		else
		EnterData(driver, VKT_Password_TextBox, "VKPWD");
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		Click_Element(driver, VKT_LoginButton);
		Thread.sleep(7000);
		try {
			EnterData(driver, VKT_UpdatePassword.VKT_NewPassword, "VKPWD");
			EnterData(driver, VKT_UpdatePassword.VKT_ConfirmPassword, "VKPWD");
			Click_Element(driver, VKT_UpdatePassword.VKT_UpdateButton);
			Thread.sleep(4500);
			EnterText(driver,VKT_Username_TextBox,uName);
			EnterData(driver, VKT_Password_TextBox, "VKPWD");
			TakeScreenshot(driver, "VigoKonnectLoginScreen");
			Click_Element(driver, VKT_LoginButton);
			Thread.sleep(7000);
		}
		catch(Exception e) {}
		finally {
			Assert_TextValue(uName,
					GetText(driver,By.xpath("//*[contains(@text,'"+uName+"')]")));
		}
	}
	
	public static void Login_VigoKonnect_Usernam(String uName) throws Exception {
		Login_VigoKonnect_Usernam(uName,"changeme");
	}
	
	@Test
	public static void testing() throws Exception{
		Login_VigoKonnect_Usernam("apiVSEAdmin12348771");
	}
	
}
