package TestScripts;
import PageElements.CMS_Agents;
import PageElements.CMS_Agents_Form;
import PageElements.CMS_BusinessGroup;
import PageElements.CMS_BusinessGroup_Form;
import PageElements.CMS_BusinessPartner;
import PageElements.CMS_BusinessPartnerForm;
import PageElements.CMS_Common_PageElements;
import PageElements.CMS_Dashboard;
import PageElements.CMS_Nurse;
import PageElements.CMS_Nurse_Form;
import PageElements.CMS_PreMonitoring;
import PageElements.CMS_VSE_EditPage;
import PageElements.CMS_VSE_Form;
import Reusable.*;
import Reusable.Reusable.*;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.annotations.Listeners;
@Listeners(Customlisteners.class)
public class Cms_Tests extends CommonMethods {
	//@Test
	public static void cms_BusinessGroup_Creation() throws Exception {
		readpropertiesdata();
		openCMS_WEB();
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PartnerMangement);
		Thread.sleep(2000);
		MethodScreenshot("CMS_PartnerManagement_DropDown");
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_BusinessGroup);
		Thread.sleep(3000);
		Assert_TextValue("BusinessGroup",GetText(dr,CMS_BusinessGroup.Cms_BusinessGroup_Navbar_Title));
		TakeScreenshot(dr,"CMS_BusinessGroup_Page");
		Click_Element(dr,CMS_Common_PageElements.Cms_CreateNew);
		Thread.sleep(2000);
		Assert_TextValue("CreateBusinessGroup",GetText(dr,CMS_BusinessGroup_Form.Cms_BusinessGroupFrom_Navbar_Title));
		TakeScreenshot(dr,"CMS_BusienssGroup_FormBefore");
		String name=EnterRandomData(dr,CMS_BusinessGroup_Form.CmsBusinessGroupForm_Name,"CMS_BUSINESSGROUP_NAME","",3,0);
		TakeScreenshot(dr,"CMS_BusienssGroup_FormAfter");
		Click_Element(dr,CMS_Common_PageElements.Cms_Form_SaveButton);
		Thread.sleep(2000);
		if(true) {
			Cms_BusinessGroup_Verification(name);
			Thread.sleep(2000);
			Delete_ClickOn_TrashBin();
			TakeScreenshot(dr,"CMS_BusinessGroup_Del");
		}
		Thread.sleep(2000);
		dr.quit();
	}
	//@Test
	public static void cms_Vse_Creation_India() throws Exception {
		readpropertiesdata();
		openCMS_WEB();
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PartnerMangement);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_PartnerManagement_DropDown");
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_BusinessPartner);
		Thread.sleep(3000);
		Assert_TextValue("Business Partner",GetText(dr,CMS_BusinessPartner.Cms_BusinessPartner_Navbar_Title));
		TakeScreenshot(dr,"CMS_BusinessPartner_Page");
		Click_Element(dr,CMS_BusinessPartner.Cms_BusinessPartner_CreateNew);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_BusinessPartner_CreateNew");
		Click_Element(dr,CMS_BusinessPartner.Cms_BusinessPartner_VSE);
		Thread.sleep(2000);
		Assert_TextValue("Create Vigo Service Enabler",GetText(dr,CMS_VSE_Form.Cms_Vse_Navbar_Title));
		TakeScreenshot(dr,"CMS_VSE_Ind_FormBefore");
		String VSEName=EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Name,"CMSVSENAME","",0,4);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_License_Number,"CMSVSELICNUM","",0,6);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_First_Name,"CMSVSEFIRSTNAME","",0,4);
		String VSE_PhNo=EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Primary_Phone_Number,"CMSVSEPHNO","",0,7);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Address_Line1,"CMSVSEADDR1","",0,5);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Pincode,"CMSVSEPINCODE","",0,6);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_User_Name,"CMSVSEUNAME","",0,4);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Password,"CMSVSEPWD","",0,4);
		Click_Element(dr,CMS_VSE_Form.Cms_Vse_Password_View);
		Thread.sleep(1000);
		TakeScreenshot(dr,"CMS_VSE_Ind_FormAfter");
		Click_Element(dr,CMS_VSE_Form.Cms_Vse_Save_Button);
		TakeScreenshot(dr,"CMS_VSE_Ind_CreateAlert");
		Thread.sleep(3000);
		//verification
		if(true) {
			Cms_Vse_Verification(VSEName,VSE_PhNo,"91");
			Delete_ClickOn_TrashBin();
			Thread.sleep(1000);
			TakeScreenshot(dr,"CMS_VSE_Aus_Del");
		}
		Thread.sleep(2000);
		dr.quit();	
	}

	//@Test
	public static void cms_Vse_Creation_Australia() throws Exception {
		readpropertiesdata();
		openCMS_WEB();
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PartnerMangement);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_PartnerManagement_DropDown");
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_BusinessPartner);
		Thread.sleep(3000);
		Assert_TextValue("Business Partner",GetText(dr,CMS_BusinessPartner.Cms_BusinessPartner_Navbar_Title));
		TakeScreenshot(dr,"CMS_BusinessPartner_Page");
		Click_Element(dr,CMS_BusinessPartner.Cms_BusinessPartner_CreateNew);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_BusinessPartner_CreateNew");
		Click_Element(dr,CMS_BusinessPartner.Cms_BusinessPartner_VSE);
		Thread.sleep(2000);
		Assert_TextValue("Create Vigo Service Enabler",GetText(dr,CMS_VSE_Form.Cms_Vse_Navbar_Title));
		TakeScreenshot(dr,"CMS_VSE_Aus_FormBefore");
		Click_Element(dr,CMS_VSE_Form.Cms_Vse_Country);
		Thread.sleep(2000);
		Click_Element(dr,CMS_VSE_Form.Cms_Vse_Country_Australia);
		Thread.sleep(2000);
		String VSE_PhNo=EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Primary_Phone_Number,"CMSVSEPHNO","",0,6);
		String VSEName=EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Name,"CMSVSENAME","",0,3);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_License_Number,"CMSVSELICNUM","",0,6);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_First_Name,"CMSVSEFIRSTNAME","",0,4);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Address_Line1,"CMSVSEADDR1","",0,5);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Pincode,"CMSVSEPINCODE","",0,6);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_User_Name,"CMSVSEUNAME","",0,4);
		EnterRandomData(dr,CMS_VSE_Form.Cms_Vse_Password,"CMSVSEPWD","",0,4);
		Click_Element(dr,CMS_VSE_Form.Cms_Vse_Password_View);
		Thread.sleep(3000);
		TakeScreenshot(dr,"CMS_VSE_Aus_FormAfter");
		Click_Element(dr,CMS_VSE_Form.Cms_Vse_Save_Button);
		TakeScreenshot(dr,"CMS_VSE_Aus_CreateAlert");
		Thread.sleep(3000);
		//verification
		if(true) {
			Cms_Vse_Verification(VSEName,VSE_PhNo,"61");
			Thread.sleep(2000);
			Delete_ClickOn_TrashBin();
			Thread.sleep(2000);
			TakeScreenshot(dr,"CMS_VSE_Aus_Del");
		}
		Thread.sleep(2000);
		dr.quit();	
	}
	//@Test 
	public static void cms_Vse_Service_Subscription() throws Exception {
		String vseName="autom1234567";
		String[] services= {"BBPVSP","Smart Heart"};
		//	Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PartnerMangement);
		//	Thread.sleep(2000);
		//	TakeScreenshot(dr,"CMS_PartnerManagement_DropDown");
		//	Click_Element(dr,CMS_Dashboard.Cms_Dashboard_BusinessPartner);
		//	Thread.sleep(3000);
		//	Assert_TextValue("Business Partner",GetText(dr,CMS_BusinessPartner.Cms_BusinessPartner_Navbar_Title));
		//	TakeScreenshot(dr,"CMS_BusinessPartner_Page");
		//	EnterText(dr,CMS_Common_PageElements.Cms_SearchBox,vseName);
		//	Click_Element(dr,CMS_Common_PageElements.Cms_SearchButton);
		//	Thread.sleep(2000);
		//	TakeScreenshot(dr,"CMS_VSE_Search");
		//	if(dr.findElements(By.xpath("//table/tbody/tr")).size()==0) { 
		//		System.out.print("no vse found with the name: "+vseName);
		//		return;
		//		}
		WebElement html = dr.findElement(By.tagName("html"));
		html.sendKeys(Keys.chord(Keys.CONTROL, "80"));
		Click_Element(dr,CMS_Common_PageElements.Cms_Edit_Button);
		html.sendKeys(Keys.chord(Keys.CONTROL, "100"));
		Thread.sleep(2000);
		Assert_TextValue("Edit Vigo Service Enabler",GetText(dr,CMS_VSE_EditPage.Cms_VseEdit_Navbar_Title));
		TakeScreenshot(dr,"CMS_VSE_BeforeEdit");
		Click_Element(dr,CMS_VSE_EditPage.Cms_VseEdit_Services);
		Thread.sleep(2000);
		Select_Multiple_FromDropDown(dr,CMS_VSE_EditPage.Cms_VseEdit_Services,CMS_VSE_EditPage.Cms_VseEdit_ServicesSearch,services);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_VSE_BeforeEdit");
		Click_Element(dr,CMS_Common_PageElements.Cms_Form_SaveButton);
		//verification
		if(true) {
			Cms_Vse_Subscribtion_verify(vseName,services);
		}

	}

	//@Test
	public static void cms_Vsp_Creation() throws Exception {
		String vseName="Giribabu VSE";
		String country="INDIA";
		String countryCode="91";
		String[] role={"Accounts"};
		int numSize= (countryCode=="91")?7:6;
		readpropertiesdata();
		openCMS_WEB();
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PartnerMangement);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_PartnerManagement_DropDown");
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_BusinessPartner);
		Thread.sleep(3000);
		Assert_TextValue("Business Partner",GetText(dr,CMS_BusinessPartner.Cms_BusinessPartner_Navbar_Title));
		TakeScreenshot(dr,"CMS_BusinessPartner_Page");
		Click_Element(dr,CMS_BusinessPartner.Cms_BusinessPartner_CreateNew);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_BusinessPartner_CreateNew");
		Click_Element(dr,CMS_BusinessPartner.Cms_BusinessPartner_VSP);
		Thread.sleep(2000);
		Assert_TextValue("Create Business Partner",GetText(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_NavbarTitle));
		TakeScreenshot(dr,"CMS_VSP_FormBefore");
		String vspName=EnterRandomData(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_Name,"CMS_BP_NAME","",0,3);
		EnterRandomData(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_Website,"CMS_BP_WEBSITE",".com",0,3);
		EnterRandomData(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_Address1,"","",3,3);
		EnterRandomData(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_Pincode,"","",0,6);
		Select_FromDropdown_UsingSearchText(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_SelectVSe,vseName);
		Thread.sleep(2000);
		Select_FromDropdown_UsingSearchText(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_Country,country);
		WebElement html = dr.findElement(By.tagName("html"));
		html.sendKeys(Keys.chord(Keys.CONTROL, "80"));
		Thread.sleep(2000);
		EnterRandomData(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_Fname,"CMS_BP_NAME","",0,3);
		EnterRandomData(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_Email,"CMS_BP_EMAIL","@vigocare.com",0,3);
		Click_Element(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_RoleDrpDown);
		for(int i=0;i<role.length;i++) {
			Thread.sleep(2000);
			Click_Element(dr,By.xpath("//span[contains(text(),'"+role[i]+"')]"));
		}
		Thread.sleep(2000);
		Select_FromDropdown_UsingSearchText(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_MobileDrpDown,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_MobCountryList,countryCode);
		String mobile=EnterRandomData(dr,CMS_BusinessPartnerForm.Cms_BusinessPartnerForm_Mobile,"CMS_BP_PHNO","",0,numSize);
		TakeScreenshot(dr,"CMS_VSP_FormAfter");
		Thread.sleep(2000);
		Click_Element(dr,CMS_Common_PageElements.Cms_Form_SaveButton);
		TakeScreenshot(dr,"CMS_VSP_Create_Alert");
		Thread.sleep(3000);
		//verification
		if(true) {
			cms_Vsp_Verification(vspName,vseName,mobile,countryCode);
			Delete_ClickOn_TrashBin();
			Thread.sleep(2000);
			TakeScreenshot(dr,"CMS_VSP_Del");
		}
		Thread.sleep(2000);
		dr.quit();
	}

	//@Test
	public static void cms_Agent_creation() throws Exception {
		String role="SUPERADMIN";
		String CountryCode="91";
		int numSize= (CountryCode=="91")?7:6;
		readpropertiesdata();
		openCMS_WEB();
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PartnerMangement);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_PartnerManagement_DropDown");
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_Agents);
		Thread.sleep(3000);
		Assert_TextValue("Agents",GetText(dr,CMS_Agents.Cms_Agents_Navbar_Title));
		TakeScreenshot(dr,"CMS_Agent_Page");
		Click_Element(dr,CMS_Agents.Cms_Agents_CreateNew);
		Thread.sleep(2000);
		Assert_TextValue("Create Agent",GetText(dr,CMS_Agents_Form.Cms_AgentsForm_Navbar_Title));
		TakeScreenshot(dr,"CMS_AgentForm_Before");
		Select_FromDropdown_UsingSearchText(dr,CMS_Agents_Form.Cms_Agents_Mobile_DrpDown,CMS_Agents_Form.Cms_Agents_Mob_CountryList,CountryCode);
		String mobile = EnterRandomData(dr,CMS_Agents_Form.Cms_Agents_Mobile,"CMS_AGENTS_MOB","",0,numSize);
		String fname = EnterRandomData(dr,CMS_Agents_Form.Cms_Agents_FirstName,"CMS_AGENTS_FNAME","",0,3);
		String lname = EnterRandomData(dr,CMS_Agents_Form.Cms_Agents_LastName,"CMS_AGENTS_LNAME","",3,0);
		String email = EnterRandomData(dr,CMS_Agents_Form.Cms_Agents_Email,"CMS_AGENTS_EMAIL","@vigocare.com",0,4);
		String password=EnterRandomData(dr,CMS_Agents_Form.Cms_Agents_Password,"CMS_AGENTS_PASSWORD","",6,0);
		Click_Element(dr,CMS_Agents_Form.Cms_Agents_PasswordView);
		EnterText(dr,CMS_Agents_Form.Cms_Agents_ConfirmPassword,password);
		Click_Element(dr,CMS_Agents_Form.Cms_Agents_ConfirmPasswordView);
		Select_FromDropdown_UsingSearchText(dr,CMS_Agents_Form.Cms_Agents_SelectRole,role);
		TakeScreenshot(dr,"CMS_AgentsForm_After");
		Click_Element(dr,CMS_Agents_Form.Cms_Agents_SaveButton);
		TakeScreenshot(dr,"CMS_Agent_Create_Alert");
		Thread.sleep(3000);
		//verification
		if(true) {
			Cms_Agent_Verification(fname,lname,email,mobile,role,CountryCode);
			Delete_ClickOn_TrashBin();
			Thread.sleep(2000);
			TakeScreenshot(dr,"CMS_Agent_Del");
		}
		Thread.sleep(2000);
		dr.quit();

	}
	//@Test
	public static void cms_Nurse_creation() throws Exception {
		String CountryCode="61";
		String busPartner="Giribabu VSE";
		String speciality="Neurosurgery";
		int numSize= (CountryCode=="91")?7:6;
		readpropertiesdata();
		openCMS_WEB();
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PartnerMangement);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_PartnerManagement_DropDown");
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_Nurses);
		Thread.sleep(3000);
		Assert_TextValue("Nurses",GetText(dr,CMS_Nurse.Cms_Nurse_Navbar_Title));
		TakeScreenshot(dr,"CMS_Nurses_Page");
		Click_Element(dr,CMS_Common_PageElements.Cms_CreateNew);
		Thread.sleep(2000);
		Assert_TextValue("Create Nurse",GetText(dr,CMS_Nurse_Form.Cms_NurseForm_Navbar_Title));
		TakeScreenshot(dr,"CMS_NurseForm_Before");
		String fname= EnterRandomData(dr,CMS_Nurse_Form.Cms_NurseForm_FirstName,"CMS_NURSE_FNAME","",0,3);
		String lname= EnterRandomData(dr,CMS_Nurse_Form.Cms_NurseForm_LastName,"CMS_NURSE_LNAME","",3,0);
		String email = EnterRandomData(dr,CMS_Nurse_Form.Cms_NurseForm_Email,"CMS_NURSE_EMAIL","@vigocare.com",0,3);
		Select_FromDropdown_UsingSearchText(dr,CMS_Nurse_Form.Cms_NurseForm_MobileDrpDown,CMS_Nurse_Form.Cms_NurseForm_MobCountry_List,CountryCode);
		String mobile= EnterRandomData(dr,CMS_Nurse_Form.Cms_NurseForm_Mobile,"CMS_NURSE_MOB","",0,numSize);
		Select_FromDropdown_UsingSearchText(dr,CMS_Nurse_Form.Cms_NurseForm_Speciality,speciality);
		Select_FromDropdown_UsingSearchText(dr,CMS_Nurse_Form.Cms_NurseForm_Hospital,busPartner);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_NurseForm_After");
		Click_Element(dr,CMS_Common_PageElements.Cms_Form_SaveButton);
		TakeScreenshot(dr,"CMS_NurseCreate_Alert");
		Thread.sleep(2000);
		//verification
		if(true) {
			Cms_Nurse_Verification(fname,lname,email,busPartner,speciality,mobile,CountryCode);
			Delete_ClickOn_TrashBin();
			Thread.sleep(2000);
			TakeScreenshot(dr,"CMS_Nurse_Del");
		}
		Thread.sleep(2000);
		dr.quit();
	}
}
