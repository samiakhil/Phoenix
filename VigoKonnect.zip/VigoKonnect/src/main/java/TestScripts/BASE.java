package TestScripts;

import java.io.FileInputStream;
import java.lang.module.Configuration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;

import PageElements.CMS_Login;
import Reusable.Reusable;
import Reusable.CommonMethods;
import io.github.bonigarcia.wdm.WebDriverManager;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.github.bonigarcia.wdm.WebDriverManager;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.testng.annotations.Test;

import org.json.JSONObject;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

public class BASE extends CommonMethods {
	public static String accessToken="";
	public static String vseName="";
	public static String vseAdminName="";
	public static String vseAssociateName="";
	public static String vspName="";
	public static String vspAdminName="";
	public static String vspAssociateName="";
	public static String vseDoctorName="";
	public static String vspDoctorName="";
	public static String vseid="";
	public static String vspid="";
	public static String vseDoctorId="";
	public static String vspDoctorid="";
	@BeforeSuite
	public static void API_Create_BusinessPartners() throws Exception {
		//admin login
		String reqbody = "{"
				+ "\"email\":\"saikrishna.b@vigocare.com\","
				+ "\"password\":\"changeme\""
				+ "}";
		String phno=RandomStringUtils.random(10, false, true);
		String random4Dig=RandomStringUtils.random(4, false, true);
		String random6Dig=RandomStringUtils.random(6, false, true);
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/auth/partner/login")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject obj=new JSONObject(getResponse.getBody().asString());
		accessToken=obj.getString("accessToken");
		//vse creation
		reqbody = "{"
				+ "\"firstName\":\"apiVSEAdmin"+random6Dig+"\","
				+ "\"lastName\":\"\","
				+ "\"name\":\"apiVSE"+random4Dig+"\","
				+ "\"licenseNumber\":\"123456\","
				+ "\"addressLine1\":\"addr1\","
				+ "\"addressLine2\":\"\","
				+ "\"pinCode\":\"123456\","
				+ "\"id\":\"\","
				+ "\"email\":\"\","
				+ "\"isServiceEnabler\":true,"
				+ "\"isActive\":true,"
				+ "\"loginId\":\"apiVSEAdmin"+random4Dig+"\","
				+ "\"password\":\"changeme\","
				+ "\"website\":\"\","
				+ "\"location\":\"\","
				+ "\"reportPassword\":\"changeme\","
				+ "\"country\":\"INDIA\","
				+ "\"mobile\":"
				+ "{\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\"},"
				+ "\"alternateMobile\":"
				+ "{\"countryCode\":\"\",\"number\":\"\"},"
				+ "\"note\":"
				+ "{\"reason\":\"\"},"
				+ "\"services\":["
				+ "{"
				+ "\"id\":\"6322ae6b1af70d0021da7e3e\","
				+ "\"name\":\"BBPBSPO2\""
				+ "},"
				+ "{"
				+ "\"id\":\"6369e3bf3c61f80022966520\","
				+ "\"name\":\"Vigo Life\""
				+ "},"
				+ "{"
				+ "\"id\":\"6396cc15aa09ed00249e6401\","
				+ "\"name\":\"testService\""
				+ "},"
				+ "{"
				+ "\"id\":\"6166b6c474eba30020255322\","
				+ "\"name\":\"SmartHeart\""
				+ "},"
				+ "{"
				+ "\"id\":\"611b8ec12e29f40020dac640\","
				+ "\"name\":\"BSM_Viatom\""
				+ "}]"
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/")
				.then()
				.statusCode(HttpStatus.SC_CREATED)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		vseid=obj.getString("_id");
		String serviceEnabler=obj.get("serviceEnabler").toString();
		vseName=new JSONObject(serviceEnabler).getString("name");
		System.out.println("VSE NAME : "+vseName);

		//vse admin creation
		phno=RandomStringUtils.random(10, false, true);
		random4Dig=RandomStringUtils.random(4, false, true);
		reqbody="{"
				+ "\"platformPartner\":\"5f0db03243f92120fe61ddba\","
				+ "\"businessPartners\":["
				+ "{\"businessPartnerId\":\""+vseid+"\","
				+ "\"businessPartnerName\":\""+vseName+"\","
				+ "\"email\":\"api@vigocare.com\","
				+ "\"isActive\":true,"
				+ "\"roles\":["
				+ "{\"role\":\"ADMIN\"}"
				+ "],"
				+ "\"isServiceEnabler\":true}"
				+ "],"
				+ "\"firstName\":\"apiVSEAdmin"+random4Dig+"\","
				+ "\"lastName\":\"\","
				+ "\"id\":\"\","
				+ "\"password\":\"changeme\","
				+ "\"confirmPassword\":\"changeme\","
				+ "\"businessPartnerId\":\""+vseid+"\","
				+ "\"email\":\"api@vigocare.com\","
				+ "\"businessPartnerName\":\""+vseName+"\","
				+ "\"userType\":\"AGENT\","
				+ "\"username\":\"apiVSEAdmin"+random4Dig+"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"loginId\":\"apiVSEAdmin"+random4Dig+"\""
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/userAgents/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		vseAdminName=obj.get("loginId").toString();
		System.out.println("VSE Admin NAME : "+vseAdminName);		

		//vse associate creation
		phno=RandomStringUtils.random(10, false, true);
		random4Dig=RandomStringUtils.random(4, false, true);
		reqbody="{"
				+ "\"platformPartner\":\"5f0db03243f92120fe61ddba\","
				+ "\"businessPartners\":["
				+ "{\"businessPartnerId\":\""+vseid+"\","
				+ "\"businessPartnerName\":\""+vseName+"\","
				+ "\"email\":\"api@vigocare.com\","
				+ "\"isActive\":true,"
				+ "\"roles\":["
				+ "{\"role\":\"ASSOCIATE\"}"
				+ "],"
				+ "\"isServiceEnabler\":true}"
				+ "],"
				+ "\"firstName\":\"apiVSEAssociate"+random4Dig+"\","
				+ "\"lastName\":\"\","
				+ "\"id\":\"\","
				+ "\"password\":\"changeme\","
				+ "\"confirmPassword\":\"changeme\","
				+ "\"businessPartnerId\":\""+vseid+"\","
				+ "\"email\":\"api@vigocare.com\","
				+ "\"businessPartnerName\":\""+vseName+"\","
				+ "\"userType\":\"AGENT\","
				+ "\"username\":\"apiVSEAssociate"+random4Dig+"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"loginId\":\"apiVSEAssociate"+random4Dig+"\""
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/userAgents/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		vseAssociateName=obj.get("loginId").toString();
		System.out.println("VSE Associate NAME : "+vseAssociateName);			
		//vsp creation
		phno=RandomStringUtils.random(10, false, true);
		random4Dig=RandomStringUtils.random(4, false, true);
		random6Dig=RandomStringUtils.random(6, false, true);
		reqbody="{"
				+ "\"id\":\"\","
				+ "\"name\":\"apiVSP"+random6Dig+"\","
				+ "\"uniqueId\":\"\","
				+ "\"website\":\"http://vigocare.co.in\","
				+ "\"location\":\"\","
				+ "\"isActive\":true,"
				+ "\"email\":\"\","
				+ "\"logo\":\"\","
				+ "\"serviceEnabler\":{"
				+ "\"id\":\""+vseid+"\","
				+ "\"name\":\""+vseName+"\""
				+ "},"
				+ "\"addressLine1\":\"addr1\","
				+ "\"addressLine2\":\"\","
				+ "\"pinCode\":\"123456\","
				+ "\"status\":\"NOT_VERIFIED\","
				+ "\"isServiceEnabler\":false,"
				+ "\"services\":[{"
				+ "\"id\":\"6322ae6b1af70d0021da7e3e\","
				+ "\"name\":\"BBPBSPO2\""
				+ "},"
				+ "{"
				+ "\"id\":\"6369e3bf3c61f80022966520\","
				+ "\"name\":\"Vigo Life\""
				+ "},"
				+ "{"
				+ "\"id\":\"6396cc15aa09ed00249e6401\","
				+ "\"name\":\"testService\""
				+ "},"
				+ "{"
				+ "\"id\":\"6166b6c474eba30020255322\","
				+ "\"name\":\"SmartHeart\""
				+ "},"
				+ "{"
				+ "\"id\":\"611b8ec12e29f40020dac640\","
				+ "\"name\":\"BSM_Viatom\""
				+ "}],"
				+ "\"reportPassword\":\"\","
				+ "\"country\":\"INDIA\","
				+ "\"mobile\":"
				+ "{"
				+ "\"countryCode\":\"\","
				+ "\"number\":\"\","
				+ "\"id\":\"\""
				+ "},"
				+ "\"note\":"
				+ "{\"reason\":\"\"},"
				+ "\"contact\":["
				+ "{"
				+ "\"firstName\":\"apiVSP\","
				+ "\"lastName\":\"\","
				+ "\"email\":\"apiVSP"+random4Dig+"@vigocare.com\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"permission\":[\"ACCOUNTS\"],"
				+ "\"isPrimary\":true,"
				+ "\"isRefresh\":true"
				+ "}],"
				+ "\"layout\":["
				+ "{"
				+ "\"layoutName\":\"FLOOR\","
				+ "\"layoutValues\":[\"\"]"
				+ "}"
				+ "]}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/")
				.then()
				.statusCode(HttpStatus.SC_CREATED)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		vspName=obj.get("name").toString();
		System.out.println("VSP NAME : "+vspName);
		vspid=obj.getString("_id");
		//vsp admin creation
		phno=RandomStringUtils.random(10, false, true);
		random4Dig=RandomStringUtils.random(4, false, true);
		reqbody="{"
				+ "\"platformPartner\":\"5f0db03243f92120fe61ddba\","
				+ "\"businessPartners\":["
				+ "{\"businessPartnerId\":\""+vspid+"\","
				+ "\"businessPartnerName\":\""+vspName+"\","
				+ "\"email\":\"api@vigocare.com\","
				+ "\"isActive\":true,"
				+ "\"roles\":["
				+ "{\"role\":\"ADMIN\"}"
				+ "],"
				+ "\"isServiceEnabler\":false}"
				+ "],"
				+ "\"firstName\":\"apiVSPAdmin"+random4Dig+"\","
				+ "\"lastName\":\"\","
				+ "\"id\":\"\","
				+ "\"password\":\"changeme\","
				+ "\"confirmPassword\":\"changeme\","
				+ "\"businessPartnerId\":\""+vspid+"\","
				+ "\"email\":\"api@vigocare.com\","
				+ "\"businessPartnerName\":\""+vspName+"\","
				+ "\"userType\":\"AGENT\","
				+ "\"username\":\"apiVSPAdmin"+random4Dig+"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"loginId\":\"apiVSPAdmin"+random4Dig+"\""
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/userAgents/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		vspAdminName=obj.get("loginId").toString();
		System.out.println("VSP Admin NAME : "+vspAdminName);
		//vsp associate creation
		phno=RandomStringUtils.random(10, false, true);
		random4Dig=RandomStringUtils.random(4, false, true);
		reqbody="{"
				+ "\"platformPartner\":\"5f0db03243f92120fe61ddba\","
				+ "\"businessPartners\":["
				+ "{\"businessPartnerId\":\""+vspid+"\","
				+ "\"businessPartnerName\":\""+vspName+"\","
				+ "\"email\":\"api@vigocare.com\","
				+ "\"isActive\":true,"
				+ "\"roles\":["
				+ "{\"role\":\"ASSOCIATE\"}"
				+ "],"
				+ "\"isServiceEnabler\":false}"
				+ "],"
				+ "\"firstName\":\"apiVSPAssociate"+random4Dig+"\","
				+ "\"lastName\":\"\","
				+ "\"id\":\"\","
				+ "\"password\":\"changeme\","
				+ "\"confirmPassword\":\"changeme\","
				+ "\"businessPartnerId\":\""+vspid+"\","
				+ "\"email\":\"api@vigocare.com\","
				+ "\"businessPartnerName\":\""+vspName+"\","
				+ "\"userType\":\"AGENT\","
				+ "\"username\":\"apiVSPAssociate"+random4Dig+"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"loginId\":\"apiVSPAssociate"+random4Dig+"\""
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/userAgents/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		vspAssociateName=obj.get("loginId").toString();
		System.out.println("VSP Associate NAME : "+vspAssociateName);	
		//vse doctor creation
		phno=RandomStringUtils.random(10, false, true);
		random4Dig=RandomStringUtils.random(4, false, true);
		reqbody="{"
				+ "\"businessPartners\":["
				+ "{"
				+ "\"businessPartnerId\":\""+vseid+"\","
				+ "\"businessPartnerName\":\""+vseName+"\","
				+ "\"location\":\"\","
				+ "\"displayName\":\"apiVSEDoctor"+random4Dig+"\","
				+ "\"speciality\":\"Cardiology\","
				+ "\"providerNumber\":\"\","
				+ "\"email\":\"\","
				+ "\"layout\":[],"
				+ "\"country\":\"INDIA\","
				+ "\"roles\":["
				+ "{"
				+ "\"role\":\"INTERNAL_DOCTOR\""
				+ "}]"
				+ "}],"
				+ "\"firstName\":\"apiVSEDoctor"+random4Dig+"\","
				+ "\"lastName\":\"test\","
				+ "\"id\":\"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"role\":\"DOCTOR\","
				+ "\"country\":\"INDIA\","
				+ "\"MCIRegNumber\":\"\""
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		vseDoctorName=obj.get("firstName").toString();
		vseDoctorId=obj.get("id").toString();
		System.out.println("VSE DOCTOR NAME : "+vseDoctorName);
		//vsp doctor creation
		phno=RandomStringUtils.random(10, false, true);
		random4Dig=RandomStringUtils.random(4, false, true);
		reqbody="{"
				+ "\"businessPartners\":["
				+ "{"
				+ "\"businessPartnerId\":\""+vspid+"\","
				+ "\"businessPartnerName\":\""+vspName+"\","
				+ "\"location\":\"\","
				+ "\"displayName\":\"apiVSPDoctor"+random4Dig+"\","
				+ "\"speciality\":\"Cardiology\","
				+ "\"providerNumber\":\"\","
				+ "\"email\":\"\","
				+ "\"layout\":[],"
				+ "\"country\":\"INDIA\","
				+ "\"roles\":["
				+ "{"
				+ "\"role\":\"INTERNAL_DOCTOR\""
				+ "}]"
				+ "}],"
				+ "\"firstName\":\"apiVSPDoctor"+random4Dig+"\","
				+ "\"lastName\":\"test\","
				+ "\"id\":\"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"role\":\"DOCTOR\","
				+ "\"country\":\"INDIA\","
				+ "\"MCIRegNumber\":\"\""
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		vspDoctorName=obj.get("firstName").toString();
		System.out.println("VSP DOCTOR NAME : "+vspDoctorName);
		vspDoctorid=obj.get("id").toString();


		System.out.println("VSE id : "+vseid);
		System.out.println("VSP id : "+vspid);
		System.out.println("VSE Doctor id : "+vseDoctorId);

	}

	@BeforeTest
	public static void Launch_MobileApp() throws Exception{
		/*UiAutomator2Options option = new UiAutomator2Options();
		option.setDeviceName("vigo");
		option.setApp("//home//vigo//Downloads//VigoKonnect-qa-v4.4-debug (1).apk");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723"), option);
		Thread.sleep(1000);
		implicitWait(driver, 10);*/
		System.out.println("== Before Test == \tApp Launched");
		Thread.sleep(1000);
		readpropertiesdata();
		LaunchApp();
		System.out.println("Launch completed");
	}
	@AfterSuite
	public static void API_Delete_BusinessPartners() {
		System.out.println("API DELETION");
		//vsp deletion
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.delete("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vspid)
				.then()
				.statusCode(HttpStatus.SC_NO_CONTENT)
				.extract()
				.response();
		//vse deletion
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.delete("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+vseid)
				.then()
				.statusCode(HttpStatus.SC_NO_CONTENT)
				.extract()
				.response();

	}
	@AfterTest
	public void tearDown() {
		System.out.println("==After Test==\tDriver quit");
		driver.quit();
	}
}
