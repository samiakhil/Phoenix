package TestScripts;


import org.openqa.selenium.By;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Reusable.Customlisteners;
import CommonPages.AddUserAgents;
import PageElements.VKT_AddAssociates;
import PageElements.VKT_DashboardPage;
import PageElements.VKT_SideMenu;
@Listeners(Customlisteners.class)
public class AddUserAgentsScript extends BASE{
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//1. missing all fields and click submit.
	public void VKTTS10TC001() throws Exception{
		System.out.println("===============VKTTS10TC001 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,false);
		AU.emptyAllFields();
		
		Thread.sleep(1000);
		vertical_scroll_up(driver);
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		Assert_TextValue("Please enter first name",GetText(driver,VKT_AddAssociates.VKT_firstNameError));
		Thread.sleep(5000);
		
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		Thread.sleep(500);
		AssociatesPage_To_Logout();
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//2. filling all the fields with mandatory inputs and click submit.
	public void vse_creating_associate_with_all_fields() throws Exception{
		System.out.println("===============VKTTS10TC002 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,false);
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		//logout
		AssociatesPage_To_Logout();
		
		
		Login_VigoKonnect_Username(AU.userName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
		
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//3. Iteratively missing one mandatory field and click submit.
	public void VKTTS10TC003() throws Exception{
		System.out.println("===============VKTTS10TC003 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();

		AddUserAgents AU = new AddUserAgents(true,false);
		String firstName=AU.firstName;
		String username=AU.userName;
		String pwd=AU.password;
		
		//firstname is missing
		AU.firstName="";
		AU.Formfill();
		
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		Assert_TextValue("Please enter first name",GetText(driver,VKT_AddAssociates.VKT_firstNameError));
		TakeScreenshot(driver,"VKT_FirstNameError");
		
		Thread.sleep(5000);

		//username is missing
		EnterText(driver,VKT_AddAssociates.VKT_firstName,firstName);
		Thread.sleep(500);
		EnterText(driver,VKT_AddAssociates.VKT_userName,"");
		Thread.sleep(500);
		
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		Assert_TextValue("Please enter Username",GetText(driver,VKT_AddAssociates.VKT_ErrorMsg));
		TakeScreenshot(driver,"VKT_UserNameError");
		
		Thread.sleep(5000);
		
		//password is missing
		EnterText(driver,VKT_AddAssociates.VKT_userName,username);
		Thread.sleep(500);
		EnterText(driver,VKT_AddAssociates.VKT_password,"");
		Thread.sleep(500);
		vertical_scroll_up(driver);
		
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		Assert_TextValue("Please enter password",GetText(driver,VKT_AddAssociates.VKT_ErrorMsg));
		TakeScreenshot(driver,"VKT_PasswordError");
		
		Thread.sleep(5000);
		
		//confirm password is missing
		EnterText(driver,VKT_AddAssociates.VKT_password,pwd);
		Thread.sleep(500);
		EnterText(driver,VKT_AddAssociates.VKT_confirmPassword,"");
		Thread.sleep(500);
		
		vertical_scroll_up(driver);
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		Assert_TextValue("Please enter confirm password",GetText(driver,VKT_AddAssociates.VKT_ErrorMsg));
		TakeScreenshot(driver,"VKT_ConfirmPasswordError");
		
		Thread.sleep(5000);
		
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		Thread.sleep(500);
		AssociatesPage_To_Logout();
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//4. filling all mandatory fields with valid inputs and using existing username and click submit.
	public void VKTTS10TC004() throws Exception{
		System.out.println("===============VKTTS10TC004 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,false);
		AU.FillOptionalFields();
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		//logout
		//AssociatesPage_To_Logout();
		//Login_VigoKonnect_Username(AU.userName);
		//Logout_VigoKonnect();
		
		Thread.sleep(2000);
		Click_Element(driver,VKT_SideMenu.VKT_AddAssociateButtonImage);
		//Again creating with existing username
		AddUserAgents obj = new AddUserAgents(true,false);
		obj.userName = AU.userName;
		obj.FillOptionalFields();
		obj.Formfill();
		Assert_TextValue("This Username is already taken. Please try with different Username",GetText(driver,VKT_AddAssociates.VKT_UserNameExistError));
		
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		//Assert_TextValue("Please enter Valid Username",GetText(driver,VKT_AddAssociates.VKT_ErrorMsg));
		TakeScreenshot(driver,"VKT_UserNameExistError");
		
		Thread.sleep(5000);
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		Thread.sleep(500);
		AssociatesPage_To_Logout();
	}
		
	//@Test//(retryAnalyzer = Customlisteners.class)
	//5. filling all mandatory fields with valid inputs and using username less than 6 characaters and click submit.
	public void VKTTS10TC005() throws Exception{
		System.out.println("===============VKTTS10TC005 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,false);
		AU.userName="usern";
		AU.FillOptionalFields();
		AU.Formfill();
		
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		Assert_TextValue("Username should contain minimum 6 characters.",GetText(driver,VKT_AddAssociates.VKT_UserNameCharactersLimitError));
		TakeScreenshot(driver,"VKT_UserNameExistError");
		
		Thread.sleep(5000);
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		Thread.sleep(500);
		AssociatesPage_To_Logout();
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//6. filling all mandatory fields with valid inputs and using password and confirm password less than 6 characaters and click submit. 
	public void VKTTS10TC006() throws Exception{
		System.out.println("===============VKTTS10TC006 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,false);
		AU.password="chan";
		AU.confirmPassword="chan";
		AU.FillOptionalFields();
		AU.Formfill();
		
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		Assert_TextValue("Password should contain minimum 6 characters.",GetText(driver,VKT_AddAssociates.VKT_PasswordError));
		Assert_TextValue("Confirm Password should contain minimum 6 characters.",GetText(driver,VKT_AddAssociates.VKT_ConfirmPasswordError));
		TakeScreenshot(driver,"VKT_Password_ConfirmPasswordError");
		
		Thread.sleep(5000);
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		Thread.sleep(500);
		AssociatesPage_To_Logout();
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//7. filling all mandatory fields with valid inputs and mismatching password and confrim password and click submit.
	public void VKTTS10TC007() throws Exception{
		System.out.println("===============VKTTS10TC007 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,false);
		AU.confirmPassword="pass1234";
		AU.FillOptionalFields();
		AU.Formfill();
		
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		Assert_TextValue("Password & confirm password doesn't match",GetText(driver,VKT_AddAssociates.VKT_PasswordError));
		TakeScreenshot(driver,"VKT_PasswordMismatchError");
		
		Thread.sleep(5000);
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		Thread.sleep(500);
		AssociatesPage_To_Logout();
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//8. filling all the fields with valid inputs and click submit. (VSE Associate)
	public void vse_creating_vse_associate() throws Exception{
		System.out.println("===============VKTTS10TC008 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,false);
		AU.FillOptionalFields();
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		//logout
		AssociatesPage_To_Logout();
		
		
		Login_VigoKonnect_Username(AU.userName);
		Logout_VigoKonnect();
		
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//9. filling all the fields with valid inputs and click submit. (VSE Admin)
	public void vse_creating_vse_admin() throws Exception{
		System.out.println("===============VKTTS10TC009 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,true);
		AU.FillOptionalFields();
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		//logout
		AssociatesPage_To_Logout();
		
		
		Login_VigoKonnect_Username(AU.userName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
		
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//10. filling all the fields with valid inputs and click submit. (VSP Associate)
	public void vsp_creating_vsp_associate() throws Exception{
		System.out.println("===============vsp_creating_vsp_associate (VKTTS10TC010) started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(false,false);
		AU.FillOptionalFields();
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		//logout
		AssociatesPage_To_Logout();
		
		
		Login_VigoKonnect_Username(AU.userName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
		
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//11. filling all the fields with valid inputs and click submit. (VSP Admin)
	public void vsp_creating_vsp_admin() throws Exception{
		System.out.println("===============vsp_creating_vsp_admin (VKTTS10TC011) started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(false,true);
		AU.FillOptionalFields();
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		//logout
		AssociatesPage_To_Logout();
		
		
		Login_VigoKonnect_Username(AU.userName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
		
	}
	
	@Test(retryAnalyzer = Customlisteners.class)
	//12. filling mandatory fields with valid inputs and click submit.
	public void VKTTS10TC012() throws Exception{
		System.out.println("===============VKTTS10TC012 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();
		
		AddUserAgents AU = new AddUserAgents(true,true);
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		AU.firstName+="edit";
		AU.lastName+="edit";
		AU.email="apitestedit@vigo.com";
		AU.role="ASSOCIATE";
		AU.password="pass1234";
		AU.confirmPassword="pass1234";
		AU.isAdmin=false;
		AddUserAgents.editUserAgent(AU);
		implicitWait(driver,1000);
		Click_Element(driver,VKT_AddAssociates.VKT_DoneButton);
		AddUserAgents.verifyUserAgent(AU);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		//logout
		AssociatesPage_To_Logout();
		
		
		Login_VigoKonnect_Username(AU.userName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
		
	}

	//@Test//(retryAnalyzer = Customlisteners.class)
	// 13. Iteratively missing single filed while editing and saving.
	public void VKTTS10TC013() throws Exception {
		System.out.println("===============VKTTS10TC013 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();

		AddUserAgents AU = new AddUserAgents(true, true);
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		AU.firstName ="";
		AU.lastName += "edit";
		AU.email = "apitestedit@vigo.com";
		AU.role = "ASSOCIATE";
		AU.password = "pass1234";
		AU.confirmPassword = "pass1234";
		AU.isAdmin = false;
		AddUserAgents.editUserAgent(AU);
		implicitWait(driver, 1000);
		Assert_TextValue("Please enter first name",GetText(driver,VKT_AddAssociates.VKT_firstNameError));
		TakeScreenshot(driver,"VKT_FirstNameError");
		implicitWait(driver, 5000);
		EnterText(driver,VKT_AddAssociates.VKT_firstName,"apiEditTest");
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_PasswordEdit,"");
		Click_Element(driver,VKT_AddAssociates.VKT_Save);
		Assert_TextValue("Please enter password",GetText(driver,VKT_AddAssociates.VKT_ErrorMsg));
		TakeScreenshot(driver,"VKT_PasswordError");
		implicitWait(driver, 5000);
		EnterText(driver,VKT_AddAssociates.VKT_PasswordEdit,"changeme");
		EnterText(driver,VKT_AddAssociates.VKT_ConfirmPasswordEdit,"");
		Click_Element(driver,VKT_AddAssociates.VKT_Save);
		Assert_TextValue("Please enter confirm password",GetText(driver,VKT_AddAssociates.VKT_ErrorMsg));
		TakeScreenshot(driver,"VKT_ConfirmPasswordError");
		implicitWait(driver, 5000);
		vertical_scroll_down(driver);
		implicitWait(driver,500);
		Click_Element(driver,VKT_AddAssociates.VKT_backButton);
		// logout
		AssociatesPage_To_Logout();
	}
	 
	//@Test  (retryAnalyzer = Customlisteners.class)
	// 14. mismatching the confirm and password fields while editing and saving.
	public void VKTTS10TC014() throws Exception {
		System.out.println("===============VKTTS10TC014 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();

		AddUserAgents AU = new AddUserAgents(true, true);
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		AU.password = "change";
		AU.confirmPassword = "changeme";
		AddUserAgents.editUserAgent(AU);
		implicitWait(driver, 1000);
		Assert_TextValue("Password & confirm password doesn't match",
				GetText(driver, VKT_AddAssociates.VKT_PasswordError));
		TakeScreenshot(driver, "VKT_PasswordMismatchError");
		implicitWait(driver, 5000);
		vertical_scroll_down(driver);
		implicitWait(driver, 500);
		Click_Element(driver, VKT_AddAssociates.VKT_backButton);
		// logout
		AssociatesPage_To_Logout();
	}
	 
	//@Test  (retryAnalyzer = Customlisteners.class)
	// 15. using the password length less than 6 characters while editing and saving
	public void VKTTS10TC015() throws Exception {
		System.out.println("===============VKTTS10TC015 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddAssociatesPage();

		AddUserAgents AU = new AddUserAgents(true, true);
		AU.Formfill();
		AU.AddAssociate_SuccessPage();
		AddUserAgents.verifyUserAgent(AU);
		AU.password = "chan";
		AU.confirmPassword = "chan";
		AddUserAgents.editUserAgent(AU);
		implicitWait(driver, 1000);
		Assert_TextValue("Unable to Create Associate.",
				GetText(driver,  By.xpath("//android.view.View[contains(@text,'Unable')]")));
		TakeScreenshot(driver, "VKT_PasswordLengthError");
		Thread.sleep(5000);
		vertical_scroll_down(driver);
		implicitWait(driver, 500);
		Click_Element(driver, VKT_AddAssociates.VKT_backButton);
		// logout
		AssociatesPage_To_Logout();
	}
}
