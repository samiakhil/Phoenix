package TestScripts;

import org.openqa.selenium.By;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import PageElements.VKT_Account;
import PageElements.VKT_DashboardPage;
import PageElements.VKT_SideMenu;
import Reusable.Customlisteners;

@Listeners(Customlisteners.class)
public class VKT_AccountScripts extends BASE{
	@Test(retryAnalyzer = Customlisteners.class)
	// 1.Clicking on Cancel Button in Change Password page.
	public void VKTTS09TC001() throws Exception {
		System.out.println("=============== VKTTS09TC001 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue("ADMIN, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ADMIN")));
		clickOnHamburger();
		Click_Element(driver,VKT_SideMenu.VKT_Account);
		TakeScreenshot(driver,"VKT_SideMenu");
		Click_Element(driver,VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver,"VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		Click_Element(driver,VKT_Account.VKT_AccountCancel);
		Click_Element(driver,VKT_Account.VKT_LOGOUT);		
	}

	@Test(retryAnalyzer = Customlisteners.class)
	// 2.Leaving all fields and clicking on Update Button in Change Password page.
	public void VKTTS09TC002() throws Exception {
		System.out.println("=============== VKTTS09TC002 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue("ADMIN, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ADMIN")));
		VKT_AccountUpdatePassword("","","");
		TakeScreenshot(driver,"VKT_AccountOldPasswordError");
		Assert_TextValue("Please enter old password", GetText(driver, VKT_Account.VKT_OldPasswordError));
		Click_Element(driver,VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}
	
	@Test(retryAnalyzer = Customlisteners.class)
	//3. Missing one field and clicking on Update 
	public void VKTTS09TC003() throws Exception {
		System.out.println("=============== VKTTS09TC003 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue("ADMIN, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ADMIN")));
		clickOnHamburger();
		Click_Element(driver, VKT_SideMenu.VKT_Account);

		Click_Element(driver, VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver,"VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		EnterData(driver,VKT_Account.VKT_AccountNewPassword,"VKPWD");
		EnterData(driver,VKT_Account.VKT_AccountConfirmPassword,"VKPWD");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		Assert_TextValue("Please enter old password",
				GetText(driver,VKT_Account.VKT_OldPasswordError));
		TakeScreenshot(driver,"VKT_AccountOldPasswordError");
		implicitWait(driver,2000);

		//new password
		EnterData(driver,VKT_Account.VKT_AccountOldPassword,"VKPWD");
		EnterText(driver,VKT_Account.VKT_AccountNewPassword,"");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		Assert_TextValue("Please enter new password",
				GetText(driver,VKT_Account.VKT_NewPasswordError));
		TakeScreenshot(driver,"VKT_AccountNewPasswordError");
		implicitWait(driver,2000);

		//confirm password
		EnterData(driver,VKT_Account.VKT_AccountNewPassword,"VKPWD");
		EnterText(driver,VKT_Account.VKT_AccountConfirmPassword,"");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		Assert_TextValue("Please enter confirm password",
				GetText(driver,VKT_Account.VKT_ConfirmPasswordError));
		TakeScreenshot(driver,"VKT_AccountConfirmPasswordError");

		//logout
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		Click_Element(driver,VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	@Test(retryAnalyzer = Customlisteners.class)
	//4.Entering wrong old password and new and confirm password fields with atleast 6 characters
	public void VKTTS09TC004() throws Exception {
		System.out.println("=============== VKTTS09TC004 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue("ADMIN, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ADMIN")));
		VKT_AccountUpdatePassword("chan","changeme","changeme");
		Assert_TextValue("Old password is not valid",
				GetText(driver,VKT_Account.VKT_OldPasswordAlert));
		TakeScreenshot(driver,"VKT_AccountLoginIdError");
		implicitWait(driver,5000);

		//logout
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		Click_Element(driver,VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	@Test(retryAnalyzer = Customlisteners.class)
	// 5.Entering old password, new password field with less than 6 characters and entering confirm password.
	public void VKTTS09TC005() throws Exception {
		System.out.println("=============== VKTTS09TC005 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue("ADMIN, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ADMIN")));
		clickOnHamburger();
		Click_Element(driver, VKT_SideMenu.VKT_Account);
		TakeScreenshot(driver, "VKT_SideMenu");
		Click_Element(driver, VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver, "VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		EnterText(driver,VKT_Account.VKT_AccountOldPassword,"changeme");
		EnterText(driver,VKT_Account.VKT_AccountNewPassword,"chang");
		EnterText(driver,VKT_Account.VKT_AccountConfirmPassword,"chang");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		TakeScreenshot(driver, "VKT_AccountNewPasswordLengthError");
		Assert_TextValue("New password length should be of minimum 6 characters", GetText(driver, VKT_Account.VKT_NewPasswordLengthError));
		Click_Element(driver, VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	@Test(retryAnalyzer = Customlisteners.class)
	// 6.Entering old password, new password field with atleast 6 characters and mismatching confirm password.
	public void VKTTS09TC006() throws Exception {
		System.out.println("=============== VKTTS09TC006 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue("ADMIN, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ADMIN")));
		clickOnHamburger();
		Click_Element(driver, VKT_SideMenu.VKT_Account);
		TakeScreenshot(driver, "VKT_SideMenu");
		Click_Element(driver, VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver, "VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		EnterText(driver, VKT_Account.VKT_AccountOldPassword, "changeme");
		EnterText(driver, VKT_Account.VKT_AccountNewPassword, "changeme");
		EnterText(driver, VKT_Account.VKT_AccountConfirmPassword, "chang");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		TakeScreenshot(driver, "VKT_AccountPasswordMismatchError");
		Assert_TextValue("Password mismatched",
				GetText(driver, VKT_Account.VKT_AccountPasswordMismatchError));
		Click_Element(driver, VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	@Test(retryAnalyzer = Customlisteners.class)
	//7.Entering correct/valid old password and new and confirm password fields with atleast 6 characters 
	//and matching and clicking on Update button
	public void VSE_admin_ChangePassword() throws Exception {
		System.out.println("=============== VSE_admin_ChangePassword  (VKTTS09TC007)=======================");
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue("ADMIN, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ADMIN")));
		VKT_AccountUpdatePassword("changeme","changeme","changeme");
		implicitWait(driver,2000);
		TakeScreenshot(driver,"VKT_ChangePasswordSucccessPage");
		Assert_TextValue("Your password has been updated successfully",
				GetText(driver,VKT_Account.VKT_PasswordSuccessMsg));
		Click_Element(driver,VKT_Account.VKT_SuccessPageDoneButton);

		//logout
		Logout_VigoKonnect();

		Login_VigoKonnect_Username(vseAdminName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	//@Test(retryAnalyzer = Customlisteners.class)
	// 1.Clicking on Cancel Button in Change Password page.
	public void VKTTS12TC001() throws Exception {
		System.out.println("=============== VKTTS12TC001 =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		Assert_TextValue("ASSOCIATE, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ASSOCIATE")));
		clickOnHamburger();
		Click_Element(driver,VKT_SideMenu.VKT_Account);
		TakeScreenshot(driver,"VKT_SideMenu");
		Click_Element(driver,VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver,"VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		Click_Element(driver,VKT_Account.VKT_AccountCancel);
		Click_Element(driver,VKT_Account.VKT_LOGOUT);		
	}

	//@Test(retryAnalyzer = Customlisteners.class)
	// 2.Leaving all fields and clicking on Update Button in Change Password page.
	public void VKTTS12TC002() throws Exception {
		System.out.println("=============== VKTTS12TC002 =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		Assert_TextValue("ASSOCIATE, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ASSOCIATE")));
		VKT_AccountUpdatePassword("","","");
		TakeScreenshot(driver,"VKT_AccountOldPasswordError");
		Assert_TextValue("Please enter old password", GetText(driver, VKT_Account.VKT_OldPasswordError));
		Click_Element(driver,VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	//@Test(retryAnalyzer = Customlisteners.class)
	//3. Missing one field and clicking on Update 
	public void VKTTS12TC003() throws Exception {
		System.out.println("=============== VKTTS12TC003 =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		Assert_TextValue("ASSOCIATE, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ASSOCIATE")));
		clickOnHamburger();
		Click_Element(driver, VKT_SideMenu.VKT_Account);

		Click_Element(driver, VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver,"VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		EnterData(driver,VKT_Account.VKT_AccountNewPassword,"VKPWD");
		EnterData(driver,VKT_Account.VKT_AccountConfirmPassword,"VKPWD");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		Assert_TextValue("Please enter old password",
				GetText(driver,VKT_Account.VKT_OldPasswordError));
		TakeScreenshot(driver,"VKT_AccountOldPasswordError");
		implicitWait(driver,2000);

		//new password
		EnterData(driver,VKT_Account.VKT_AccountOldPassword,"VKPWD");
		EnterText(driver,VKT_Account.VKT_AccountNewPassword,"");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		Assert_TextValue("Please enter new password",
				GetText(driver,VKT_Account.VKT_NewPasswordError));
		TakeScreenshot(driver,"VKT_AccountNewPasswordError");
		implicitWait(driver,2000);

		//confirm password
		EnterData(driver,VKT_Account.VKT_AccountNewPassword,"VKPWD");
		EnterText(driver,VKT_Account.VKT_AccountConfirmPassword,"");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		Assert_TextValue("Please enter confirm password",
				GetText(driver,VKT_Account.VKT_ConfirmPasswordError));
		TakeScreenshot(driver,"VKT_AccountConfirmPasswordError");

		//logout
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		Click_Element(driver,VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	//@Test(retryAnalyzer = Customlisteners.class)
	//4.Entering wrong old password and new and confirm password fields with atleast 6 characters
	public void VKTTS12TC004() throws Exception {
		System.out.println("=============== VKTTS12TC004 =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		Assert_TextValue("ASSOCIATE, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ASSOCIATE")));
		VKT_AccountUpdatePassword("chan","changeme","changeme");
		Assert_TextValue("Old password is not valid",
				GetText(driver,VKT_Account.VKT_OldPasswordAlert));
		TakeScreenshot(driver,"VKT_AccountLoginIdError");
		implicitWait(driver,5000);

		//logout
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		Click_Element(driver,VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	//@Test(retryAnalyzer = Customlisteners.class)
	// 5.Entering old password, new password field with less than 6 characters and entering confirm password.
	public void VKTTS12TC005() throws Exception {
		System.out.println("=============== VKTTS12TC005 =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		Assert_TextValue("ASSOCIATE, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ASSOCIATE")));
		clickOnHamburger();
		Click_Element(driver, VKT_SideMenu.VKT_Account);
		TakeScreenshot(driver, "VKT_SideMenu");
		Click_Element(driver, VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver, "VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		EnterText(driver,VKT_Account.VKT_AccountOldPassword,"changeme");
		EnterText(driver,VKT_Account.VKT_AccountNewPassword,"chang");
		EnterText(driver,VKT_Account.VKT_AccountConfirmPassword,"chang");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		TakeScreenshot(driver, "VKT_AccountNewPasswordLengthError");
		Assert_TextValue("New password length should be of minimum 6 characters", GetText(driver, VKT_Account.VKT_NewPasswordLengthError));
		Click_Element(driver, VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	//@Test(retryAnalyzer = Customlisteners.class)
	// 6.Entering old password, new password field with atleast 6 characters and mismatching confirm password.
	public void VKTTS12TC006() throws Exception {
		System.out.println("=============== VKTTS12TC006 =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		Assert_TextValue("ASSOCIATE, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ASSOCIATE")));
		clickOnHamburger();
		Click_Element(driver, VKT_SideMenu.VKT_Account);
		TakeScreenshot(driver, "VKT_SideMenu");
		Click_Element(driver, VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver, "VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		EnterText(driver, VKT_Account.VKT_AccountOldPassword, "changeme");
		EnterText(driver, VKT_Account.VKT_AccountNewPassword, "changeme");
		EnterText(driver, VKT_Account.VKT_AccountConfirmPassword, "chang");
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
		TakeScreenshot(driver, "VKT_AccountPasswordMismatchError");
		Assert_TextValue("Password mismatched",
				GetText(driver, VKT_Account.VKT_AccountPasswordMismatchError));
		Click_Element(driver, VKT_Account.VKT_AccountCancel);
		Click_Element(driver, VKT_Account.VKT_LOGOUT);
	}

	//@Test(retryAnalyzer = Customlisteners.class)
	//7.Entering correct/valid old password and new and confirm password fields with atleast 6 characters 
	//and matching and clicking on Update button
	public void VSE_associate_ChangePassword() throws Exception {
		System.out.println("=============== VSE_associate_ChangePassword  (VKTTS12TC007)=======================");
		Login_VigoKonnect_Username(vseAssociateName);
		Assert_TextValue("ASSOCIATE, " + vseName, GetText(driver, VKT_DashboardPage.getXpathForRole("ASSOCIATE")));
		VKT_AccountUpdatePassword("changeme","changeme","changeme");
		implicitWait(driver,2000);
		TakeScreenshot(driver,"VKT_ChangePasswordSucccessPage");
		Assert_TextValue("Your password has been updated successfully",
				GetText(driver,VKT_Account.VKT_PasswordSuccessMsg));
		Click_Element(driver,VKT_Account.VKT_SuccessPageDoneButton);

		//logout
		Logout_VigoKonnect();

		Login_VigoKonnect_Username(vseAssociateName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}
}