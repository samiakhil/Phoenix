package TestScripts;

import org.apache.http.HttpStatus;
import org.json.JSONObject;
import org.testng.annotations.Ignore;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import PageElements.VKT_AddHospital;
import PageElements.VKT_DashboardPage;
import PageElements.VKT_LogoutPage;
import PageElements.VKT_SideMenu;
import Reusable.Customlisteners;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import CommonPages.Hospital;

import static PageElements.VKT_AddHospital.*;
import static io.restassured.RestAssured.given;

//import Reusable.*;

@Listeners(Customlisteners.class)
public class AddHospitalScript extends BASE{
	
	//-----------------------------Add Hospital---------------------------------------------//

	@Test//(retryAnalyzer = Customlisteners.class)
	//1.leaving only a single mandatory field empty and clicking submit.
	public void VKTTS06TC001() throws Exception{
		System.out.println("===============VKTTS06TC001 started =======================");
		String temp="";
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		temp=data.firstName;
		data.firstName="";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoFNameAlert");
		Assert_TextValue("Please enter contact first name",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		data.firstName=temp;
		implicitWait(driver, 4000);
		EnterText(driver,VKT_FirstName,data.firstName);
		EnterText(driver,VKT_Email,"");
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoEmailAlert");
		Assert_TextValue("Please enter email",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 4000);
		EnterText(driver,VKT_Email,data.email);
		Click_Element(driver,VKT_Role);
		implicitWait(driver,1000);
		Click_Element(driver,VKT_Accounts);
		Click_Element(driver,VKT_Page_View);
		implicitWait(driver,1000);
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoRoleAlert");
		Assert_TextValue("Please select Role",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 4000);
		Click_Element(driver,VKT_Role);
		implicitWait(driver,1000);
		Click_Element(driver,VKT_Accounts);
		Click_Element(driver,VKT_Page_View);
		implicitWait(driver,1000);
		EnterText(driver,VKT_MobileNumber,"");
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoMobileAlert");
		Assert_TextValue("Enter valid mobile number",GetText(driver,VKT_AddHospital.VKT_PhoneNumberError));
		implicitWait(driver, 4000);
		EnterText(driver,VKT_MobileNumber,data.mobile);
		EnterText(driver,VKT_UserName,"");
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoUNameAlert");
		Assert_TextValue("Please enter Username",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 4000);
		EnterText(driver,VKT_UserName,data.userName);
		implicitWait(driver,1000);
		VKT_PrevPage();
		Thread.sleep(1500);
		EnterText(driver,VKT_HospitalName,"");
		VKT_NextPage();
		Thread.sleep(1500);
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoHNameAlert");
		Assert_TextValue("Please enter Name",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 4000);
		VKT_PrevPage();
		Thread.sleep(1500);
		EnterText(driver,VKT_HospitalName,data.hospitalName);
		EnterText(driver,VKT_AddressLane1,"");
		VKT_NextPage();
		Thread.sleep(1500);
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoAddr1Alert");
		Assert_TextValue("Please enter Address line1",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 4000);
		VKT_PrevPage();
		Thread.sleep(1500);
		EnterText(driver,VKT_AddressLane1,data.address1);
		EnterText(driver,VKT_Pincode,"");
		VKT_NextPage();
		Thread.sleep(1500);
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoPincodeAlert");
		Assert_TextValue("Please enter pincode",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 4000);
		VKT_PrevPage();
		Thread.sleep(1500);
		EnterText(driver,VKT_Pincode,data.pincode);
		Click_Element(driver,VKT_ServicesSubscibe);
		implicitWait(driver,1000);
		Click_Element(driver,VKT_VigoLife);
		Click_Element(driver,VKT_Page_View);
		VKT_NextPage();
		Thread.sleep(1500);
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalNoPincodeAlert");
		Assert_TextValue("Please select Service",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 4000);
		//logout
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//2.filling all fields and hospital name with less than 6 characters and clicking submit. 
	public void VKTTS06TC002() throws Exception{
		System.out.println("===============VKTTS06TC002 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.hospitalName="test";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		TakeScreenshot(driver,"VKT_AddHospitalHospitalNameLengthErrorAlert");
		Assert_TextValue("Name should be atleast 6 characters",GetText(driver,VKT_AddHospital.VKT_NameError));
		implicitWait(driver,5000);
		Click_Element(driver,VKT_DashboardPage.VKT_VSE_Dashboard);
		//implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//3.filling all mandatory fields with valid inputs and clicking submit.
	public void AddHospital_Mandatory_Fields() throws Exception{
		System.out.println("===============VKTTS06TC003 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		VKT_HospitalVerification(data.hospitalName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//4.Filling all fields with valid inputs and clicking submit.
	public void AddHospital_with_all_fields() throws Exception{
		System.out.println("===============VKTTS06TC004 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.website="http://vigocare.com";
		data.reportPassword="changeme";
		data.address2="ad2";
		data.lastName="test";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		VKT_HospitalVerification(data.hospitalName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//5.filling optional fields and clicking submit.
	public void VKTTS06TC005() throws Exception{
		System.out.println("===============VKTTS06TC005 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.EmptyInput();
		data.website="http://vigocare.com";
		data.reportPassword="changeme";
		data.address2="ad2";
		data.lastName="test";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		Assert_TextValue("Please enter Name",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 5000);
		Click_Element(driver,VKT_DashboardPage.VKT_VSE_Dashboard);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)	
	//6.Clicking submit without filling any field.
	public void VKTTS06TC006() throws Exception{
		System.out.println("===============VKTTS06TC006 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		Thread.sleep(1000);
		VKT_NextPage();
		Thread.sleep(2000);
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		Assert_TextValue("Please enter Name",GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver, 5000);
		Click_Element(driver,VKT_DashboardPage.VKT_VSE_Dashboard);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	//@Test//(retryAnalyzer = Customlisteners.class)
	//7.filling all mandatory fields with valid inputs and using existing username and clicking submit
	public void VKTTS06TC007() throws Exception{
		System.out.println("===============VKTTS06TC007 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		Thread.sleep(2000);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		data.hospitalFormFill();
		Assert_TextValue("This Username is already taken. Please try with different Username",
				GetText(driver,VKT_AddHospital.VKT_UserNameExist));
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		TakeScreenshot(driver,"VKT_AddHospitalUsernameExistErrorAlert");
		Assert_TextValue("Please enter Valid Username",
				GetText(driver,VKT_AddHospital.VKT_HospitalErrorMsg));
		implicitWait(driver,5000);
		Click_Element(driver,VKT_DashboardPage.VKT_VSE_Dashboard);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	//@Test//(retryAnalyzer = Customlisteners.class)
	//8.filling all mandatory fields with valid input and entering username less than 6 characters and clicking submit.
	public void VKTTS06TC008() throws Exception{
		System.out.println("===============VKTTS06TC008 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.userName="test";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		TakeScreenshot(driver,"VKT_AddHospitalInvalidMobErrorAlert");
		Assert_TextValue("Username should contain minimum 6 characters.",GetText(driver,VKT_AddHospital.VKT_UserNameError));
		implicitWait(driver,5000);
		Click_Element(driver,VKT_DashboardPage.VKT_VSE_Dashboard);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	//@Test//(retryAnalyzer = Customlisteners.class)
	//9.filling all mandatory fields with valid inputs and filling mobile number less than 10 digits and clicking submit.
	public void VKTTS06TC009() throws Exception{
		System.out.println("===============VKTTS06TC009 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.mobile="999999999";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		TakeScreenshot(driver,"VKT_AddHospitalInvalidMobErrorAlert");
		Assert_TextValue("Enter valid mobile number",GetText(driver,VKT_AddHospital.VKT_PhoneNumberError));
		implicitWait(driver,5000);
		Click_Element(driver,VKT_DashboardPage.VKT_VSE_Dashboard);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	//@Test//(retryAnalyzer = Customlisteners.class)
	//10.filling all mandatory fields with valid inputs, using already existing hospital name and clicking submit.
	public void VKTTS06TC010() throws Exception{
		//Dmaven.test.skip=true;
		System.out.println("===============VKTTS06TC010 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		Thread.sleep(3000);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		data.userName="appiumVSPAdmin"+Random_AlphaNumeric(0,6);
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		TakeScreenshot(driver,"VKT_AddHospitalHospitalExistErrorAlert");
		Assert_TextValue("Unable to add Hospital",GetText(driver,VKT_AddHospital.VKT_HospitalExistError));//modify
		implicitWait(driver,5000);
		Click_Element(driver,VKT_DashboardPage.VKT_VSE_Dashboard);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	//@Test//(retryAnalyzer = Customlisteners.class)
	//11.filling all mandatory fields with valid inputs and filling mobile number 
	//with one leading 0 and 11 digits and clicking submit.
	public void VKTTS06TC011() throws Exception{
		System.out.println("===============VKTTS06TC011 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.mobile="0"+data.mobile;
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		VKT_HospitalVerification(data.hospitalName);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}

	//@Ignore
	//12.filling all mandatory fields with valid inputs and filling mobile number with 
	//more than 1 leading 0 and 11 digits and clicking submit.
	public void VKTTS06TC012() throws Exception{
		System.out.println("===============VKTTS06TC012 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.mobile="00"+"999999999";
		data.hospitalFormFill();
		implicitWait(driver,1000);
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		TakeScreenshot(driver,"VKT_AddHospitalInvalidMobErrorAlert");
		Assert_TextValue("Enter valid mobile number",GetText(driver,VKT_AddHospital.VKT_PhoneNumberError));
		Click_Element(driver,VKT_DashboardPage.VKT_VSE_Dashboard);
		implicitWait(driver,1000);
		Logout_VigoKonnect();
	}
	
//	@Test//(retryAnalyzer = Customlisteners.class)
	//13.Verifying Add Hospital Tab option for VSE Associate not to be existing.
	public void VKTTS06TC013() throws Exception{
		System.out.println("===============VKTTS06TC013 started =======================");
		Login_VigoKonnect_Username(vseAssociateName);
		int ele= driver.findElements(VKT_AddHospitalTab).size();
		if(ele!=0)
			throw new Exception("add hospital tab is present for vse associate");
		System.out.println("add hospital tab is not present for vse associate ");
		Logout_VigoKonnect();
	}
	
//	@Test//(retryAnalyzer = Customlisteners.class)
	//14. Creating a hospital and searching with a invalid hospital name.
	public void VKTTS06TC014() throws Exception{
		System.out.println("===============VKTTS06TC014 started =======================");
		Login_VigoKonnect_Username(vseAdminName);	
		Click_Element(driver,VKT_DashboardPage.VKT_ASideMenu);
		implicitWait(driver,500);
		Click_Element(driver,VKT_SideMenu.VKT_Hospitals);
		TakeScreenshot(driver,"VKT_HospitalList");
		Click_Element(driver,VKT_SideMenu.VKT_AddHospitalImageButton);
		
		implicitWait(driver, 2000);
		
		
		Hospital data=new Hospital();
		data.website="http://vigocare.com";
		data.reportPassword="changeme";
		data.address2="ad2";
		data.lastName="test";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		Thread.sleep(1000);
		
		String wName = "Wrong"+Random_AlphaNumeric(3,0);
		
		//search in the list
		Click_Element(driver,VKT_DashboardPage.VKT_ASideMenu);
		Click_Element(driver,VKT_SideMenu.VKT_Hospitals);
		TakeScreenshot(driver,"VKT_HospitalList");
		
		EnterText(driver,VKT_SideMenu.VKT_TextFieldForHospitalName,wName);
		Click_Element(driver,VKT_SideMenu.VKT_SearchButton);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"HospitalListAfterSeach");
		
		Thread.sleep(1000);
		
		Click_Element(driver,VKT_SideMenu.VKT_MenuButton);
		Thread.sleep(1000);
		Click_Element(driver,VKT_SideMenu.VKT_Logout);
		Thread.sleep(1000);
		Assert_TextValue("Are you sure you want to Logout?",
				GetText(driver,VKT_LogoutPage.VKT_LogoutPopup));
		TakeScreenshot(driver, "VigoKonnectLogoutConfirmationPage");
		Click_Element(driver,VKT_LogoutPage.VKT_LogoutConfirm);
		implicitWait(driver,500);
		TakeScreenshot(driver, "VigoKonnectAfterLogout");

	}
	
//@Test//(retryAnalyzer = Customlisteners.class)
	//15. From Sidemenu option creating hospital by filling all fields with valid inputs and clicking submit.
	//Searching in hospital list from side menu option and assertions with given data.
	public void VKTTS06TC015() throws Exception{
		System.out.println("===============VKTTS06TC015 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		
		Click_Element(driver,VKT_DashboardPage.VKT_ASideMenu);
		implicitWait(driver,500);
		Click_Element(driver,VKT_SideMenu.VKT_Hospitals);
		TakeScreenshot(driver,"VKT_HospitalList");
		Click_Element(driver,VKT_SideMenu.VKT_AddHospitalImageButton);
		
		implicitWait(driver, 2000);
		Hospital data=new Hospital();
		data.website="http://vigocare.com";
		data.reportPassword="changeme";
		data.address2="ad2";
		data.lastName="test";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		Thread.sleep(1000);
		
		
		//search in the list
		Click_Element(driver,VKT_DashboardPage.VKT_ASideMenu);
		Click_Element(driver,VKT_SideMenu.VKT_Hospitals);
		TakeScreenshot(driver,"VKT_HospitalList");
		
		EnterText(driver,VKT_SideMenu.VKT_TextFieldForHospitalName,data.hospitalName);
		Click_Element(driver,VKT_SideMenu.VKT_SearchButton);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"BriefHospitalDataAfterSeach");

		//Assertions for not verified
		data.assertHospitalData(data,"NOT_VERIFIED");
		
		//
		Thread.sleep(1000);
		Logout_VigoKonnect();		
	}
	
	//@Test//(retryAnalyzer = Customlisteners.class)
	//16. From Sidemenu option creating hospital by filling all fields with valid inputs and 
	//clicking submit and making hospital as verified in CMS web.
	//Searching in hospital list from side menu option and assertions with given data.
	public void VKTTS06TC016() throws Exception{
		System.out.println("===============VKTTS06TC016 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		
		Click_Element(driver,VKT_DashboardPage.VKT_ASideMenu);
		implicitWait(driver,500);
		Click_Element(driver,VKT_SideMenu.VKT_Hospitals);
		TakeScreenshot(driver,"VKT_HospitalList");
		Click_Element(driver,VKT_SideMenu.VKT_AddHospitalImageButton);
		
		implicitWait(driver,2000);
		Hospital data=new Hospital();
		data.website="http://vigocare.com";
		data.reportPassword="changeme";
		data.address2="ad2";
		data.lastName="test";
		data.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		Thread.sleep(1000);
		
		//id of the hospital
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.get("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner?query="+data.hospitalName)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject obj = new JSONObject(getResponse.getBody().asString());
        String Hid = obj.getJSONArray("businessPartners").getJSONObject(0).getString("id");
        System.out.println(Hid);
		
		// making hospital as verified
		String ws = data.website.isEmpty()?"https://test.com":data.website;
		String reqBody= ""
				+ "{"
				+ "\"website\":\""+ws+"\","
				+ "\"status\":\"VERIFIED\""
				+ "}";
		getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.body(reqBody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/business/partner/"+Hid)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		obj=new JSONObject(getResponse.getBody().asString());
		System.out.println("Status of the hospital changed");
		
		//search in the list
		Click_Element(driver,VKT_DashboardPage.VKT_ASideMenu);
		Click_Element(driver,VKT_SideMenu.VKT_Hospitals);
		TakeScreenshot(driver,"VKT_HospitalList");
		
		EnterText(driver,VKT_SideMenu.VKT_TextFieldForHospitalName,data.hospitalName);
		Click_Element(driver,VKT_SideMenu.VKT_SearchButton);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"BriefHospitalDataAfterSeach");

		//Assertions for verified
		data.assertHospitalData(data,"VERIFIED");
		
		//
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}
}
