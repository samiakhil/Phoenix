package TestScripts;

import org.openqa.selenium.By;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import CommonPages.AddDoctors;
import static CommonPages.AddDoctors.assertDoctorData;
import PageElements.VKT_AddDoctor;
import PageElements.VKT_SideMenu;
import Reusable.Customlisteners;

@Listeners(Customlisteners.class)
public class AddDoctorsScript extends BASE{
	
	@Test(retryAnalyzer = Customlisteners.class)
	//1. missing all fields and click submit.
	public void VKTTS11TC001() throws Exception{
		System.out.println("===============VKTTS11TC001 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();
		
		AddDoctors AD = new AddDoctors(true);
		AD.emptyAllFields();

		implicitWait(driver,2000);
		vertical_scroll_up(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		//Assert
		TakeScreenshot(driver,"VKT_AddDoctors_EmptyFieldsError");
		implicitWait(driver,5000);
		
		//logout
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}
	
	@Test(retryAnalyzer = Customlisteners.class)
	//2. filling all mandatory fields with valid inputs and click submit .
	public void VKTTS11TC002() throws Exception{
		System.out.println("===============VKTTS11TC002 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.formFill();
		AD.addDoctorSubmit();

		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//3.filling all mandatory fields with valid inputs and using existing mobile number of another docter and click add new.
	public void VKTTS11TC003() throws Exception{
		System.out.println("===============VKTTS11TC003 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.formFill();
		AD.addDoctorSubmit();
		
		TakeScreenshot(driver,"VKT_DoctorsList");
		Click_Element(driver,VKT_SideMenu.VKT_AddDoctorButtonImage);
		implicitWait(driver,7000);
		Assert_TextValue("ADD DOCTOR",
				GetText(driver,VKT_AddDoctor.VKT_DocPageTitle));
		AD.formFill();
		implicitWait(driver,1000);
		Assert_TextValue("Mobile number is associated with "+AD.firstName+", "+AD.lastName+" Do you wish to continue or Add a new Doctor?",
				GetText(driver,VKT_AddDoctor.VKT_DocMobileError));
		TakeScreenshot(driver,"VKT_AddDoctorMobileError");
		Click_Element(driver,VKT_AddDoctor.VKT_DocAddNew);
		TakeScreenshot(driver,"VKT_AddDoctorFormAfterAddNew");
		Assert_TextValue("",
				GetText(driver,VKT_AddDoctor.VKT_DocMobileNumber));
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}
	
	@Test(retryAnalyzer = Customlisteners.class)
	// 4.filling all mandatory fields with valid inputs and using existing mobile 
	//number of another docter and click continue.
	public void VKTTS11TC004() throws Exception {
		System.out.println("===============VKTTS11TC004 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.formFill();
		AD.addDoctorSubmit();

		TakeScreenshot(driver,"VKT_DoctorsList");
		Click_Element(driver,VKT_SideMenu.VKT_AddDoctorButtonImage);
		implicitWait(driver,7000);
		Assert_TextValue("ADD DOCTOR",
				GetText(driver,VKT_AddDoctor.VKT_DocPageTitle));
		AD.formFill();
		implicitWait(driver, 1000);
		Assert_TextValue(
				"Mobile number is associated with " + AD.firstName + ", " + AD.lastName
						+ " Do you wish to continue or Add a new Doctor?",
				GetText(driver, VKT_AddDoctor.VKT_DocMobileError));
		TakeScreenshot(driver, "VKT_AddDoctorMobileError");
		Click_Element(driver, VKT_AddDoctor.VKT_DocContinue);
		TakeScreenshot(driver, "VKT_AddDoctorContinueAlert");
		implicitWait(driver,1000);
		Assert_TextValue("Can't add doctor with same mobile number under same hospital",
				GetText(driver, VKT_AddDoctor.VKT_DocContinueAlert));
		implicitWait(driver,5000);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}
	
	@Test(retryAnalyzer = Customlisteners.class)
	//5. Iteratively missing one mandatory field and click submit. 
	public void VKTTS11TC005() throws Exception{
		System.out.println("===============VKTTS11TC005 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.speciality="";
		AD.formFill();
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please select speciality",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorSpecialityAlert");
		implicitWait(driver,5000);
		Click_Element(driver,VKT_AddDoctor.VKT_DocSpeciality);
		Click_Element(driver,VKT_AddDoctor.VKT_DocSpecialityType("Cardiology"));
		
		EnterText(driver,VKT_AddDoctor.VKT_DocFirstName,"");
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter first name",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorFirstNameAlert");
		implicitWait(driver,5000);
		EnterText(driver,VKT_AddDoctor.VKT_DocFirstName,AD.firstName);
		
		EnterText(driver,VKT_AddDoctor.VKT_DocLastName,"");
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter last name",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorLastNameAlert");
		implicitWait(driver,5000);
		EnterText(driver,VKT_AddDoctor.VKT_DocLastName,AD.lastName);
		
		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,"");
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter display name",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorDisplayNameAlert");
		implicitWait(driver,5000);
		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,AD.displayName);
		
		EnterText(driver,VKT_AddDoctor.VKT_DocMobileNumber,"");
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter mobile number",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorMobileAlert");
		implicitWait(driver,5000);
		
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}
	
	@Test(retryAnalyzer = Customlisteners.class)
	//6. Filling all the fields with valid inputs and click submit.
	public void create_VSE_Doctor() throws Exception{
		System.out.println("===============create_VSE_Doctor started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.createDoctor();

		assertDoctorData(AD);
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}
	
	 @Test(retryAnalyzer = Customlisteners.class)
	// 7. filling all mandatory fields with valid inputs and using mobile number less than 10 digits and click submit.
	public void VKTTS11TC007() throws Exception {
		System.out.println("===============VKTTS11TC007 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.mobileNumber="999999999";
		AD.formFill();
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter a valid mobile number",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorMobileAlert");
		implicitWait(driver,5000);
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}
	
	 @Test(retryAnalyzer = Customlisteners.class)
	// 8. filling all mandatory fields with valid inputs and using mobile number with 10 digits 
	//which has 1 or more leading zeroes  and click submit.
	public void VKTTS11TC008() throws Exception {
		System.out.println("===============VKTTS11TC008 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.mobileNumber = "0999999999";
		AD.formFill();
		Click_Element(driver, VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter a valid mobile number", GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorMobileAlert");
		implicitWait(driver, 5000);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}
	
	@Test(retryAnalyzer = Customlisteners.class)
	// 9. filling all mandatory fields with valid inputs and using mobile number with 10 digits which 
	//has 1 or more leading zeroes  and click submit.
	public void VKTTS11TC009() throws Exception {
		System.out.println("===============VKTTS11TC009 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.mobileNumber = "014"+Random_AlphaNumeric(0,8);
		AD.createDoctor();

		DoctorListPage_To_Logout();
	}
	
	 @Test
	// 10. filling all mandatory fields with valid inputs and using existing MCI license number and click submit.
	public void VKTTS11TC010() throws Exception {
		 System.out.println("===============VKTTS11TC010 started =======================");
			Login_VigoKonnect_Username(vseAdminName);
			DB_To_AddDoctorsPage();

			AddDoctors AD = new AddDoctors(true);
			AD.MCINumber=Random_AlphaNumeric(0,7);
			AD.formFill();
			AD.addDoctorSubmit();
			
			AddDoctors AD1 = new AddDoctors(true);
			AD1.MCINumber = AD.MCINumber;
			TakeScreenshot(driver,"VKT_DoctorsList");
			Click_Element(driver,VKT_SideMenu.VKT_AddDoctorButtonImage);
			implicitWait(driver,7000);
			Assert_TextValue("ADD DOCTOR",
					GetText(driver,VKT_AddDoctor.VKT_DocPageTitle));
			AD1.formFill();
			Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
			GetText(driver,VKT_AddDoctor.VKT_MCIAlert).startsWith("Doctor");
			TakeScreenshot(driver, "VKT_AddDoctorMCIAlert");
			implicitWait(driver, 5000);
			Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
			DoctorListPage_To_Logout();
	}
	
	@Test  (groups= {"sanity"}) 
	//11. Editing a Created Doctor data and verifying the data.
	public void edit_VSE_Doctor() throws Exception{
		System.out.println("===============edit_VSE_Doctor started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.createDoctor();

		assertDoctorData(AD);
		Click_Element(driver,VKT_AddDoctor.VKT_DocEditButton);
		
		//Edit
		AD.displayName=AD.displayName+"E";
		AD.email="edittest@gmail.com";
		//AD.MCINumber="8817759536";
		
		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,AD.displayName);
		EnterText(driver,VKT_AddDoctor.VKT_DocEmail,AD.email);
		//implicitWait(driver,7000);
		EnterText(driver,VKT_AddDoctor.VKT_DocMICNumber,AD.MCINumber);
		
		Click_Element(driver,VKT_AddDoctor.VKT_DocSaveButton);
		implicitWait(driver,1000);
		Assert_TextValue("The Profile has been successfully Updated.",
				GetText(driver,VKT_AddDoctor.VKT_SuccessMsg));
		TakeScreenshot(driver,"VKT_EditDoctorSuccessPage");
		Click_Element(driver,VKT_AddDoctor.VKT_DoneButton);
		//
		assertDoctorData(AD);
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		implicitWait(driver,1000);
		DoctorListPage_To_Logout();
	}
	
	@Test(retryAnalyzer = Customlisteners.class)
	//12. In editing page, missing all mandatory fields and save.
	public void VKTTS11TC012() throws Exception{
		System.out.println("===============VKTTS11TC012 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.createDoctor();

		assertDoctorData(AD);		
		Click_Element(driver,VKT_AddDoctor.VKT_DocEditButton);

		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,"");
		EnterText(driver,VKT_AddDoctor.VKT_DocEmail,"");
		EnterText(driver,VKT_AddDoctor.VKT_DocMICNumber,"");
		
		Click_Element(driver,VKT_AddDoctor.VKT_DocSaveButton);
		Assert_TextValue("Please enter display name",GetText(driver,VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_EditDoctorDisplayNameAlert");
		implicitWait(driver,5000);

		//logout
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test(retryAnalyzer = Customlisteners.class)
	//13. In editing page, using existing MCI License of other doctor and save.
	public void VKTTS11TC013() throws Exception{
		System.out.println("===============VKTTS11TC013 started =======================");
		Login_VigoKonnect_Username(vseAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(true);
		AD.createDoctor();

		assertDoctorData(AD);		
		Click_Element(driver,VKT_AddDoctor.VKT_DocEditButton);

		EnterText(driver,VKT_AddDoctor.VKT_DocMICNumber,"123456");

		Click_Element(driver,VKT_AddDoctor.VKT_DocSaveButton);
		GetText(driver,VKT_AddDoctor.VKT_MCIAlert).startsWith("Doctor");
		TakeScreenshot(driver, "VKT_AddDoctorMCIAlert");
		implicitWait(driver,5000);

		//logout
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//1. missing all fields and click submit.
	public void VKTTS13TC001() throws Exception{
		System.out.println("===============VKTTS13TC001 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.emptyAllFields();

		implicitWait(driver,2000);
		vertical_scroll_up(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		//Assert
		TakeScreenshot(driver,"VKT_AddDoctors_EmptyFieldsError");
		implicitWait(driver,5000);

		//logout
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//2. filling all mandatory fields with valid inputs and click submit .
	public void VKTTS13TC002() throws Exception{
		System.out.println("===============VKTTS13TC002 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.formFill();
		AD.addDoctorSubmit();

		DoctorListPage_To_Logout();
	}

	@Test////(retryAnalyzer = Customlisteners.class)
	//3.filling all mandatory fields with valid inputs and using existing mobile number of another docter and click add new.
	public void VKTTS13TC003() throws Exception{
		System.out.println("===============VKTTS13TC003 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.formFill();
		AD.addDoctorSubmit();

		TakeScreenshot(driver,"VKT_DoctorsList");
		Click_Element(driver,VKT_SideMenu.VKT_AddDoctorButtonImage);
		implicitWait(driver,7000);
		Assert_TextValue("ADD DOCTOR",
				GetText(driver,VKT_AddDoctor.VKT_DocPageTitle));
		AD.formFill();
		implicitWait(driver,1000);
		Assert_TextValue("Mobile number is associated with "+AD.firstName+", "+AD.lastName+" Do you wish to continue or Add a new Doctor?",
				GetText(driver,VKT_AddDoctor.VKT_DocMobileError));
		TakeScreenshot(driver,"VKT_AddDoctorMobileError");
		Click_Element(driver,VKT_AddDoctor.VKT_DocAddNew);
		TakeScreenshot(driver,"VKT_AddDoctorFormAfterAddNew");
		Assert_TextValue("",
				GetText(driver,VKT_AddDoctor.VKT_DocMobileNumber));
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 4.filling all mandatory fields with valid inputs and using existing mobile 
	//number of another docter and click continue.
	public void VKTTS13TC004() throws Exception {
		System.out.println("===============VKTTS13TC004 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.formFill();
		AD.addDoctorSubmit();

		TakeScreenshot(driver,"VKT_DoctorsList");
		Click_Element(driver,VKT_SideMenu.VKT_AddDoctorButtonImage);
		implicitWait(driver,7000);
		Assert_TextValue("ADD DOCTOR",
				GetText(driver,VKT_AddDoctor.VKT_DocPageTitle));
		AD.formFill();
		implicitWait(driver, 1000);
		Assert_TextValue(
				"Mobile number is associated with " + AD.firstName + ", " + AD.lastName
				+ " Do you wish to continue or Add a new Doctor?",
				GetText(driver, VKT_AddDoctor.VKT_DocMobileError));
		TakeScreenshot(driver, "VKT_AddDoctorMobileError");
		Click_Element(driver, VKT_AddDoctor.VKT_DocContinue);
		TakeScreenshot(driver, "VKT_AddDoctorContinueAlert");
		implicitWait(driver,1000);
		Assert_TextValue("Can't add doctor with same mobile number under same hospital",
				GetText(driver, VKT_AddDoctor.VKT_DocContinueAlert));
		implicitWait(driver,5000);
		
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//5. Iteratively missing one mandatory field and click submit. 		//re-work
	public void VKTTS13TC005() throws Exception{
		System.out.println("===============VKTTS13TC005 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		String firstName=AD.firstName;
		String lastName=AD.lastName;
		String displayName=AD.displayName;
		String mobileNumber=AD.mobileNumber;
		String speciality=AD.speciality;
		
		AD.emptyAllFields();
		AD.formFill();
		
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter first name",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorFirstNameAlert");
		implicitWait(driver,5000);
		EnterText(driver,VKT_AddDoctor.VKT_DocFirstName,firstName);

		EnterText(driver,VKT_AddDoctor.VKT_DocLastName,"");
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter last name",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorLastNameAlert");
		implicitWait(driver,5000);
		EnterText(driver,VKT_AddDoctor.VKT_DocLastName,lastName);

		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,"");
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter display name",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorDisplayNameAlert");
		implicitWait(driver,5000);
		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,displayName);

		EnterText(driver,VKT_AddDoctor.VKT_DocMobileNumber,"");
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter mobile number",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorMobileAlert");
		implicitWait(driver,5000);
		EnterText(driver,VKT_AddDoctor.VKT_DocMobileNumber,mobileNumber);

		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please select speciality",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorSpecialityAlert");
		implicitWait(driver,5000);
		Click_Element(driver,VKT_AddDoctor.VKT_DocSpeciality);
		Click_Element(driver,VKT_AddDoctor.VKT_DocSpecialityType(speciality));

		//
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please select type",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorTypeAlert");
		implicitWait(driver,5000);
		
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//6. Filling all the fields with valid inputs and click submit.
	public void create_VSP_Doctor() throws Exception{
		System.out.println("===============create_VSP_Doctor started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.type = "INTERNAL";
		AD.createDoctor();

		assertDoctorData(AD);
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 7. filling all mandatory fields with valid inputs and using mobile number less than 10 digits and click submit.
	public void VKTTS13TC007() throws Exception {
		System.out.println("===============VKTTS13TC007 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.mobileNumber="999999999";
		AD.formFill();
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter a valid mobile number",
				GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorMobileAlert");
		implicitWait(driver,5000);
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 8. filling all mandatory fields with valid inputs and using mobile number with 10 digits 
	//which has 1 or more leading zeroes  and click submit.
	public void VKTTS13TC008() throws Exception {
		System.out.println("===============VKTTS13TC008 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.mobileNumber = "0999999999";
		AD.formFill();
		Click_Element(driver, VKT_AddDoctor.VKT_DocSubmit);
		Assert_TextValue("Please enter a valid mobile number", GetText(driver, VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_AddDoctorMobileAlert");
		implicitWait(driver, 5000);
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 9. filling all mandatory fields with valid inputs and using mobile number with 10 digits which 
	//has 1 or more leading zeroes  and click submit.
	public void VKTTS13TC009() throws Exception {
		System.out.println("===============VKTTS13TC009 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.mobileNumber = "014"+Random_AlphaNumeric(0,8);
		AD.createDoctor();

		DoctorListPage_To_Logout();
	}

	@Test
	// 10. filling all mandatory fields with valid inputs and using existing MCI license number and click submit.
	public void VKTTS13TC010() throws Exception {
		System.out.println("===============VKTTS13TC010 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.MCINumber=Random_AlphaNumeric(0,7);
		AD.formFill();
		AD.addDoctorSubmit();

		AddDoctors AD1 = new AddDoctors(false);
		AD1.MCINumber = AD.MCINumber;
		TakeScreenshot(driver,"VKT_DoctorsList");
		Click_Element(driver,VKT_SideMenu.VKT_AddDoctorButtonImage);
		implicitWait(driver,7000);
		Assert_TextValue("ADD DOCTOR",
				GetText(driver,VKT_AddDoctor.VKT_DocPageTitle));
		AD1.formFill();
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		GetText(driver,VKT_AddDoctor.VKT_MCIAlert).startsWith("Doctor");
		TakeScreenshot(driver, "VKT_AddDoctorMCIAlert");
		implicitWait(driver, 5000);
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//11. Editing a Created Doctor data and verifying the data.
	public void edit_VSP_Doctor() throws Exception{
		System.out.println("===============edit_VSP_Doctor started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.createDoctor();

		assertDoctorData(AD);
		Click_Element(driver,VKT_AddDoctor.VKT_DocEditButton);

		//Edit
		AD.displayName=AD.displayName+"E";
		AD.email="edittest@gmail.com";
		//AD.MCINumber="8817759536";

		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,AD.displayName);
		EnterText(driver,VKT_AddDoctor.VKT_DocEmail,AD.email);
		//implicitWait(driver,7000);
		EnterText(driver,VKT_AddDoctor.VKT_DocMICNumber,AD.MCINumber);

		if(!AD.isVSE) {// for VSP Admin and Associate
			String type = GetText(driver,VKT_AddDoctor.VKT_DocType).equals("EXTERNAL")?"INTERNAL":"EXTERNAL";
			Click_Element(driver,VKT_AddDoctor.VKT_DocType);
			Click_Element(driver,VKT_AddDoctor.VKT_DocType(type));
			AD.type = type;
			implicitWait(driver,500);
			vertical_scroll_up(driver);
		}

		Click_Element(driver,VKT_AddDoctor.VKT_DocSaveButton);
		implicitWait(driver,1000);
		Assert_TextValue("The Profile has been successfully Updated.",
				GetText(driver,VKT_AddDoctor.VKT_SuccessMsg));
		TakeScreenshot(driver,"VKT_EditDoctorSuccessPage");
		Click_Element(driver,VKT_AddDoctor.VKT_DoneButton);
		//
		assertDoctorData(AD);
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocBackButton);
		implicitWait(driver,1000);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//12. In editing page, missing all mandatory fields and save.
	public void VKTTS13TC012() throws Exception{
		System.out.println("===============VKTTS13TC012 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.createDoctor();

		assertDoctorData(AD);		
		Click_Element(driver,VKT_AddDoctor.VKT_DocEditButton);

		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,"");
		EnterText(driver,VKT_AddDoctor.VKT_DocEmail,"");
		EnterText(driver,VKT_AddDoctor.VKT_DocMICNumber,"");
		
		vertical_scroll_up(driver);
		Click_Element(driver,VKT_AddDoctor.VKT_DocSaveButton);
		Assert_TextValue("Please enter display name",GetText(driver,VKT_AddDoctor.VKT_DocAlert));
		TakeScreenshot(driver, "VKT_EditDoctorDisplayNameAlert");
		implicitWait(driver,5000);

		//logout
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//13. In editing page, using existing MCI License of other doctor and save.
	public void VKTTS13TC013() throws Exception{
		System.out.println("===============VKTTS13TC013 started =======================");
		Login_VigoKonnect_Username(vspAdminName);
		DB_To_AddDoctorsPage();

		AddDoctors AD = new AddDoctors(false);
		AD.createDoctor();

		assertDoctorData(AD);		
		Click_Element(driver,VKT_AddDoctor.VKT_DocEditButton);

		EnterText(driver,VKT_AddDoctor.VKT_DocMICNumber,"123456");

		Click_Element(driver,VKT_AddDoctor.VKT_DocSaveButton);
		GetText(driver,VKT_AddDoctor.VKT_MCIAlert).startsWith("Doctor");
		TakeScreenshot(driver, "VKT_AddDoctorMCIAlert");
		implicitWait(driver,5000);

		//logout
		vertical_scroll_down(driver);
		Click_Element(driver, VKT_AddDoctor.VKT_DocBackButton);
		DoctorListPage_To_Logout();
	}

}