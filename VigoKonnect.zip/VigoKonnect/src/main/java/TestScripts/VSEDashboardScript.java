package TestScripts;

import static io.restassured.RestAssured.given;

import org.apache.commons.lang3.RandomStringUtils;
import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;
import org.testng.annotations.Ignore;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import PageElements.VKT_AddHospital;
import PageElements.VKT_DashboardPage;
import PageElements.VKT_HospitalCasesPage;
import PageElements.VKT_HospitalStatisticsPage;
import PageElements.VKT_PatientsOpen;
import PageElements.VKT_RegisterPatient_Page;
import Reusable.Customlisteners;
import io.appium.java_client.android.AndroidDriver;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import CommonPages.CaseCreation;
import CommonPages.Hospital;
@Listeners(Customlisteners.class)
public class VSEDashboardScript extends BASE{
	@Test//(retryAnalyzer = Customlisteners.class)
	//Asserting username,role, vse name.
	public void VKTTS08TC001() throws Exception{
		System.out.println("=============== VKTTS08TC001 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue("ADMIN, "+vseName,GetText(driver,By.xpath("//*[contains(@text,'ADMIN')]")));
		System.out.println("Name of the user is :\t"+GetText(driver,VKT_DashboardPage.VKT_NameOfTheUser));
		Logout_VigoKonnect();
	}
	
	@Test//(retryAnalyzer = Customlisteners.class)
	//Open count before and after creating a case
	public void VKTTS08TC002() throws Exception{
		System.out.println("=============== VKTTS08TC002 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		int openCount = Integer.parseInt(GetText(driver,VKT_DashboardPage.VKT_VSE_OpenCount));
		System.out.println("Open Count is\t:"+openCount);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		Assert_TextValue(Integer.toString(openCount+1),GetText(driver,VKT_DashboardPage.VKT_VSE_OpenCount));
		Logout_VigoKonnect();
	}
	
	@Test//(retryAnalyzer = Customlisteners.class)
	//Filling all fields, mobile number registered earlier and has no monitoring,
	//and creating a case
	public void VKTTS08TC003() throws Exception{
		System.out.println("=============== VKTTS08TC003 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		int openCount = Integer.parseInt(GetText(driver,VKT_DashboardPage.VKT_VSE_OpenCount));
		System.out.println("Open Count is\t:"+openCount);
		CaseCreation obj = new CaseCreation();
		obj.doctor=vseDoctorName;
		RegisterPatient(obj);
		caseCreationSuccessPage();
		Assert_TextValue(Integer.toString(openCount+1),GetText(driver,VKT_DashboardPage.VKT_VSE_OpenCount));

		String pname=obj.firstName;
		Click_Element(driver,VKT_DashboardPage.VKT_PatientOpen);
		TakeScreenshot(driver,"PatientsUnderOpen");
		Thread.sleep(1000);
		Assert_TextValue("Open Leads",
				GetText(driver,By.xpath("//*[contains(@text,'Open Leads')]")));

		//filter according to VSE NAME
		Click_Element(driver,VKT_PatientsOpen.VKT_FilterWithVSP);
		Thread.sleep(1000);
		vertical_scroll_up(driver);
		Click_Element(driver,VKT_PatientsOpen.hospital(vseName));
		Thread.sleep(1000);
		vertical_scroll_down(driver);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_PatientReg_View);
		Thread.sleep(1000);

		EnterText(driver,VKT_PatientsOpen.VKT_SearchTextWithName,pname);
		Click_Element(driver,VKT_PatientsOpen.VKT_SearchClick);
		//driver.findElements(By.className("android.widget.Image")).get(5).click();
		Thread.sleep(2000);

		TakeScreenshot(driver,"Searched_PatientName");
		Assert_TextValue(pname+" "+obj.lastName,GetText(driver,VKT_PatientsOpen.patient(pname)));

		Click_Element(driver,VKT_PatientsOpen.patient(pname));
		Thread.sleep(1000);
		isDisplayed(driver,By.xpath("//*[contains(@text,'"+pname+"')]"));
		TakeScreenshot(driver,"PatientDetailsWithCaseId");
		String caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		System.out.println(caseId);
		Thread.sleep(1000);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Assert_TextValue("Open Leads",
				GetText(driver,By.xpath("//*[contains(@text,'Open Leads')]")));
		Thread.sleep(1000);
		Click_Element(driver,VKT_PatientsOpen.VKT_OPbacktoDB);	
		Thread.sleep(1000);
		Logout_VigoKonnect();
	}
	
	@Ignore
	//Completing  a case and checking for increase in count for both total completed leads 
	//and also in hospital  wise statistics.
	public void VKTTS08TC004() throws Exception{
		System.out.println("=============== VKTTS08TC004 =======================");
		//
	}

	@Test//(retryAnalyzer = Customlisteners.class)//(threadPoolSize=1, invocationCount = 3)
	//5.Validating increase in total hospitals count by 1 after adding a hospital and searching by hospital name
	public void VKTTS08TC005() throws Exception{
		System.out.println("=============== VKTTS08TC005 =======================");
		Login_VigoKonnect_Username(vseAdminName);
		int hospitalCount = Integer.parseInt(GetText(driver,VKT_DashboardPage.VKT_VSE_TotalHospitalsCount));
		Hospital obj=new Hospital();
		obj.addHospital();
		Thread.sleep(2500);
		Assert_TextValue(Integer.toString(hospitalCount+1),GetText(driver,VKT_DashboardPage.VKT_VSE_TotalHospitalsCount));
		VKT_HospitalVerification(obj.hospitalName);
		Click_Element(driver,VKT_PatientsOpen.VKT_OPbacktoDB);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//6.Validating increase in open cases count by 1 after registering a patient
	//using hospital created under current VSE and searching using patient name .
	public void VKTTS08TC006() throws Exception {
		System.out.println("=============== VKTTS08TC006 =======================");
		//adding hospital
		Login_VigoKonnect_Username(vseAdminName);
		implicitWait(driver,2000);
		int hospitalCount = Integer.parseInt(GetText(driver, VKT_DashboardPage.VKT_VSE_TotalHospitalsCount));
		int caseOpenCount = Integer.parseInt(GetText(driver, VKT_DashboardPage.VKT_VSE_OpenCount));
		Hospital obj = new Hospital();
		obj.addHospital();
		Logout_VigoKonnect();

		//accessing id of the created vsp admin
		String[] tempIds=obj.getId(accessToken);
		String tempAdminId= tempIds[0];
		String tempHospId= tempIds[1];

		//setting password for created hospital's admin
		obj.setPassword(tempAdminId);

		//creating a doctor under created hospital
		String phno=RandomStringUtils.random(10, false, true);
		String random4Dig=RandomStringUtils.random(4, false, true);
		String reqbody="{"
				+ "\"businessPartners\":["
				+ "{"
				+ "\"businessPartnerId\":\""+tempHospId+"\","
				+ "\"businessPartnerName\":\""+obj.hospitalName+"\","
				+ "\"location\":\"\","
				+ "\"displayName\":\"apiVSPDoctor"+random4Dig+"\","
				+ "\"speciality\":\"Cardiology\","
				+ "\"providerNumber\":\"\","
				+ "\"email\":\"\","
				+ "\"layout\":[],"
				+ "\"country\":\"INDIA\","
				+ "\"roles\":["
				+ "{"
				+ "\"role\":\"INTERNAL_DOCTOR\""
				+ "}]"
				+ "}],"
				+ "\"firstName\":\"apiVSPDoctor"+random4Dig+"\","
				+ "\"lastName\":\"test\","
				+ "\"id\":\"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"role\":\"DOCTOR\","
				+ "\"country\":\"INDIA\","
				+ "\"MCIRegNumber\":\"\""
				+ "}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject docObj=new JSONObject(getResponse.getBody().asString());
		String tempDocName=docObj.get("firstName").toString();
		System.out.println("VSP DOCTOR NAME : "+tempDocName);
		String tempDocId=docObj.get("id").toString();
		System.out.println("Doctor with name "+tempDocName+" has been created");

		//creating case
		implicitWait(driver,1000);
		Login_VigoKonnect_Username(obj.userName);
		CaseCreation caseObj = new CaseCreation();
		caseObj.doctor = tempDocName;
		RegisterPatient(caseObj);
		caseCreationSuccessPage();
		implicitWait(driver,2000);
		String caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		System.out.println("Patient Id \t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Logout_VigoKonnect();

		//verifying case using vse admin
		implicitWait(driver,1000);
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue(Integer.toString(hospitalCount + 1),
				GetText(driver, VKT_DashboardPage.VKT_VSE_TotalHospitalsCount));
		Assert_TextValue(Integer.toString(caseOpenCount + 1),
				GetText(driver, VKT_DashboardPage.VKT_VSE_OpenCount));
		Click_Element(driver, VKT_DashboardPage.VKT_VSE_OpenCount);
		EnterText(driver,VKT_PatientsOpen.VKT_SearchTextWithName,caseObj.firstName);
		TakeScreenshot(driver,"VKT_PatientOpenList");
		int ele = driver.findElements(VKT_PatientsOpen.patient(caseObj.firstName))
				.size();
		if (ele == 0)
			throw new Exception("case not found");
		System.out.println("Case with patient name "+caseObj.firstName + " found");
		implicitWait(driver, 1000);
		Click_Element(driver, VKT_PatientsOpen.VKT_OPbacktoDB);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	//7.Validating increase in open cases count by 1 after registering a patient using
	// hospital created under current VSE and  searching  using patient name after filtering.
	public void VKTTS08TC007() throws Exception {
		System.out.println("=============== VKTTS08TC007 =======================");
		//adding hospital
		Login_VigoKonnect_Username(vseAdminName);
		implicitWait(driver,2000);
		int hospitalCount = Integer.parseInt(GetText(driver, VKT_DashboardPage.VKT_VSE_TotalHospitalsCount));
		int caseOpenCount = Integer.parseInt(GetText(driver, VKT_DashboardPage.VKT_VSE_OpenCount));
		Hospital obj = new Hospital();
		obj.addHospital();
		Logout_VigoKonnect();

		//accessing id of the created vsp admin
		String[] tempIds=obj.getId(accessToken);
		String tempAdminId= tempIds[0];
		String tempHospId= tempIds[1];


		//setting password for created hospital's admin
		obj.setPassword(tempAdminId);



		//creating a doctor under created hospital
		String phno=RandomStringUtils.random(10, false, true);
		String random4Dig=RandomStringUtils.random(4, false, true);
		String reqbody="{"
				+ "\"businessPartners\":["
				+ "{"
				+ "\"businessPartnerId\":\""+tempHospId+"\","
				+ "\"businessPartnerName\":\""+obj.hospitalName+"\","
				+ "\"location\":\"\","
				+ "\"displayName\":\"apiVSPDoctor"+random4Dig+"\","
				+ "\"speciality\":\"Cardiology\","
				+ "\"providerNumber\":\"\","
				+ "\"email\":\"\","
				+ "\"layout\":[],"
				+ "\"country\":\"INDIA\","
				+ "\"roles\":["
				+ "{"
				+ "\"role\":\"INTERNAL_DOCTOR\""
				+ "}]"
				+ "}],"
				+ "\"firstName\":\"apiVSPDoctor"+random4Dig+"\","
				+ "\"lastName\":\"test\","
				+ "\"id\":\"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"role\":\"DOCTOR\","
				+ "\"country\":\"INDIA\","
				+ "\"MCIRegNumber\":\"\""
				+ "}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject docObj=new JSONObject(getResponse.getBody().asString());
		String tempDocName=docObj.get("firstName").toString();
		System.out.println("VSP DOCTOR NAME : "+tempDocName);
		String tempDocId=docObj.get("id").toString();
		System.out.println("Doctor with name "+tempDocName+" has been created");

		//creating case
		implicitWait(driver,1000);
		Login_VigoKonnect_Username(obj.userName);
		CaseCreation caseObj = new CaseCreation();
		caseObj.doctor = tempDocName;
		RegisterPatient(caseObj);
		caseCreationSuccessPage();
		implicitWait(driver,2000);
		String caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		System.out.println("Patient Id \t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Logout_VigoKonnect();

		//verifying case using vse admin
		implicitWait(driver,1000);
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue(Integer.toString(hospitalCount + 1),
				GetText(driver, VKT_DashboardPage.VKT_VSE_TotalHospitalsCount));
		Assert_TextValue(Integer.toString(caseOpenCount + 1),
				GetText(driver, VKT_DashboardPage.VKT_VSE_OpenCount));
		Click_Element(driver, VKT_DashboardPage.VKT_VSE_OpenCount);
		implicitWait(driver,1000);
		Click_Element(driver, VKT_PatientsOpen.VKT_FilterWithVSP);
		TakeScreenshot(driver,"VKT_FilterList");
		Click_Element(driver,VKT_PatientsOpen.hospital(obj.hospitalName));
		Click_Element(driver, VKT_PatientsOpen.VKT_EscapeFromFilter);
		EnterText(driver,VKT_PatientsOpen.VKT_SearchTextWithName,caseObj.firstName);
		TakeScreenshot(driver,"VKT_PatientOpenList");
		int ele = driver.findElements(VKT_PatientsOpen.patient(caseObj.firstName))
				.size();
		if (ele == 0)
			throw new Exception("case not found");
		System.out.println("Case with patient name "+caseObj.firstName + " found");
		implicitWait(driver, 1000);
		Click_Element(driver, VKT_PatientsOpen.VKT_OPbacktoDB);
		Logout_VigoKonnect();
	}

	@Test//(retryAnalyzer = Customlisteners.class)
	// 8.Validating increase in open cases count by 1 after registering a patient
	// using
	// hospital created under current VSE and searching using patient name after
	// filtering.
	public void VKTTS08TC008() throws Exception {
		System.out.println("=============== VKTTS08TC008 =======================");
		//adding hospital
		Login_VigoKonnect_Username(vseAdminName);
		implicitWait(driver,2000);
		int hospitalCount = Integer.parseInt(GetText(driver, VKT_DashboardPage.VKT_VSE_TotalHospitalsCount));
		int caseOpenCount = Integer.parseInt(GetText(driver, VKT_DashboardPage.VKT_VSE_OpenCount));
		Hospital obj = new Hospital();
		obj.addHospital();
		VKT_HospitalVerification(obj.hospitalName);
TakeScreenshot(driver,"VKT_TotalHospitalList");
		
		int totalLength=driver.findElements(VKT_HospitalStatisticsPage.VKT_TotalHospitalsCountInCurrentPage).size();
		int hList=totalLength/4;
		System.out.println("Total length \t:"+hList);
		int i;
		boolean flag=true;
		for(i=1;i<=hList;i++) {
			implicitWait(driver,2000);
			String tempHospitalName = GetText(driver,VKT_HospitalStatisticsPage.getContent(i, 1));
			
			if(obj.hospitalName.equals(tempHospitalName)) {
				System.out.println("Found the hospital");
				flag=false;
				break;
			}
		}
		if(flag) {
			throw new Error("Hospital Not Found");
		}
		int hospOpenCount =Integer.parseInt(GetText(driver,VKT_HospitalStatisticsPage.getContent(i, 2)));
		int hospInProg=Integer.parseInt(GetText(driver,VKT_HospitalStatisticsPage.getContent(i, 3)));
		int hospClosed=Integer.parseInt(GetText(driver,VKT_HospitalStatisticsPage.getContent(i, 4)));
		Logout_VigoKonnect();

		//accessing id of the created vsp admin
		String[] tempIds=obj.getId(accessToken);
		String tempAdminId= tempIds[0];
		String tempHospId= tempIds[1];

		//setting password for created hospital's admin
		obj.setPassword(tempAdminId);

		//creating a doctor under created hospital
		String phno=RandomStringUtils.random(10, false, true);
		String random4Dig=RandomStringUtils.random(4, false, true);
		String reqbody="{"
				+ "\"businessPartners\":["
				+ "{"
				+ "\"businessPartnerId\":\""+tempHospId+"\","
				+ "\"businessPartnerName\":\""+obj.hospitalName+"\","
				+ "\"location\":\"\","
				+ "\"displayName\":\"apiVSPDoctor"+random4Dig+"\","
				+ "\"speciality\":\"Cardiology\","
				+ "\"providerNumber\":\"\","
				+ "\"email\":\"\","
				+ "\"layout\":[],"
				+ "\"country\":\"INDIA\","
				+ "\"roles\":["
				+ "{"
				+ "\"role\":\"INTERNAL_DOCTOR\""
				+ "}]"
				+ "}],"
				+ "\"firstName\":\"apiVSPDoctor"+random4Dig+"\","
				+ "\"lastName\":\"test\","
				+ "\"id\":\"\","
				+ "\"mobile\":{"
				+ "\"countryCode\":\"91\","
				+ "\"number\":\""+phno+"\""
				+ "},"
				+ "\"role\":\"DOCTOR\","
				+ "\"country\":\"INDIA\","
				+ "\"MCIRegNumber\":\"\""
				+ "}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.post("https://api.mvm2.qa.vigocare.com/v1/admin/doctor/")
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject docObj=new JSONObject(getResponse.getBody().asString());
		String tempDocName=docObj.get("firstName").toString();
		System.out.println("VSP DOCTOR NAME : "+tempDocName);
		String tempDocId=docObj.get("id").toString();
		System.out.println("Doctor with name "+tempDocName+" has been created");

		//creating case
		implicitWait(driver,1000);
		Login_VigoKonnect_Username(obj.userName);
		CaseCreation caseObj = new CaseCreation();
		caseObj.doctor = tempDocName;
		RegisterPatient(caseObj);
		caseCreationSuccessPage();
		implicitWait(driver,2000);
		String caseId = GetText(driver,VKT_RegisterPatient_Page.VKT_CaseId);
		System.out.println("Patient Id \t:"+caseId);
		Click_Element(driver,VKT_RegisterPatient_Page.VKT_BackButton);
		Logout_VigoKonnect();

		//verifying case using vse admin
		implicitWait(driver,1000);
		Login_VigoKonnect_Username(vseAdminName);
		Assert_TextValue(Integer.toString(hospitalCount + 1),
				GetText(driver, VKT_DashboardPage.VKT_VSE_TotalHospitalsCount));
		Assert_TextValue(Integer.toString(caseOpenCount + 1),
				GetText(driver, VKT_DashboardPage.VKT_VSE_OpenCount));
//		VKT_HospitalVerification(obj.hospitalName);
//		Assert_TextValue(Integer.toString(hospOpenCount+1),GetText(driver,VKT_HospitalStatisticsPage.getContent(1, 2)));
//		Assert_TextValue(Integer.toString(hospInProg),GetText(driver,VKT_HospitalStatisticsPage.getContent(1, 3)));
//		Assert_TextValue(Integer.toString(hospClosed),GetText(driver,VKT_HospitalStatisticsPage.getContent(1, 4)));
//		Click_Element(driver,VKT_HospitalStatisticsPage.hospital(obj.hospitalName));
		//
		Click_Element(driver, VKT_DashboardPage.VKT_VSE_TotalHospitals);
		implicitWait(driver, 2000);
		TakeScreenshot(driver,"VKT_TotalHospitalList");
		
		totalLength=driver.findElements(VKT_HospitalStatisticsPage.VKT_TotalHospitalsCountInCurrentPage).size();
		hList=totalLength/4;
		System.out.println("Total length \t:"+hList);
		i=0;
		flag=true;
		for(i=1;i<=hList;i++) {
			implicitWait(driver,2000);
			String tempHospitalName = GetText(driver,VKT_HospitalStatisticsPage.getContent(i, 1));
			
			if(obj.hospitalName.equals(tempHospitalName)) {
				System.out.println("Found the hospital");
				flag=false;
				break;
			}
		}
		if(flag) {
			throw new Error("Hospital Not Found");
		}
		implicitWait(driver,1000);
		Assert_TextValue(Integer.toString(hospOpenCount+1),GetText(driver,VKT_HospitalStatisticsPage.getContent(i, 2)));
		Assert_TextValue(Integer.toString(hospInProg),GetText(driver,VKT_HospitalStatisticsPage.getContent(i, 3)));
		Assert_TextValue(Integer.toString(hospClosed),GetText(driver,VKT_HospitalStatisticsPage.getContent(i, 4)));
		Click_Element(driver,VKT_HospitalStatisticsPage.getContent(i, 1));
		implicitWait(driver,1000);
		//
		TakeScreenshot(driver,"VKT_HospitalPatientCasesList");
		//Assert_TextValue(obj.hospitalName,GetText(driver,VKT_HospitalCasesPage.VKT_HospitalCaseTitle(obj.hospitalName)));
		Assert_TextValue(caseObj.fullName,GetText(driver,VKT_HospitalStatisticsPage.hospital(caseObj.firstName)));
		implicitWait(driver, 1000);
		//Click_Element(driver, VKT_PatientsOpen.VKT_OPbacktoDB);
		Logout_VigoKonnect();
	}

	@Ignore
	//Checking open count decreases after completing a created case recently and 
	//the case details not present in hospital patient list
	public void VKTTS08TC009() throws Exception{
		
	}
}
