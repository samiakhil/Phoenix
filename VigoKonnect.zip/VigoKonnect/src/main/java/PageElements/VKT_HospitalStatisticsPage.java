package PageElements;

import org.openqa.selenium.By;

public class VKT_HospitalStatisticsPage {
	public static By VKT_title = By.xpath("//android.view.View/android.view.View[2]/android.view.View[5]");
	//public static By VKT_title = By.xpath("//android.view.View[contains(@text,'Hospital')]");
	
	public static By VKT_BackButton = By.xpath("//android.view.View[2]/android.view.View[4]");
	//public static By VKT_SearchButton = By.xpath("//android.widget.Image[3]");
	
	public static By VKT_SearchHospitalTextField = By.xpath("//android.widget.EditText");
	
	public static By VKT_SearchButton = By.xpath("//android.view.View[2]/android.view.View[6]/android.view.View/android.view.View/android.view.View/android.widget.Image");
	//public static By VKT_SearchButton = By.xpath("//android.widget.Image[4]");
	public static By hospital(String hospitalName) {
		return By.xpath("(//android.view.View[contains(@text,'"+hospitalName+"')])");
	}
	public static By VKT_TotalHospitalsCountInCurrentPage = By.xpath("//android.widget.ListView/android.view.View/android.view.View/android.view.View/android.view.View/android.view.View");
	
	public static By getContent(int i,int j) {
		return By.xpath("//android.widget.ListView/android.view.View["+i+"]/android.view.View/android.view.View/android.view.View/android.view.View["+j+"]/android.view.View");
	}
}
