package PageElements;

import org.openqa.selenium.By;

public class CMS_Nurse {
	public static By Cms_Nurse_Navbar_Title= By.xpath("//span[contains(text(),'Nurses') and @class='no-redirect']");
	public static By Cms_Nurse_Page_Title= By.xpath("//h2[contains(text(),'Nurses')]");
}
