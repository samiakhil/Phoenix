package PageElements;

import org.openqa.selenium.By;

public class VKT_SideMenu {
	//public static By VKT_UserType = By.xpath("(//android.view.View[1]/android.view.View[2]/android.view.View[2]/android.view.View[2])[1]");
	public static By VKT_DB = By.xpath("//android.view.View[contains(@text,'Dashboard')]");
	public static By VKT_Account = By.xpath("//android.view.View[contains(@text,'Account')]");
	
	public static By VKT_Doctors = By.xpath("//android.view.View[contains(@text,'Doctors')]");
	public static By VKT_AddDoctorButtonImage = By.xpath("//android.view.View[3]/android.view.View/android.widget.Button");
	
	public static By VKT_Associates = By.xpath("//android.view.View[contains(@text,'Associates')]");
	public static By VKT_AddAssociateButtonImage = By.xpath("//android.view.View[3]/android.view.View/android.widget.Button");
	
	public static By VKT_Hospitals = By.xpath("//android.view.View[contains(@text,'Hospitals')]");
	public static By VKT_TextFieldForHospitalName = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[1]");
	public static By VKT_SearchButton = By.xpath("//android.view.View[2]/android.view.View[3]/android.view.View/android.view.View/android.view.View/android.widget.Image");
	public static By VKT_AddHospitalImageButton = By.xpath("//android.view.View[3]/android.view.View/android.widget.Button");
	
	public static By VKT_MenuButton = By.xpath("//android.widget.Image[contains(@text,'menublue') or contains(@text,'side-menu-blue')]");
	public static By VKT_Logout = By.xpath("//android.widget.Button[contains(@text,'LOGOUT')]");
	
	public static By getElementXpath(String name) {
		return By.xpath("//*[contains(@text,'"+name+"')]");
	}
}
