package PageElements;

import org.openqa.selenium.By;

public class VKT_PatientDetails {
	public static By VKT_PatientCaseId = By.xpath("//android.view.View[contains(@text,'VC') and contains(@text,'VP')]");
	public static By VKT_PatientBackButton=By.xpath("//android.widget.Image[contains(@text,'back-icon')]");
}
