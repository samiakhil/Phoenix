package PageElements;

import org.openqa.selenium.By;

public class VKT_AddDoctor {
	public static By VKT_DocBackButton = By.xpath("//android.widget.Image[contains(@text,'back-icon-pd')]");
	public static By VKT_DocPageTitle= By.xpath("//android.view.View[contains(@text,'ADD DOCTOR')]");
	public static By VKT_DocFirstName = By.xpath("//android.widget.TextView[contains(@text,'First Name')]/following-sibling::android.view.View[1]/child::android.widget.EditText");
	public static By VKT_DocLastName= By.xpath("//android.widget.TextView[contains(@text,'Last Name')]/following-sibling::android.view.View[1]/child::android.widget.EditText");
	public static By VKT_DocDisplayName= By.xpath("//android.widget.TextView[contains(@text,'Display Name')]/following-sibling::android.view.View[1]/child::android.widget.EditText");
	public static By VKT_DocEmail= By.xpath("//android.widget.TextView[contains(@text,'Email')]/following-sibling::android.view.View[1]/child::android.widget.EditText");
	public static By VKT_DocMobileNumber= By.xpath("//android.widget.TextView[contains(@text,'Mobile Number')]/following-sibling::android.view.View[2]/descendant::android.widget.EditText");
	public static By VKT_DocMICNumber= By.xpath("//android.widget.TextView[contains(@text,'MCI License Number')]/following-sibling::android.view.View[1]/child::android.widget.EditText");
	public static By VKT_DocSpeciality= By.xpath("//android.widget.TextView[contains(@text,'Speciality')]/following-sibling::android.view.View[1]");
	public static By VKT_DocSpecialityType(String specialityType) {
		return By.xpath("//android.widget.RadioButton[contains(@text,'"+specialityType+"')]");
	}
	public static By VKT_DocType= By.xpath("//android.view.View[contains(@text,'Type*')]/following-sibling::android.view.View/android.view.View");
	public static By VKT_DocType(String Type) {
		return By.xpath("//android.widget.RadioButton[contains(@text,'"+Type+"')]");
	}
	public static By VKT_DocSubmit= By.xpath("//android.widget.Button[contains(@text,'SUBMIT')]");
	
	public static By VKT_SuccessMsg = By.xpath("//android.view.View[contains(@text,'The Profile')]");
	public static By VKT_ReferenceId = By.xpath("//android.view.View[contains(@text,'Reference')]");
	public static By VKT_DoneButton = By.xpath("//android.widget.Button[contains(@text,'DONE')]");
	
	public static By VKT_DocMobileError = By.xpath("//android.view.View[contains(@text,'Mobile number is associated with')]");
	public static By VKT_DocAddNew = By.xpath("//android.widget.Button[contains(@text,'ADD NEW')]");
	public static By VKT_DocContinue = By.xpath("//android.widget.Button[contains(@text,'CONTINUE')]");
	public static By VKT_DocContinueAlert = By.xpath("//android.view.View[contains(@text,\"Can't add doctor with same mobile number under same hospital\")]");
	public static By VKT_DocAlert = By.xpath("//android.view.View[contains(@text,'Please')]");
	public static By VKT_MCIAlert = By.xpath("//android.view.View[contains(@text,'Doctor with')]"); 
	
	public static By getXpathForDoctorFromList(String dName) {
		return By.xpath("//android.widget.Button[contains(@text,'Dr. "+dName+"')]");
	}
	
	public static By VKT_DocEditPageTitle= By.xpath("//android.view.View[contains(@text,'EDIT DOCTOR')]");
	public static By VKT_DocEditButton= By.xpath("//android.widget.Button[contains(@text,'EDIT')]");
	public static By VKT_DocSaveButton= By.xpath("//android.widget.Button[contains(@text,'SAVE')]");
	
}