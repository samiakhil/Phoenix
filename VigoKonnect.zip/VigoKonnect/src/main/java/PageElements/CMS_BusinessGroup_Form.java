package PageElements;

import org.openqa.selenium.By;

public class CMS_BusinessGroup_Form {
	public static By Cms_BusinessGroupFrom_Navbar_Title= By.xpath("//span[contains(text(),'CreateBusinessGroup')]");
	public static By Cms_BusinessGroupForm_Page_Title=By.xpath("//h2[contains(text(),'CreateBusinessGroup')]");
	public static By CmsBusinessGroupForm_Name= By.xpath("//input[@placeholder='Name']");
}
