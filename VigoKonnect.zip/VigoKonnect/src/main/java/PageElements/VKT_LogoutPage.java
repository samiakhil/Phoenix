package PageElements;

import org.openqa.selenium.By;

public class VKT_LogoutPage {
	public static By VKT_LogoutPopup = By.xpath("//android.view.View[contains(@text,'Are you')]");
	public static By VKT_LogoutConfirm = By.xpath("//android.widget.Button[contains(@text,'CONFIRM')]");
	public static By VKT_LogoutCancel = By.xpath("//android.widget.Button[contains(@text,'CANCEL')]");
}
