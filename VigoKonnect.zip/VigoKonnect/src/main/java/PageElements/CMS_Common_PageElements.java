package PageElements;

import org.openqa.selenium.By;

public class CMS_Common_PageElements {
	public static By Cms_CreateNew=By.xpath("//span[contains(text(),'Create New')]");
	public static By Cms_SearchBox=By.xpath("//input[@placeholder='search']");
	public static By Cms_SearchButton=By.xpath("//span[contains(text(),'SEARCH')]");
	public static By Cms_Form_CancelButton = By.xpath("//button[@role='cancelbutton'and @class='ripple-btn default']");
	public static By Cms_Form_SaveButton = By.xpath("//button[@role='savebutton']");
	public static By Cms_Delete_Button = By.xpath("//table/descendant::tbody/descendant::button[2]");
	public static By Cms_Edit_Button = By.xpath("//table/descendant::tbody/descendant::button[1]");
	public static By Cms_OK_Button = By.xpath("//button[@role='okbutton']");
}
