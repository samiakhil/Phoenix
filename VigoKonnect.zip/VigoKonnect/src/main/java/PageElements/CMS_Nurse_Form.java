package PageElements;

import org.openqa.selenium.By;

public class CMS_Nurse_Form {
	public static By Cms_NurseForm_Navbar_Title= By.xpath("//span[contains(text(),'Create Nurse')]");
	public static By Cms_NurseForm_Page_Title=By.xpath("//h2[contains(text(),'Create Nurse')]");
	public static By Cms_NurseForm_FirstName=By.xpath("//input[@placeholder='First Name']");
	public static By Cms_NurseForm_LastName=By.xpath("//input[@placeholder='Last Name']");
	public static By Cms_NurseForm_Email=By.xpath("//input[@placeholder='Email']");
	public static By Cms_NurseForm_Hospital=By.xpath("//input[@placeholder='Select Hospital']");
	public static By Cms_NurseForm_Speciality = By.xpath("//input[@placeholder='Select Speciality']");
	public static By Cms_NurseForm_Mobile = By.xpath("//input[@placeholder='Enter Mobile Number']");
	public static By Cms_NurseForm_MobileDrpDown= By.xpath("//span[contains(text(),'▼')]");
	public static By Cms_NurseForm_MobCountry_List =By.xpath("//input[@placeholder='Enter Mobile Number']/preceding-sibling::div/descendant::li");
}
