package PageElements;

import org.openqa.selenium.By;

public class VKT_HospitalCasesPage {
	public static By VKT_HospitalCaseTitle(String hospitalName) {
		return By.xpath("//android.view.View[contains(@text,'"+hospitalName+"')]");
	}
	public static By VKT_SearchBox = By.xpath("//android.widget.EditText");
	public static By patient(String patientName) {
		return By.xpath("//android.view.View[contains(@text,'"+patientName+"')]");
	}
}
