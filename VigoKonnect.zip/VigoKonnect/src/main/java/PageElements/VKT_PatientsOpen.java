package PageElements;

import org.openqa.selenium.By;

public class VKT_PatientsOpen {
	//public static By VK_Username_Button = By.xpath("//android.view.View[contains(@text,'Username')]");
	public static By VKT_SearchTextWithName = By.xpath("//android.widget.EditText[@package='vigo.doctor.app']");
	public static By VKT_SearchClick = By.xpath("(//android.widget.Image[@package='vigo.doctor.app'])[5]");
	public static By VKT_FilterWithVSP = By.xpath("(//android.widget.Image[@package='vigo.doctor.app'])[4]");
	public static By VKT_OPbacktoDB = By.xpath("(//android.widget.Image[@package='vigo.doctor.app'])[3]");
	public static By patient(String patientName) {
		return By.xpath("(//android.view.View[contains(@text,'"+patientName+"')])");
	}
	public static By VKT_EscapeFromFilter=By.xpath("//android.view.View");
	public static By hospital(String hospitalName) {
		return By.xpath("//android.widget.CheckBox[contains(@text,'"+hospitalName+"')]");
	}
}