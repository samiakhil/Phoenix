package PageElements;

import org.openqa.selenium.By;

public class CMS_VSE_EditPage {
	public static By Cms_VseEdit_Navbar_Title= By.xpath("//span[contains(text(),'Edit Vigo Service Enabler')]");
	public static By Cms_VsesEdit_Page_Title=By.xpath("//h2[contains(text(),'Edit Vigo Service Enabler')]");
	public static By Cms_VseEdit_ServicesSearch = By.xpath("//label[contains(text(),'Services Subscribed')]/following-sibling::div/descendant::input[@placeholder]");
	public static By Cms_VseEdit_Services=By.xpath("//input[@placeholder='Service']/following-sibling::span/descendant::i");
}
