package PageElements;
import org.openqa.selenium.By;
import org.testng.annotations.Ignore;

public class VKT_RegisterPatient_Page {
	////android.widget.RadioButton[contains(@text,'+61')]
	//public static By VK_Username_Button = By.xpath("//android.view.View[contains(@text,'Username')]");
	
	public static By VKT_RegPatientTitle = By.xpath("(//android.view.View[contains(@text,'REGISTER')])");
	
	public static By VKT_IND_CODE = By.xpath("//android.widget.Spinner[contains(@text,'+91')]");
	
	public static By VKT_Select_Country = By.xpath("//android.widget.Spinner[contains(@text,'+91')]");
	public static By VKT = By.xpath("(//android.widget.RadioButton[contains(@text,'+61')])[2]");
	
	public static By VKT_RegPatient_MobileNumber = By.xpath("(//android.widget.EditText)[1]");
	
	public static By VKT_RegPatientFirstName = By.xpath("(//android.widget.EditText)[2]");
	public static By VKT_RegPatientLastName = By.xpath("(//android.widget.EditText)[3]");
	public static By VKT_RegPatientPincode = By.xpath("(//android.widget.EditText)[4]");
	public static By VKT_RegPatientTreatingDoctor = By.xpath("(//android.widget.EditText)[5]");
	public static By VKT_RegPatient_SearchDoctor = By.xpath("//android.widget.EditText");
	public static By VKT_1stDoctor_List = By.xpath("//android.widget.Button[contains(@text,'Dr')]");
	
	public static By VKT_RegPatientSelectService = By.xpath("//android.widget.TextView[contains(@text,'Service')]/following-sibling::android.view.View[1]/descendant::android.view.View");
	public static By VKT_SelectVigoLife = By.xpath("//android.widget.RadioButton[contains(@text,'Vigo Life')]");
	public static By VKT_SelectTestService = By.xpath("//android.widget.RadioButton[contains(@text,'testService')]");
	
	public static By VKT_RegPatientSubmit = By.xpath("//android.widget.Button[contains(@text,'SUBMIT')]");
	
	public static By ErrorMsg = By.xpath("//android.view.View[contains(@text,'Please')]");
	

	public static By VKT_Patient_ID = By.xpath("//android.view.View[contains(@text,'Patient ID')]");
	public static By VKT_Patient_Done = By.xpath("//android.widget.Button[contains(@text,'DONE')]");
	public static By VKT_TopPaientId = By.xpath("//android.widget.Button[contains(@text,'VP')][1]");
	public static By VKT_VSE_NewPatient_Button=By.xpath("//android.widget.Button[contains(@text,'ADD NEW PATIENT')]");
	//public static By VKT_AlreadyMonitiring_MessageDialogBox_OkButton=By.xpath("//android.view.View[@text='There is a monitoring already going on with this mobile number, please use a different mobile number']/following-sibling::android.widget.Button[@text='OK']");
	public static By VKT_AlreadyMonitiring_MessageDialogBox_OkButton=By.xpath("//android.widget.Button[contains(@text,'OK')]");
	public static By VKT_BackButton=By.xpath("//android.widget.Image[contains(@text,'back-icon')]");
	public static By VKT_CaseId = By.xpath("//android.view.View[contains(@text,'VC')]");

	public static By VKT_Patient_AddNew=By.xpath("//android.widget.Button[contains(@text,'ADD NEW PATIENT')]");
	public static By VKT_Patient_OK=By.xpath("//android.widget.Button[contains(@text,'OK')]");
	public static By VKT_Patient_AddNewPopupText=By.xpath("//android.view.View[contains(@text,'Please select or add a new patient')]");
	public static By VKT_Patient_PopUp=By.xpath("//android.view.View[contains(@text,'There is a monitoring already going on with this mobile number, please use a different mobile number')]");
	public static By VKT_PatientReg_View = By.xpath("//android.view.View");
	public static By VKT_Patinet_Alert = By.xpath("//android.view.View[contains(@text,'Please')]");
}
