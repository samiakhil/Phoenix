package PageElements;

import org.openqa.selenium.By;

public class CMS_Login extends VKT_Login {

	public static By Cms_Username = By.id("email");
	public static By Cms_Password = By.id("password");
	public static By Cms_Savelives_Checkbox = By.xpath("//span[@class='el-checkbox__inner']");
	public static By Cms_Signin_Button = By.xpath("//button[@role='loginbutton']");

}
