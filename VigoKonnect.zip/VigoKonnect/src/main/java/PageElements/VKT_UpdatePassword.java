package PageElements;

import org.openqa.selenium.By;

public class VKT_UpdatePassword {
	public static By VKT_ChangePwdTitle = By.xpath("//android.view.View[contains(@text,'Change Password')]");
	public static By VKT_NewPassword = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[1]");
	public static By VKT_ConfirmPassword = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[2]");
	public static By VKT_UpdateButton = By.xpath("//android.widget.Button[contains(@text,'UPDATE')]");
	public static By VKT_UpdateConfirmation = By.xpath("//android.view.View[contains(@text,'Password updated')]");
	public static By VKT_UpdateAlertNewPwd = By.xpath("//android.view.View[contains(@text,'Please enter new password')]");
	public static By VKT_UpdateAlertConfirmNewPwd = By.xpath("//android.view.View[contains(@text,'Please enter confirm password')]");
	public static By VKT_UpdateAlertError = By.xpath("//android.view.View[contains(@text,'New password')]");
	public static By VKT_UpdateAlertMismatchError = By.xpath("//android.view.View[contains(@text,'New password and confirm password are not matching')]");
}
