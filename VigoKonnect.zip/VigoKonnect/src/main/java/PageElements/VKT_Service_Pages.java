package PageElements;

import org.openqa.selenium.By;

public class VKT_Service_Pages {
	public static By VKT_Service_SearchBox = By.xpath("//android.widget.EditText");
}
