package PageElements;

import org.openqa.selenium.By;

public class CMS_BusinessPartnerForm {
	public static By Cms_BusinessPartnerForm_NavbarTitle= By.xpath("//span[contains(text(),'Create Business Partner')]");
	public static By Cms_BusinessPartnerFormPage_Title=By.xpath("//h2[contains(text(),'Create Business Partner')]");
	public static By Cms_BusinessPartnerForm_Name=By.xpath("//input[@placeholder='Partner Name']");
	public static By Cms_BusinessPartnerForm_Website= By.xpath("//input[@placeholder='Website']");
	public static By Cms_BusinessPartnerForm_Address1= By.xpath("//label[@for='addressLine1']/following-sibling::div/descendant::input[@placeholder='Address Line1']");
	public static By Cms_BusinessPartnerForm_Pincode= By.xpath("//input[@placeholder='Pincode']");
	public static By Cms_BusinessPartnerForm_Fname= By.xpath("//input[@placeholder='First Name']");
	public static By Cms_BusinessPartnerForm_Lname= By.xpath("//input[@placeholder='Last Name']");
	public static By Cms_BusinessPartnerForm_Email= By.xpath("//input[@placeholder='Email']");
	public static By Cms_BusinessPartnerForm_Mobile= By.xpath("//input[@placeholder='Enter Mobile Number']");
	public static By Cms_BusinessPartnerForm_ServicesSearch= By.xpath("//label[contains(text(),'Services Subscribed')]/following-sibling::div/descendant::input[@placeholder]");
	public static By Cms_BusinessPartnerForm_Services= By.xpath("//label[contains(text(),'Services Subscribed')]/following-sibling::div/descendant::i/parent::span/parent::span/preceding-sibling::input");
	public static By Cms_BusinessPartnerForm_SelectVSe= By.xpath("//input[@placeholder='Select VSE']");
	public static By Cms_BusinessPartnerForm_Country= By.xpath("//label[@for='country']/following-sibling::div/descendant::input");
	public static By Cms_BusinessPartnerForm_CountryList= By.xpath("//span[contains(text(),'INDIA')]/ancestor::ul");
	public static By Cms_BusinessPartnerForm_MobileDrpDown= By.xpath("//span[contains(text(),'▼')]");
	public static By Cms_BusinessPartnerForm_MobCountryList= By.xpath("//span[contains(text(),'▲')]/parent::span/following-sibling::ul/li");
	public static By Cms_BusinessPartnerForm_Role=By.xpath("//input[@placeholder='Select Permission']");
	public static By Cms_BusinessPartnerForm_RoleDrpDown=By.xpath("//input[@placeholder='Select Permission']/following-sibling::span/descendant::i[1]");
}
