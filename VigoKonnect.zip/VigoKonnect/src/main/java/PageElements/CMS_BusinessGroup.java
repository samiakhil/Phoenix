package PageElements;

import org.openqa.selenium.By;

public class CMS_BusinessGroup {
	public static By Cms_BusinessGroup_Navbar_Title= By.xpath("//span[contains(text(),'BusinessGroup') and @class='no-redirect']");
	public static By Cms_BusinessGroup_Page_Title=By.xpath("//h2[contains(text(),'BusinessGroup')]");
}
