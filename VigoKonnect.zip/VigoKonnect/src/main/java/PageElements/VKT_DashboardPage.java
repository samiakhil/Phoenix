package PageElements;

import org.openqa.selenium.By;

public class VKT_DashboardPage {
	//public static By VK_Username_Button = By.xpath("//android.view.View[contains(@text,'Username')]");
	public static By VKT_ASideMenu = By.xpath("//android.widget.Image[contains(@text,'Associate_Sidemenu') or contains(@text,'default-profile-menu') or contains(@text,'menu-icon') or contains(@text,'menublue')]");
	public static By VKT_PatientOpen = By.xpath("//android.view.View[contains(@text,'Open')]");
	public static By VKT_RegisterPatient=By.xpath("//android.view.View[@text='Register Patient']");
	public static By VKT_NameOfTheUser = By.xpath("//android.view.View[2]/android.view.View[2]/android.view.View[1]");

	//vsp
	public static By VKT_VSP_RegPatient = By.xpath("//android.view.View[contains(@text,'Register Patient')]");
	public static By VKT_VSP_AllMonitoring = By.xpath("//android.view.View[contains(@text,'All Monitorings')]");
	public static By VKT_VSP_Service(String serviceName) {
		return By.xpath("//android.view.View[contains(@text,'" + serviceName + "')]");}
	public static By VKT_VSP_Patient(String patientName) {
		return By.xpath("//android.widget.Button[contains(@text,'" + patientName + "')]");}
	//for doctor
	public static By VKT_DoctorProfile_Menu = By.xpath("//android.widget.Image[contains(@text,'default-profile-menu')]");
	public static By VKT_DoctorName = By.xpath("//android.view.View[contains(@text,'Dr')]");

	//vse
	public static By VKT_VSE_Dashboard = By.xpath("//android.view.View[contains(@text,'Dashboard')]");
	public static By VKT_VSE_Open = By.xpath("//android.view.View[contains(@text,'Open')]");
	public static By VKT_VSE_OpenCount = By.xpath("//android.view.View[contains(@text,'Open')]/following-sibling::android.view.View");
	public static By VKT_VSE_Inprogress = By.xpath("//android.view.View[contains(@text,'Inprogress')]");
	public static By VKT_VSE_InprogressCount = By.xpath("//android.view.View[contains(@text,'Inprogress')]/following-sibling::android.view.View");
	public static By VKT_VSE_TotalHospitals = By.xpath("//android.view.View[contains(@text,'Total Hospitals')]");
	public static By VKT_VSE_TotalHospitalsCount = By.xpath("//android.view.View[contains(@text,'Total Hospitals')]/following-sibling::android.view.View");
	public static By VKT_VSE_TotalCompletedLeads = By.xpath("//android.view.View[contains(@text,'Total Completed Leads')]");
	public static By VKT_VSE_TotalCompletedLeadsCount = By.xpath("//android.view.View[contains(@text,'Total Completed Leads')]/following-sibling::android.view.View");

	public static By getXpathForRole(String role) {
		return By.xpath("//*[contains(@text,'"+role+"')]");
	}
}
