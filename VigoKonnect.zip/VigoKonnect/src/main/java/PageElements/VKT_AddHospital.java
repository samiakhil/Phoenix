package PageElements;

import org.openqa.selenium.By;

public class VKT_AddHospital {
	public static By VKT_SideMenuInForm = By.xpath("//android.widget.Image[contains(@text,'menu-icon')]");
	
	public static By VKT_HospitalName = By.xpath("(//android.widget.EditText)[1]");
	public static By VKT_WebsiteUrl = By.xpath("(//android.widget.EditText)[2]");
	public static By VKT_ReportPassword = By.xpath("(//android.widget.EditText)[3]");
	public static By VKT_AddressLane1 = By.xpath("(//android.widget.EditText)[4]");
	public static By VKT_AddressLane2 = By.xpath("(//android.widget.EditText)[5]");
	public static By VKT_Pincode = By.xpath("(//android.widget.EditText)[6]");
	
	public static By VKT_ServicesSubscibe = By.xpath("//android.view.View[contains(@text,'Select Service') or contains(@text,'Vigo Life')]");
	public static By VKT_VigoLife = By.xpath("//android.widget.CheckBox[contains(@text,'Vigo Life')]");
	public static By VKT_testService = By.xpath("//android.widget.CheckBox[contains(@text,'testService')]");
	public static By VKT_BBPBSPO2 = By.xpath("//android.widget.CheckBox[contains(@text,'BBPBSPO2')]");
	public static By VKT_SmartHeart = By.xpath("//android.widget.CheckBox[contains(@text,'SmartHeart')]");
	public static By VKT_BSM_Viatom = By.xpath("//android.widget.CheckBox[contains(@text,'BSM_Viatom')]");
	
	public static By VKT_Page_View = By.xpath("(//android.widget.LinearLayout)[1]");
	
	public static By VKT_Next_Button = By.xpath("//android.view.View[contains(@text,'Next')]");
	//contact info
	public static By VKT_FirstName = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[1]");
	public static By VKT_LastName = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[2]");
	public static By VKT_Email = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[3]");
	
	public static By VKT_Role = By.xpath("//android.view.View[contains(@text,'Select Role') or contains(@text,'Accounts')]");
	public static By VKT_Accounts = By.xpath("//android.widget.CheckBox[contains(@text,'Accounts')]");
	public static By VKT_Management = By.xpath("//android.widget.CheckBox[contains(@text,'Management')]");
	public static By VKT_Clinical = By.xpath("//android.widget.CheckBox[contains(@text,'Clinical')]");
	public static By VKT_Communication = By.xpath("//android.widget.CheckBox[contains(@text,'Communication')]");
	
	public static By VKT_MobileNumber = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[4]");
	public static By VKT_UserName = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[5]");
	
	public static By VKT_Previous_Button = By.xpath("//android.view.View[contains(@text,'Prev')]");
	public static By VKT_SUBMIT_Button= By.xpath("//android.widget.Button[contains(@text,'SUBMIT')]");
	
	public static By VKT_HospitalErrorMsg = By.xpath("//android.view.View[contains(@text,'Please')]");	//Please
	public static By VKT_NameError = By.xpath("//android.view.View[contains(@text,'Name should')]"); //name 6 characters
	public static By VKT_PhoneNumberError = By.xpath("//android.view.View[contains(@text,'Enter')]");//Enter valid mobile number
	public static By VKT_UserName_Success = By.xpath("//android.view.View[contains(@text,'Congrats')]");//Congrats for username
	public static By VKT_UserNameExist = By.xpath("//android.view.View[contains(@text,'This Username')]");//Already username exist
	public static By VKT_UserNameError = By.xpath("//android.view.View[contains(@text,'Username should')]");//username should contain minimum 6 characters
	public static By VKT_HospitalExistError = By.xpath("//android.view.View[contains(@text,'Unable to add Hospital')]");//Unable to add hospital with same hospital name
	
	public static By getXpathForEditTextWithNum(String num) {
		return By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])["+num+"]");
	}
	
	public static By getXpathForAssertValues(int i) {
		return By.xpath("//android.view.View[2]/android.widget.ListView/android.view.View/android.view.View/android.view.View["+i+"]");
	}
}