package PageElements;
import org.openqa.selenium.By;

public class CMS_BusinessPartner {
	public static By Cms_BusinessPartner_Navbar_Title= By.xpath("//span[contains(text(),'Business Partner')and @class='no-redirect']");
	public static By Cms_BusinessPartner_Page_Title= By.xpath("//h2[contains(text(),'Business Partner')]");
	public static By Cms_BusinessPartner_CreateNew= By.xpath("//span[contains(text(),'Create New')]");
	public static By Cms_BusinessPartner_VSE= By.xpath("//span[contains(text(),'Vigo Service Enabler')]");
	public static By Cms_BusinessPartner_VSP= By.xpath("//span[contains(text(),'Vigo Service Provider')]");
	public static By Cms_BusinessPartner_Search=By.xpath("//input[@placeholder='search']");
	public static By Cms_BusinessPartner_SearchButton= By.xpath("//span[contains(text(),'SEARCH')]");
}
