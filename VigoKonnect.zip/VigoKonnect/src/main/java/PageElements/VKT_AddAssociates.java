package PageElements;

import org.openqa.selenium.By;

public class VKT_AddAssociates {
	public static By VKT_backButton = By.xpath("(//android.widget.Image[@package='vigo.doctor.app'])[1]");
	
	public static By VKT_firstName=By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[1]");
	public static By VKT_lastName=By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[2]");
	public static By VKT_mobileNumber=By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[3]");
	public static By VKT_email=By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[4]");
	public static By VKT_userName=By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[5]");
	public static By VKT_password=By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[6]");
	public static By VKT_confirmPassword=By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[7]");
	public static By VKT_giveAdminRights=By.xpath("(//android.widget.Button[contains(@text,'Give Admin Rights')])");
	public static By VKT_submit=By.xpath("(//android.widget.Button[contains(@text,'SUBMIT')])");
	public static By VKT_usernameError = By.xpath("//android.view.View[contains(@text,'')]");
	public static By VKT_firstNameError = By.xpath("//android.view.View[contains(@text,'Please')]");
	
	public static By VKT_SuccessMsg = By.xpath("//android.view.View[contains(@text,'The Profile')]");
	public static By VKT_AssociateReference = By.xpath("//android.view.View[contains(@text,'Reference')]");
	public static By VKT_DoneButton = By.xpath("//android.widget.Button[contains(@text,'DONE')]");
	
	public static By VKT_ErrorMsg= By.xpath("//android.view.View[contains(@text,'Please')]");
	
	public static By VKT_UserNameExistError= By.xpath("//android.view.View[contains(@text,'This Username')]");
	public static By VKT_UserNameCharactersLimitError= By.xpath("//android.view.View[contains(@text,'Username should contain minimum 6 characters')]");
	public static By VKT_PasswordError = By.xpath("//android.view.View[contains(@text,'Password')]");
	public static By VKT_ConfirmPasswordError = By.xpath("//android.view.View[contains(@text,'Confirm Password')]");
	public static By userAgent(String userName) {
		return By.xpath("//android.widget.Button[contains(@text,'"+userName+"')]");
	}
	
//edit
	public static By VKT_RoleEdit = By.xpath("//android.widget.TextView[contains(@text,'Role')]/following-sibling::android.view.View[1]/child::android.widget.EditText");
	public static By VKT_PasswordEdit = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[7]");
	public static By VKT_ConfirmPasswordEdit = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[8]");
	public static By VKT_Save = By.xpath("//android.widget.Button[contains(@text,'SAVE')]");
	public static By VKT_Edit = By.xpath("//android.widget.Button[contains(@text,'EDIT')]");
}
