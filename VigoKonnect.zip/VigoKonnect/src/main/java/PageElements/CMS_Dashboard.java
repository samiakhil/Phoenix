package PageElements;
import org.openqa.selenium.By;

public class CMS_Dashboard {
	public static By Cms_Dashboard_PartnerMangement= By.xpath("//span[contains(text(),'Partner Management')]");
	public static By Cms_Dashboard_BusinessPartner= By.xpath("//span[contains(text(),'Business Partner')]");
	public static By Cms_Dashboard_Doctors= By.xpath("//span[contains(text(),'Doctors')]");
	public static By Cms_Dashboard_Agents=By.xpath("//span[contains(text(),'Agents')]");
	public static By Cms_Dashboard_Nurses=By.xpath("//div[@class='sidebar-container open']/descendant::span[contains(text(),'Nurses')]");
	public static By Cms_Dashboard_BusinessGroup=By.xpath("//span[contains(text(),'Business Group')]");
	public static By Cms_Dashboard_Cases=By.xpath("//span[contains(text(),'cases')]");
	public static By Cms_Dashboard_PreMonitoring=By.xpath("//div[@class='sidebar-container open']/descendant::span[contains(text(),'Pre Monitoring')]");
	public static By Cms_Dashboard_CaseCreation=By.xpath("//span[contains(text(),'create case')]");
}
