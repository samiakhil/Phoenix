package PageElements;

import org.openqa.selenium.By;

public class CMS_Agents {
	public static By Cms_Agents_Navbar_Title= By.xpath("//span[contains(text(),'Agents')]");
	public static By Cms_Agents_Page_Title=By.xpath("//h2[contains(text(),'Agents')]");
	public static By Cms_Agents_CreateNew= By.xpath("//span[contains(text(),'Create New')]");
	public static By Cms_Agents_SearchBox= By.xpath("//input[@placeholder='search']");
	public static By Cms_Agents_SearchButton= By.xpath("//span[contains(text(),'SEARCH')]");
}
