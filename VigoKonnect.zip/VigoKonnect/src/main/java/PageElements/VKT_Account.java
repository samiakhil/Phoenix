package PageElements;

import org.openqa.selenium.By;

public class VKT_Account {
	//public static By VK_Username_Button = By.xpath("//android.view.View[contains(@text,'Username')]");
	
	public static By VKT_MenuIcon = By.xpath("//android.widget.Image[contains(@text,'menu-icon')]");
	public static By VKT_AccountName=By.xpath("(//android.view.View[contains(@text,'Name')]/following-sibling::android.view.View)[1]");
	public static By VKT_AccountUserType=By.xpath("(//android.view.View[contains(@text,'User Type')]/following-sibling::android.view.View)[1]");
	public static By VKT_AccountEmail=By.xpath("(//android.view.View[contains(@text,'Email')]/following-sibling::android.view.View)[1]");
	public static By VKT_AccountMobileNumber=By.xpath("(//android.view.View[contains(@text,'Mobile Number')]/following-sibling::android.view.View)[1]");
	public static By VKT_LOGOUT = By.xpath("//android.widget.Button[contains(@text,'LOGOUT')]");
	public static By VKT_ChangePasswordTitle=By.xpath("	//android.view.View[contains(@text,'CHANGE PASSWORD')]");
	public static By VKT_AccountChangePassword=By.xpath("//android.view.View[contains(@text,'Change Password')]");
	public static By VKT_AccountOldPassword = By.xpath("(//android.widget.EditText)[1]");
	public static By VKT_OldPasswordError=By.xpath("//android.view.View[contains(@text,'Please enter old password')]");
	public static By VKT_AccountNewPassword = By.xpath("(//android.widget.EditText)[2]");
	public static By VKT_NewPasswordError=By.xpath("//android.view.View[contains(@text,'Please enter new password')]");
	public static By VKT_AccountConfirmPassword = By.xpath("(//android.widget.EditText)[3]");
	public static By VKT_ConfirmPasswordError=By.xpath("//android.view.View[contains(@text,'Please enter confirm password')]");
	public static By VKT_NewPasswordLengthError=By.xpath("//android.view.View[contains(@text,'New password length should be of minimum 6 characters')]");
	public static By VKT_AccountPasswordMismatchError=By.xpath("//android.view.View[contains(@text,'Password mismatched')]");
	public static By VKT_AccountUpdate = By.xpath("//android.widget.Button[contains(@text,'UPDATE')]");
	public static By VKT_AccountCancel = By.xpath("//android.widget.Button[contains(@text,'CANCEL')]");
	public static By VKT_OldPasswordAlert = By.xpath("//android.view.View[contains(@text,'Old password is not valid')]");
	public static By VKT_PasswordSuccessMsg = By.xpath("//android.view.View[contains(@text,'Your password has been updated successfully')]");
	public static By VKT_SuccessPageDoneButton = By.xpath("//android.widget.Button[contains(@text,'DONE')]");
}
