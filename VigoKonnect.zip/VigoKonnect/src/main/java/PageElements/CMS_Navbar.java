package PageElements;

import org.openqa.selenium.By;

public class CMS_Navbar {
	public static By Cms_Navbar_UserAvatar=By.xpath("//div[@role='avatar' and @class='user-avatar']");
	public static By Cms_Navbar_Logout=By.xpath("//span[@class='logout' and contains(text(),'Logout')]");
	//public static By Cms_Navbar_Logout=By.xpath("//span[@class='logout']");
	
}
