package PageElements;

import org.openqa.selenium.By;

public class CMS_Agents_Form {
	public static By Cms_AgentsForm_Navbar_Title= By.xpath("//span[contains(text(),'Create Agent')]");
	public static By Cms_AgentsForm_Page_Title=By.xpath("//h2[contains(text(),'Create Agent')]");
	public static By Cms_Agents_FirstName=By.xpath("//input[@placeholder='First Name']");
	public static By Cms_Agents_LastName=By.xpath("//input[@placeholder='Last Name']");
	public static By Cms_Agents_Email=By.xpath("//input[@placeholder='Email']");
	public static By Cms_Agents_SelectRole=By.xpath("//input[@placeholder='Select Role']");
	public static By Cms_Agents_Mobile=By.xpath("//input[@placeholder='Enter Mobile Number']");
	public static By Cms_Agents_Mobile_DrpDown= By.xpath("//span[contains(text(),'▼')]");
	public static By Cms_Agents_Mob_CountryList= By.xpath("//span[contains(text(),'▲')]/parent::span/following-sibling::ul/li");
	public static By Cms_Agents_Password=By.xpath("//input[@placeholder='Password']");
	public static By Cms_Agents_PasswordView=By.xpath("//input[@placeholder='Password']/following-sibling::span");
	public static By Cms_Agents_ConfirmPassword=By.xpath("//input[@placeholder='Confirm Password']");
	public static By Cms_Agents_ConfirmPasswordView=By.xpath("//input[@placeholder='Confirm Password']/following-sibling::span");
	public static By Cms_Agents_CancelButton=By.xpath("//button[contains(text(),'Cancel')]");
	public static By Cms_Agents_SaveButton=By.xpath("//button[contains(text(),'Save')]");
}
