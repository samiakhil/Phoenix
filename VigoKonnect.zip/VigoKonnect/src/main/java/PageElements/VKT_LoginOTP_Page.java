package PageElements;

import org.openqa.selenium.By;

public class VKT_LoginOTP_Page {
	public static By VKT_OTP_Field1 = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[1]");
	
	public static By VKT_Verify_Button = By.xpath("//android.widget.Button[contains(@text,'VERIFY')]");
	public static By VKT_OTP_Failed = By.xpath("//android.view.View[contains(@text,'OTP verification failed...')]");
}
