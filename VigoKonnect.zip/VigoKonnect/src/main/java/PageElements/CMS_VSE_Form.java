package PageElements;

import org.openqa.selenium.By;

public class CMS_VSE_Form {
	public static By Cms_Vse_Navbar_Title= By.xpath("//span[contains(text(),'Create Vigo Service Enabler')]");
	public static By Cms_Vse_Page_Title= By.xpath("//h2[contains(text(),'Create Vigo Service Enabler')]");
	public static By Cms_Vse_Name = By.xpath("//input[@placeholder='VSE Name']");
	public static By Cms_Vse_License_Number = By.xpath("//input[@placeholder='VSE License Number']");
	public static By Cms_Vse_Country = By.xpath("//input[@placeholder='Country']");
	public static By Cms_Vse_Country_India= By.xpath("//span[contains(text(),'INDIA')]/parent::li");
	public static By Cms_Vse_Country_Australia= By.xpath("//span[contains(text(),'AUSTRALIA')]/parent::li");
	public static By Cms_Vse_First_Name = By.xpath("//input[@placeholder='First Name']");
	public static By Cms_Vse_Last_Name = By.xpath("//input[@placeholder='Last Name']");
	public static By Cms_Vse_Primary_Phone_Number = By.xpath("//label[@for='mobile.number']/following-sibling::div/descendant::input");
	public static By Cms_Vse_Primary_PhoneNumber_Countries= By.xpath("//label[@for='mobile.number']/following-sibling::div/descendant::div[@class='vti__dropdown']");
	public static By Cms_Vse_Alternate_Phone_Number = By.xpath("//label[contains(text(),'Alternate')]/following-sibling::div/descendant::input");
	public static By Cms_Vse_Alternate_Phone_Number_Countries= By.xpath("//label[contains(text(),'Alternate')]/following-sibling::div/descendant::div[@class='vti__dropdown']");
	public static By Cms_Vse_PhoneNumber_Australia= By.xpath("//strong[contains(text(),'Australia')]/ancestor::li");
	public static By Cms_Vse_PhoneNumber_India= By.xpath("//strong[contains(text(),'India')]/ancestor::li");
	public static By Cms_Vse_PhoneNumber_Indonesia= By.xpath("//strong[contains(text(),'Indonesia')]/ancestor::li");
	public static By Cms_Vse_Email_Id = By.xpath("//input[@placeholder='user@vigocare.com']");
	public static By Cms_Vse_Address_Line1 = By.xpath("//label[@for='addressLine1']/following-sibling::div/descendant::input");
	public static By Cms_Vse_Address_Line2 = By.xpath("//label[contains(text(),'Address Line2')]/following-sibling::div/descendant::input");
	public static By Cms_Vse_Pincode = By.xpath("//input[@placeholder='Pincode']");
	public static By Cms_Vse_Report_Password = By.xpath("//input[@placeholder='Report Password']");
	public static By Cms_Vse_Report_Password_View = By.xpath("//input[@placeholder='Report Password']/following-sibling::span/descendant::span[@class='el-icon-view']");
	public static By Cms_Vse_User_Name = By.xpath("//input[@placeholder='User Name']");
	public static By Cms_Vse_Password = By.xpath("//input[@placeholder='Password']");
	public static By Cms_Vse_Password_View = By.xpath("//input[@placeholder='Password']/following-sibling::span/descendant::span[@class='el-icon-view']");
	public static By Cms_Vse_Cancel_Button = By.xpath("//button[@role='cancelbutton'and @class='ripple-btn default']");
	public static By Cms_Vse_Save_Button = By.xpath("//button[@role='savebutton']");
}
