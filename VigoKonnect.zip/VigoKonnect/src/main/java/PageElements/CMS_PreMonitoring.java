package PageElements;

import org.openqa.selenium.By;

public class CMS_PreMonitoring {
	public static By Cms_Premonitoring_NavbarTitle= By.xpath("//span[@role='breadcrumbItem']/descendant::span[contains(text(),'Pre Monitoring')]");
	public static By Cms_Premonitoring_PageTitle= By.xpath("//h2[contains(text(),'Pre Monitoring')]");


}
