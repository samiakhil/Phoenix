package PageElements;

import org.openqa.selenium.By;

public class VKT_Login {
	//public static By VK_Username_Button = By.xpath("//android.widget.Button[contains(@text,'Username')]");
	public static By VKT_AllowNotification = By.xpath("//android.widget.Button[contains(@text,'Allow')]");

	public static By VKT_Mobile_Number_Button = By.xpath("//android.view.View[contains(@text,'Mobile Number')]");
	public static By VKT_MobileNumber_TextBox = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[1]");
	
	public static By VKT_Username_Button = By.xpath("//android.view.View[contains(@text,'Username')]");
	
	public static By VKT_Username_TextBox = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[1]");
	public static By VKT_Password_TextBox = By.xpath("(//android.widget.EditText[@package='vigo.doctor.app'])[2]");
	public static By VKT_LoginButton = By.xpath("//android.widget.Button[contains(@text,'LOG IN')]");
	
	public static By VKT_Dashboard = By.xpath("(//android.view.View[contains(@text,'Dashboard')])[1]");
	public static By VKT_AddHospitalTab = By.xpath("(//android.view.View[contains(@text,'Add Hospital')])[1]");
	public static By VKT_RegisterPatient = By.xpath("(//android.view.View[contains(@text,'Register Patient')])");
	public static By VKT_UserNotExist_Error = By.xpath("//android.view.View[contains(@text,'User d')]");
	public static By VKT_ForgetPassword = By.xpath("//android.widget.Button[contains(@text,'FORGOT PASSWORD?')]");
	public static By VKT_ContactAdminPopUp= By.xpath("//android.widget.Button[contains(@text,'OK')]");
	public static By VKT_ErrorMsg = By.xpath("//android.view.View[contains(@text,'Please')]");

	public static By VKT_UserNameError = By.xpath("//android.view.View[contains(@text,'Please enter username')]");
	public static By VKT_PasswordError = By.xpath("//android.view.View[contains(@text,'Please enter password')]");
	public static By VKT_UserDoesnotExistError = By.xpath("//android.view.View[contains(@text,'User Does')]");
	public static By VKT_IncorrectPwd = By.xpath("//android.view.View[contains(@text,'Incorrect password')]");
}
