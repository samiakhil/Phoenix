package CommonPages;

import static Reusable.Reusable.*;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import PageElements.VKT_RegisterPatient_Page;

public class CaseCreation {
	public String mobile= "";
	public String firstName = "";
	public String lastName= "";
	public String pincode = "";
	public String doctor = "";
	public String service = "";
	public String fullName ="";
	
	public CaseCreation() {
		this.mobile="414"+Random_AlphaNumeric(0,7);
		this.firstName=getTextFromProperties("VK_FNAME")+Random_AlphaNumeric(4,0);
		this.lastName="test";
		this.pincode="123456";
		this.doctor="";
		this.service="Vigo Life";
	}
	public void EmptyAllFields() {
		this.mobile="";
		this.firstName="";
		this.lastName="";
		this.pincode="";
		this.doctor="";
		this.service="";
	}
	
	
	public void FillMobileNumber() throws Exception{
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatient_MobileNumber,this.mobile);
		implicitWait(driver,1000);
		//if number registered earlier
		int ncount = driver.findElements(VKT_RegisterPatient_Page.VKT_VSE_NewPatient_Button).size();
		if(ncount!=0) {
			TakeScreenshot(driver, "Previous cases pageopened");
			Assert_TextValue(
					"The following patients in your hospital are associated with this " + this.mobile
							+ " mobile number. Please select or add a new patient",
					GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_AddNewPopupText));
			implicitWait(driver,1000);
			if(this.firstName == "" && this.lastName =="") {// if first name and old names are empty then use old case id
				//clicking on old case id
				Click_Element(driver,VKT_RegisterPatient_Page.VKT_TopPaientId);
				implicitWait(driver,1000);
				this.firstName=GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientFirstName);
				this.lastName=GetText(driver,VKT_RegisterPatient_Page.VKT_RegPatientLastName);
				implicitWait(driver,1000);
			}
			else {
				//adding new patient 
				Click_Element(driver, VKT_RegisterPatient_Page.VKT_VSE_NewPatient_Button);
				implicitWait(driver,1000);
				int monitoringCount=driver.findElements(VKT_RegisterPatient_Page.VKT_AlreadyMonitiring_MessageDialogBox_OkButton).size();
				if(monitoringCount!=0) {// monitoring with existing mobile
					implicitWait(driver,2000);
					TakeScreenshot(driver, "Already Monitiring dialogbox");
					Assert_TextValue("There is a monitoring already going on with this mobile number, please use a different mobile number",
							GetText(driver,VKT_RegisterPatient_Page.VKT_Patient_PopUp));
					Click_Element(driver, VKT_RegisterPatient_Page.VKT_AlreadyMonitiring_MessageDialogBox_OkButton);
					implicitWait(driver,1000);
					if(driver.findElements(VKT_RegisterPatient_Page.VKT_VSE_NewPatient_Button).size()!=0) {
						vertical_scroll_down(driver);
						vertical_scroll_down(driver);
					}
					implicitWait(driver,500);
				}
			}
		}
		implicitWait(driver,2000);
	}
	
	public void SelectDoctor() throws Exception{
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientTreatingDoctor);
		implicitWait(driver,1000);
		int dcount = driver.findElements(VKT_RegisterPatient_Page.VKT_1stDoctor_List).size();
		if(this.doctor!="" && dcount!=0) {
			EnterText(driver,VKT_RegisterPatient_Page.VKT_RegPatient_SearchDoctor,this.doctor);
			Click_Element(driver,VKT_RegisterPatient_Page.VKT_1stDoctor_List);
		}
		else {//when no doctors available or not to select any doctor
			vertical_scroll_down(driver);
    		Click_Element(driver,VKT_RegisterPatient_Page.VKT_PatientReg_View);
		}
		implicitWait(driver,1000);
	}
	public void SelectService() throws Exception{
		int scount=driver.findElements(VKT_RegisterPatient_Page.VKT_RegPatientSelectService).size();
		if(this.service!="" && scount!=0) {
			Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSelectService);
			implicitWait(driver,1000);
			Click_Element(driver,VKT_RegisterPatient_Page.VKT_SelectVigoLife);
			implicitWait(driver,2000);
		}
		else {
			//if()
		}
	}
	
	
	//Fill complete form
	public void FillCaseCreationForm() throws Exception{
		FillMobileNumber();
		implicitWait(driver,1000);
		
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatientFirstName,this.firstName);
		implicitWait(driver,1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatientLastName,this.lastName);
		implicitWait(driver,1000);
		EnterText(driver, VKT_RegisterPatient_Page.VKT_RegPatientPincode,this.pincode);
		implicitWait(driver,1000);
		
		SelectDoctor();
		SelectService();
		this.fullName = this.firstName+ " " + this.lastName;
	}
}
