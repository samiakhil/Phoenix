package CommonPages;

import PageElements.VKT_AddDoctor;
import TestScripts.BASE;

public class AddDoctors extends  BASE{
	public String firstName="";
	public String lastName="";
	public String displayName="";
	public String email="";
	public String mobileNumber="";
	public String MCINumber="";
	public String speciality="";
	public String type="";
	public String fullName = "";
	public String doctorId="";
	public boolean isVSE=true;	//for VSP admin and associate
	
	public AddDoctors(boolean isVSE) {
		//String rnValue=Random_AlphaNumeric(0,4);
		this.isVSE=isVSE;
		firstName=isVSE?"apiVSEDoctor":"apiVSPDoctor";
		//firstName =firstName;// + rnValue;
		lastName="test";
		displayName="api doctor";//+ rnValue;
		mobileNumber="414"+Random_AlphaNumeric(0,7);
		speciality="Cardiology";
		type="EXTERNAL";
	}
	
	public void emptyAllFields() {
		firstName="";
		lastName="";
		displayName="";
		mobileNumber="";
		speciality="";
		type="";
	}
	
	public AddDoctors formFill() throws Exception{
		TakeScreenshot(driver,"VKT_AddDoctorFormBefore");
		EnterText(driver,VKT_AddDoctor.VKT_DocFirstName,firstName);
		EnterText(driver,VKT_AddDoctor.VKT_DocLastName,lastName);
		EnterText(driver,VKT_AddDoctor.VKT_DocDisplayName,displayName);
		EnterText(driver,VKT_AddDoctor.VKT_DocEmail,email);
		EnterText(driver,VKT_AddDoctor.VKT_DocMobileNumber,mobileNumber);
		implicitWait(driver,7500);
		EnterText(driver,VKT_AddDoctor.VKT_DocMICNumber,MCINumber);
		vertical_scroll_up(driver);
		
		if(this.speciality!="") {
			Click_Element(driver,VKT_AddDoctor.VKT_DocSpeciality);
			Click_Element(driver,VKT_AddDoctor.VKT_DocSpecialityType(speciality));
		}

		if(!isVSE && type!="") {// for VSP Admin and Associate
			Click_Element(driver,VKT_AddDoctor.VKT_DocType);
			Click_Element(driver,VKT_AddDoctor.VKT_DocType(type));
			implicitWait(driver,500);
		}
		vertical_scroll_up(driver);
		TakeScreenshot(driver,"VKT_AddDoctorFormAfter");
		return this;
	}
	
	public void assignOptionalFields() {
		email="apitest@vigocare.com";
		MCINumber=Random_AlphaNumeric(0,10);
	}
	
	public void addDoctorSubmit() throws Exception {
		Click_Element(driver,VKT_AddDoctor.VKT_DocSubmit);
		implicitWait(driver,1000);
		Assert_TextValue("The Profile has been successfully created.",
				GetText(driver,VKT_AddDoctor.VKT_SuccessMsg));
		doctorId = GetText(driver,VKT_AddDoctor.VKT_ReferenceId);
		TakeScreenshot(driver,"VKT_AddDoctorSuccessPage");
		Click_Element(driver,VKT_AddDoctor.VKT_DoneButton);
		implicitWait(driver,1000);
		
		fullName = firstName+ " " + lastName;
		doctorId = doctorId.substring(doctorId.indexOf("VD"));
		System.out.println("Doctor id :\t"+doctorId);
	}
	
	public AddDoctors createDoctor() throws Exception {
		this.assignOptionalFields();
		this.formFill();
		this.addDoctorSubmit();
		return this;
	}
	public static void assertDoctorData(AddDoctors obj) throws Exception{
		String type=(obj.type).toLowerCase();
		type=type.substring(0, 1).toUpperCase() + type.substring(1);
		String doctorWithId = "Dr. "+obj.fullName+" "+type+", "+obj.doctorId;
		Assert_TextValue(doctorWithId,GetText(driver,VKT_AddDoctor.getXpathForDoctorFromList(obj.fullName)));
		Click_Element(driver,VKT_AddDoctor.getXpathForDoctorFromList(obj.fullName));
		implicitWait(driver,7000);
		
		Assert_TextValue("EDIT DOCTOR",
				GetText(driver,VKT_AddDoctor.VKT_DocEditPageTitle));
		Assert_TextValue(obj.firstName,
				GetText(driver,VKT_AddDoctor.VKT_DocFirstName));
		Assert_TextValue(obj.lastName,
				GetText(driver,VKT_AddDoctor.VKT_DocLastName));
		Assert_TextValue(obj.displayName,
				GetText(driver,VKT_AddDoctor.VKT_DocDisplayName));
		Assert_TextValue(obj.email,
				GetText(driver,VKT_AddDoctor.VKT_DocEmail));
		Assert_TextValue(obj.mobileNumber,
				GetText(driver,VKT_AddDoctor.VKT_DocMobileNumber));
		Assert_TextValue(obj.MCINumber,
				GetText(driver,VKT_AddDoctor.VKT_DocMICNumber));
		vertical_scroll_up(driver);
		System.out.println("Scrolled");
		vertical_scroll_up(driver);
		Assert_TextValue(obj.speciality,
				GetText(driver,VKT_AddDoctor.VKT_DocSpeciality));
		if(!obj.isVSE) {
			implicitWait(driver,1000);
			Assert_TextValue(obj.type,
					GetText(driver,VKT_AddDoctor.VKT_DocType));
		}
		
	}
	
}