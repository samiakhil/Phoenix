package CommonPages;

import PageElements.VKT_AddAssociates;
import PageElements.VKT_SideMenu;
import TestScripts.BASE;

public class AddUserAgents extends BASE{
	public String firstName="api";
	public String lastName="";
	public String mobileNumber="";
	public String email="";
	public String userName="";
	public String password="";
	public String confirmPassword="";
	public boolean isAdmin=true;
	public String role="";
	public boolean isVSE=true;
	
	public AddUserAgents(boolean isVSE,boolean isAdmin){
		String random6Dig=Random_AlphaNumeric(0,6);
		this.isAdmin=isAdmin;
		this.isVSE=isVSE;
		if(isVSE) {
			this.firstName+="VSE";
			this.userName+="VSE";
		}
		else {
			this.firstName+="VSp";
			this.userName+="VSp";
		}
		if(isAdmin) {
			this.firstName+="Admin";
			this.userName+="Admin"+random6Dig;
			this.role="ADMIN";
		}
		else {
			this.firstName+="Associate";
			this.userName+="Associate"+random6Dig;
			this.role="ASSOCIATE";
		}
		this.password="changeme";
		this.confirmPassword="changeme";
	
	}
	public void emptyAllFields() {
		this.firstName="";
		this.lastName="";
		this.mobileNumber="";
		this.email="";
		this.userName="";
		this.password="";
		this.confirmPassword="";
		//this.admin=false;
	}
	public AddUserAgents Formfill() throws Exception{
		EnterText(driver,VKT_AddAssociates.VKT_firstName,this.firstName);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_lastName,this.lastName);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_mobileNumber,this.mobileNumber);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_email,this.email);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_userName,this.userName);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_password,this.password);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_confirmPassword,this.confirmPassword);
		implicitWait(driver,500);
		vertical_scroll_up(driver);
		if(this.isAdmin) {
			Thread.sleep(1000);
			Click_Element(driver,VKT_AddAssociates.VKT_giveAdminRights);
			implicitWait(driver,500);
		}
		
		return this;
	}
	
	public void FillOptionalFields() throws Exception{
		this.lastName= "test";
		this.mobileNumber="414"+ Random_AlphaNumeric(0,7);
		this.email = "test@gmail.com";
	}
	public void AddAssociate_SuccessPage() throws Exception{
		Click_Element(driver,VKT_AddAssociates.VKT_submit);
		implicitWait(driver,1000);
		Assert_TextValue("The Profile has been successfully created.",
				GetText(driver,VKT_AddAssociates.VKT_SuccessMsg));
		String AssId=GetText(driver,VKT_AddAssociates.VKT_AssociateReference);
		System.out.println(AssId);
		TakeScreenshot(driver,"VKT_AddAssociateSuccessPage");
		Click_Element(driver,VKT_AddAssociates.VKT_DoneButton);
		implicitWait(driver,1000);
	}
	
	public AddUserAgents createUserAgent() throws Exception {
		this.FillOptionalFields();
		this.Formfill();
		this.AddAssociate_SuccessPage();
		return this;
	}
	
	public static void verifyUserAgent(AddUserAgents data) throws Exception {
		clickOnHamburger();
		implicitWait(driver,500);
		Click_Element(driver,VKT_SideMenu.VKT_Associates);
		TakeScreenshot(driver,"VKT_AssociatesList");
		scrollToElement(VKT_AddAssociates.userAgent(data.firstName));
		Click_Element(driver,VKT_AddAssociates.userAgent(data.firstName));
		TakeScreenshot(driver,"VKT_AssociatesDetails");
		Thread.sleep(2000);
		try {
			Assert_TextValue(data.firstName,
					GetText(driver,VKT_AddAssociates.VKT_firstName));
			Assert_TextValue(data.lastName,
					GetText(driver,VKT_AddAssociates.VKT_lastName));
			Assert_TextValue(data.mobileNumber,
					GetText(driver,VKT_AddAssociates.VKT_mobileNumber));
			Assert_TextValue(data.email,
					GetText(driver,VKT_AddAssociates.VKT_email));
			Assert_TextValue(data.userName,
					GetText(driver,VKT_AddAssociates.VKT_userName));
			Assert_TextValue(data.role,
					GetText(driver,VKT_AddAssociates.VKT_RoleEdit));
		}
		catch(Exception e) {
			throw new Exception("Details are incorrect for user agents");
		}
		System.out.println("user agent exist with provided details");
	}
	public static void editUserAgent(AddUserAgents data) throws Exception {
		Click_Element(driver,VKT_AddAssociates.VKT_Edit);
		EnterText(driver,VKT_AddAssociates.VKT_firstName,data.firstName);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_lastName,data.lastName);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_mobileNumber,data.mobileNumber);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_email,data.email);
		implicitWait(driver,500);
		String role=GetText(driver,VKT_AddAssociates.VKT_RoleEdit);
		EnterText(driver,VKT_AddAssociates.VKT_PasswordEdit,data.password);
		implicitWait(driver,500);
		EnterText(driver,VKT_AddAssociates.VKT_ConfirmPasswordEdit,data.confirmPassword);
		implicitWait(driver,500);
		vertical_scroll_up(driver);
		if(!role.equals(data.role)) {
			Click_Element(driver,VKT_AddAssociates.VKT_giveAdminRights);
		}
		Click_Element(driver,VKT_AddAssociates.VKT_Save);
	}
}
