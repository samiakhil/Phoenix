package CommonPages;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import static PageElements.VKT_AddHospital.*;
import static io.restassured.RestAssured.given;

import org.apache.http.HttpStatus;
import org.json.JSONArray;
import org.json.JSONObject;
import org.openqa.selenium.By;

import PageElements.VKT_AddHospital;
import TestScripts.BASE;

public class Hospital extends BASE{
	public String hospitalName="";
	public String website="";
	public String reportPassword="";
	public String address1="";
	public String address2="";
	public String pincode="";
	public String[] services= new String[5];
	public String firstName="";
	public String lastName="";
	public String email="";
	public String[] role= new String[4];
	public String mobile="";
	public String userName="";

	public Hospital(){
		String random6Dig=Random_AlphaNumeric(0,6);
		this.address1="ad1";
		this.pincode="123456";
		this.email="appiumTest@vigocare.com";
		this.firstName="apiVSP"+random6Dig;
		this.mobile="414"+Random_AlphaNumeric(0,7);
		this.hospitalName="apiVSP"+random6Dig;
		this.services[0]="Vigo Life";
		this.role[0]="Accounts";
		this.userName="apiVSPAdmin"+Random_AlphaNumeric(0,6);
	}


	public Hospital EmptyInput() {
		this.address1="";
		this.address2="";
		this.pincode="";
		this.email="";
		this.firstName="";
		this.lastName="";
		this.mobile="";
		this.hospitalName="";
		this.services[0]="";
		this.role[0]="";
		this.userName="";
		this.website="";
		this.reportPassword="";
		return this;
	}

	public Hospital hospitalFormFill() throws Exception {
		TakeScreenshot(driver,"VKT_AddHospitalFormPage1Before");
		EnterText(driver,VKT_HospitalName,this.hospitalName);
		System.out.println(this.hospitalName);
		EnterText(driver,VKT_WebsiteUrl,this.website);
		EnterText(driver,VKT_ReportPassword,this.reportPassword);
		EnterText(driver,VKT_AddressLane1,this.address1);
		EnterText(driver,VKT_AddressLane2,this.address2);
		EnterText(driver,VKT_Pincode,this.pincode);
		Thread.sleep(1000);
		Click_Element(driver,VKT_ServicesSubscibe);
		Thread.sleep(2000);
		if(this.services[0]!="")
			Click_Element(driver,VKT_VigoLife);
		Click_Element(driver,VKT_Page_View);
		implicitWait(driver,1000);
		TakeScreenshot(driver,"VKT_AddHospitalFormPage1After");
		VKT_NextPage();
		Thread.sleep(1500);
		TakeScreenshot(driver,"VKT_AddHospitalFormPage2Before");
		EnterText(driver,VKT_FirstName,this.firstName);
		EnterText(driver,VKT_LastName,this.lastName);
		EnterText(driver,VKT_Email,this.email);
		Click_Element(driver,VKT_Role);
		implicitWait(driver,1000);
		if(this.role[0]!="")
			Click_Element(driver,VKT_Accounts);
		Click_Element(driver,VKT_Page_View);
		implicitWait(driver,1000);
		EnterText(driver,VKT_MobileNumber,this.mobile);
		EnterText(driver,VKT_UserName,this.userName);
		TakeScreenshot(driver,"VKT_AddHospitalFormPage2After");
		return this;
	}

	public Hospital addHospital() throws Exception {
		Click_Element(driver,VKT_AddHospitalTab);
		implicitWait(driver, 2000);
		this.hospitalFormFill();
		Click_Element(driver,VKT_AddHospital.VKT_SUBMIT_Button);
		return this;
	}

	public String[] getId(String accessToken) {
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.get("https://api.mvm2.qa.vigocare.com/v1/admin/userAgents/?query="+this.userName)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject resObj=new JSONObject(getResponse.getBody().asString());
		JSONArray resArray=resObj.getJSONArray("users");
		resObj = resArray.getJSONObject(0);
		String agentId= resObj.getString("id");	
		System.out.println("id of temp vsp admin is captured");
		resArray=resObj.getJSONArray("businessPartners");
		resObj=resArray.getJSONObject(0);
		String hospId =resObj.getString("businessPartnerId");
		System.out.println("id of temp vsp is captured");
		return new String[]{agentId,hospId};
	}

	public void setPassword(String id) {
		String reqbody="{\"password\":\"changeme\","
				+ "\"confirmpassword\":\"changeme\"}";
		Response getResponse=given()
				.contentType(ContentType.JSON).accept(ContentType.JSON).
				body(reqbody)
				.when()
				.header("Authorization","Bearer "+accessToken)
				.patch("https://api.mvm2.qa.vigocare.com/v1/admin/userAgents/"+id)
				.then()
				.statusCode(HttpStatus.SC_OK)
				.extract()
				.response();
		JSONObject resObj=new JSONObject(getResponse.getBody().asString());
		System.out.println("changed password for the tem vsp admin");
	}
	
	public void assertHospitalData(Hospital obj,String ver) throws Exception{
		Assert_TextValue(obj.hospitalName,
				GetText(driver,getXpathForAssertValues(1)));
		Assert_TextValue(" - "+obj.mobile,
				GetText(driver,getXpathForAssertValues(3)));
		Assert_TextValue("Email Id :" + ( obj.email != "" ? " "+obj.email : "" ),
				GetText(driver,getXpathForAssertValues(4)));
		Assert_TextValue(ver,
				GetText(driver,getXpathForAssertValues(6)));
		
		TakeScreenshot(driver,"VKT_HospitalBriefData");
		Click_Element(driver,getXpathForAssertValues(1));
		
		//Individual Data after clicking on the Hospital name
		String allServices="";
		for(String s:obj.services) {
			if(s!=null) {
				allServices=allServices+s+", ";
			}
		}
		int lastElementIndex =  allServices.length()-2;
		String tempServices=allServices.substring(0,lastElementIndex);
		System.out.println(tempServices);
		implicitWait(driver,1000);
		Assert_TextValue(obj.hospitalName,
				GetText(driver,VKT_HospitalName));
		Assert_TextValue(obj.website,
				GetText(driver,VKT_WebsiteUrl));
		Assert_TextValue(obj.reportPassword,
				GetText(driver,VKT_ReportPassword));
		Assert_TextValue(obj.address1,
				GetText(driver,VKT_AddressLane1));
		Assert_TextValue(obj.address2,
				GetText(driver,VKT_AddressLane2));
		Assert_TextValue(obj.pincode,
				GetText(driver,VKT_Pincode));
		//service
		Assert_TextValue(tempServices,
				GetText(driver,By.xpath("(//android.widget.EditText)[7]")));
		
		VKT_NextPage();
		Thread.sleep(1500);

		Assert_TextValue(obj.firstName,
				GetText(driver,VKT_FirstName));
		Assert_TextValue(obj.lastName,
				GetText(driver,VKT_LastName));
		Assert_TextValue(obj.email,
				GetText(driver,VKT_Email));

		//Role
		Assert_TextValue(obj.role[0],
				GetText(driver,By.xpath("(//android.widget.EditText)[4]")));
		Assert_TextValue(obj.mobile,
				GetText(driver,By.xpath("(//android.widget.EditText)[6]")));

	}
}
