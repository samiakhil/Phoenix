package Reusable;

import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.google.common.io.Files;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageElements.CMS_Agents;
import PageElements.CMS_BusinessPartner;
import PageElements.CMS_Common_PageElements;
import PageElements.CMS_Login;
import PageElements.CMS_Nurse_Form;
import PageElements.CMS_VSE_EditPage;

import PageElements.CMS_Navbar;

import PageElements.VKT_SideMenu;
import PageElements.VKT_DashboardPage;

import PageElements.VKT_LogoutPage;
import PageElements.VKT_RegisterPatient_Page;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;
import io.github.bonigarcia.wdm.WebDriverManager;

import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import java.io.*;
import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class Reusable extends CMS_Login {
	protected static WebDriver dr;
	public static AndroidDriver driver;
	public static FileInputStream fis;
	public static Properties prop;
	private static String str;
	
	// launching Vigokonnect application
	public static void LaunchApp() throws MalformedURLException, Exception {
		Thread.sleep(3000);
		UiAutomator2Options option = new UiAutomator2Options();
		option.setDeviceName("vigo");
		option.setPlatformName("Android");
		String projectPath = System.getProperty("user.dir");
		System.out.println("Working Directory = " + projectPath);

		option.setApp(projectPath+"/VKT_App/VigoKonnect-qa-v4.9.4-debug.apk");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/"), option);
		Thread.sleep(3000);
		
		//			Click_Element(driver,VK_AllowNotification);
		//			Thread.sleep(2000);
		//			pageLoadTimeOut(driver, 10);
	}




	//vertical scroll up 
	public static void vertical_scroll_up(AndroidDriver driver) throws Exception{
		TouchAction action = new TouchAction(driver);
		Dimension size = driver.manage().window().getSize();
		int width = size.getWidth();
		int height = size.getHeight();
		int middleOfX = width/2;
		int startYCoordinate= (int)(height*.7);
		int endYCoordinate= (int)(height*.2);

		action.press(PointOption.point(middleOfX, startYCoordinate))
		.waitAction(WaitOptions.waitOptions(Duration.ofSeconds(2)))
		.moveTo(PointOption.point(middleOfX, endYCoordinate)).release().perform();

	}


	//Load properties file
	public static void readpropertiesdata() throws Exception {
		fis = new FileInputStream("./Properties/Config.properties");
		prop = new Properties();
		prop.load(fis);
	}

	// CMS opening and login
	public static void openCMS_WEB() throws Exception {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options = new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		dr = new ChromeDriver(options);
		dr.get(prop.getProperty("CMSURl"));
		dr.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		dr.manage().window().maximize();
		Thread.sleep(5000);
		dr.findElement(Cms_Username).sendKeys(prop.getProperty("CMSUID"));
		dr.findElement(Cms_Password).sendKeys(prop.getProperty("CMSPWD"));
		dr.findElement(Cms_Savelives_Checkbox).click();
		dr.findElement(Cms_Signin_Button).click();
		Thread.sleep(5000);
		String Cms_HomePage_Title = dr.getTitle();
		System.out.println(Cms_HomePage_Title);
		Assert_TextValue(Cms_HomePage_Title, prop.getProperty("CMSHOMEPAGE_TITLE"));
		TakeScreenshot(dr, "CMSHomeScreen");	
	}

	// clicking any element
	public static String Click_Element(WebDriver driver, By element) throws Exception {
		isDisplayed(driver,element);
		String eleText=GetText(driver,element);
		driver.findElement(element).click(); 
		return eleText;
	}

	// Entering any data into the element
	public static void EnterData(WebDriver driver, By element, String text) throws Exception {
		isDisplayed(driver,element);
		WebElement ele = driver.findElement(element);
		ele.clear();
		ele.sendKeys(prop.getProperty(text));
		String s = prop.getProperty(text);
		System.out.println(s);
	}

	// selecting option from dropdown based on index number.

	public static void Select_FromDropdown_UsingIndex(WebDriver driver, By element, int index) {
		Select s = new Select(driver.findElement(element));
		s.selectByIndex(index);
	}

	//select an option from dropdown using search text
	public static void Select_FromDropdown_UsingSearchText(WebDriver driver,By drpDown,By element,String searchText) throws Exception {
		Click_Element(dr,drpDown);
		Thread.sleep(2000);
		List<WebElement> options = driver.findElements(element);
		for (WebElement option : options) {
			if (option.getText().contains(searchText)) {
				System.out.print(option);
				option.click();
				break;
			}
		}
	}

	//selecting an option from dropdown using search text when dropdown has search option
	public static void Select_FromDropdown_UsingSearchText(WebDriver driver,By drpDown,String searchText) throws Exception {
		Click_Element(dr,drpDown);
		EnterText(dr,drpDown,searchText);
		Click_Element(dr,By.xpath("//span[contains(text(),'"+searchText+"')]"));
	}

	//selecting multiple options from dropDown
	public static void Select_Multiple_FromDropDown(WebDriver driver,By drpDown,By textArea,String[] options) throws Exception {
		Click_Element(dr,drpDown);
		for(int i=0;i<options.length;i++) {
			EnterText_NoClear(dr,textArea,options[i]);
			Click_Element(dr,By.xpath("//span[contains(text(),'BBPBSPO2')]/ancestor::ul/descendant::span[contains(text(),'"+options[i]+"')]"));
			Thread.sleep(1000);
		}
	}
	// Asserting the textvalue using equals method
	public static void Assert_TextValue(String Expected, String Actual) {
		Assert.assertEquals(Actual, Expected);
		System.out.println("values are matching, The value:\t"+Expected);
	}

	// implicit wait
	@SuppressWarnings("deprecation")
	public static void implicitWait(WebDriver driver, int timeOut) {
		driver.manage().timeouts().implicitlyWait(timeOut, TimeUnit.MILLISECONDS);;
	}

	public static void openNCloseNotifications(AndroidDriver driver) throws Exception {
		driver.openNotifications();
        System.out.println("Opened Notification");
        Thread.sleep(1000);
        vertical_scroll_up(driver);
        Thread.sleep(1000);
        System.out.println("Closed Notification");;
	}
	// pageload wait
	public static void pageLoadTimeOut(WebDriver driver, int timeOut) {
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(timeOut));
	}

	// Screenshot
	public static void TakeScreenshot(WebDriver driver, String screenshotname) throws Exception {
		TakesScreenshot ts = (TakesScreenshot) driver;
		File src = ts.getScreenshotAs(OutputType.FILE);
		Files.copy(src, new File("./Screenshots/Script Screenshots/" + screenshotname + ".jpg"));
	}

	//
	public static void MethodScreenshot(String screenshotname) throws Exception {
		TakesScreenshot ts;
		if(driver!=null && !driver.toString().contains("(null)")){
			System.out.println("MS driver value:\t"+driver);
			ts = (TakesScreenshot) driver;
			File src = ts.getScreenshotAs(OutputType.FILE);
			Files.copy(src, new File("./Screenshots/Failed Testcases/" + screenshotname+".jpg"));
		}
		if(dr!=null && !dr.toString().contains("(null)")){
			System.out.println("MS dr value:\t"+dr);
			ts = (TakesScreenshot) dr;
			File src = ts.getScreenshotAs(OutputType.FILE);
			Files.copy(src, new File("./Screenshots/Failed Testcases/" + screenshotname+".jpg"));
		}
		
		
	}
	// Accepting an alert
	public static void Alert_Accept(WebDriver driver) {
		driver.switchTo().alert().accept();
	}
	//generating ramdom string containing chars and numbers
	public static String Random_AlphaNumeric(int alphaSize,int numSize) {
		String randomString = RandomStringUtils.random(alphaSize, true, false);
		String randomNumber="";
		if(numSize!=0)
			randomNumber= Long.toString((long) Math.floor(Math.random()*9*Math.pow(10, numSize-1))+ (long)Math.pow(10, numSize-1));
		return randomString+randomNumber;
	}
	public static String EnterRandomData(WebDriver driver, By element, String propName,String suffix,int alphaSize,int numSize) throws Exception {
		isDisplayed(driver,element);
		WebElement ele = driver.findElement(element);
		ele.clear();
		String str="";
		if(prop.getProperty(propName)==null)
			str = Random_AlphaNumeric(alphaSize,numSize)+suffix;
		else
			str=prop.getProperty(propName)+Random_AlphaNumeric(alphaSize,numSize)+suffix;
		ele.sendKeys(str);
		System.out.println(str);
		return str;
	}
	public static String GetText(WebDriver driver, By element){
		String ele = driver.findElement(element).getText();
		return ele;	
	}
	public static void EnterText(WebDriver driver,By element,String text) throws Exception {
		isDisplayed(driver,element);
		WebElement ele=driver.findElement(element);
		ele.clear();
		ele.sendKeys(text);
	}
	public static void EnterText_NoClear(WebDriver driver,By element,String text) throws Exception {
		isDisplayed(driver,element);
		WebElement ele=driver.findElement(element);
		ele.sendKeys(text);
	}
	public static boolean isSelected(WebDriver driver,By element) {
		boolean selected = driver.findElement(element).isSelected();
		if(!selected) {
			System.out.println("The element is not selected\t:"+element);
		}
		return selected;
	}
	public static void isDisplayed(WebDriver driver,By element) throws Exception {
		boolean displayed = driver.findElement(element).isDisplayed();
		if (!displayed){
			System.out.println("Unable to detect the element\t:"+element);
		}
	}

	//vertical scroll down 
	public static void vertical_scroll_down(AndroidDriver driver) throws Exception{
		TouchAction ts = new TouchAction(driver);
		ts.press(PointOption.point(536,796)).moveTo(PointOption.point(536, 1536)).release().perform();

	}
	//return text value from properties using property name
	public static String getTextFromProperties(String text) {
		return prop.getProperty(text);
	}
	
	
	public static boolean isEndOfPage(String pageSource){
		return pageSource.equals(driver.getPageSource());
	}

	
	public static void scrollToElement(By ele) throws Exception {
		String pageSource = "";
		boolean flag=false;
		while(!isEndOfPage(pageSource)) {
			Thread.sleep(1000);
			pageSource=driver.getPageSource();
			try {
				driver.findElement(ele).isDisplayed();
				System.out.println("found the element \t:"+ele);
				flag=true;
				break;
			}
			catch(NoSuchElementException e) {
				vertical_scroll_up(driver);
			}
		}
		if(!flag) {
			throw new Exception("Not found the element");
		}
	}
}

