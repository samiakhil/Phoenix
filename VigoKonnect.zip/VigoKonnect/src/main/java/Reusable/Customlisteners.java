package Reusable;

import java.net.MalformedURLException;

import org.testng.IRetryAnalyzer;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class Customlisteners extends Reusable implements ITestListener,IRetryAnalyzer {
	public static ExtentSparkReporter sparkreporter;
	public static ExtentReports reports;
	public static ExtentTest extenttest;
	
	private int retryCount= 0;
	private static final int maxRetryCount= 2;

	public void reportconfig () {
		sparkreporter=new ExtentSparkReporter("./TestReports/Report.html");
		reports = new ExtentReports();
		reports.attachReporter(sparkreporter);

		//system info//
		reports.setSystemInfo("OS:","Ubuntu 22.10");
		reports.setSystemInfo("App:","Vigo Konnect");
		reports.setSystemInfo("Platform:","Android");
		reports.setSystemInfo("Version:","4.9.2");
		reports.setSystemInfo("Reporters:","Prashanth & Sai Krishna");

		//Look Config//
		sparkreporter.config().setDocumentTitle("Vigo Test Automation Report");
		sparkreporter.config().setReportName("VigoKonnect Tests");
		//sparkreporter.config().setTheme(Theme.DARK);
	}

	@SuppressWarnings("deprecation")
	@Override
	public void onTestFailure(ITestResult result) {
		// TODO Auto-generated method stub
		System.out.println("Failed: The method name is: \t"+result.getName());
		extenttest=reports.createTest(result.getName());
		extenttest.log(Status.FAIL, MarkupHelper.createLabel("Test is failed at this method:"+result.getName(),ExtentColor.RED));
		extenttest.fail(result.getThrowable());
		String projectpath = System.getProperty("user.dir");
		System.out.println("Working Directory = " + projectpath);
		//extenttest.addScreenCaptureFromPath(projectpath+"/Screenshots/Failed Testcases/"+result.getName()+".jpg");
		try {
			MethodScreenshot(result.getName());
			extenttest.addScreenCaptureFromPath(projectpath+"/Screenshots/Failed Testcases/"+result.getName()+".jpg");
			Thread.sleep(1000);
			if(driver!=null && !driver.toString().contains("(null)")) {
				//CommonMethods.Logout_VigoKonnect();
				driver.resetApp();
				Thread.sleep(5000);
			}
			if(dr!=null && !dr.toString().contains("(null)")) {
				CommonMethods.CMS_Logout();		
			}
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub
		extenttest=reports.createTest(result.getName());
		extenttest.log(Status.PASS, MarkupHelper.createLabel("Test is successful:"+result.getName(),ExtentColor.GREEN));
	}

	@Override
	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		extenttest=reports.createTest(result.getName());
		extenttest.log(Status.SKIP, MarkupHelper.createLabel("Test is skipped at this method:"+result.getName(),ExtentColor.WHITE));
	}

	@Override
	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		reportconfig();
	}

	@Override
	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		reports.flush();
	}
	
	@Override
	public boolean retry(ITestResult result){
		// TODO Auto-generated method stub
		if(retryCount<maxRetryCount) {
			try {
				if(driver!=null && !driver.toString().contains("(null)")) {
					driver.resetApp();
					Thread.sleep(3000);
				}
				if(dr!=null && !dr.toString().contains("(null)")) {
					//CommonMethods.CMS_Logout();
					System.out.println("dr value:\t"+dr);
					dr.quit();
					dr=null;
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			retryCount++;
			return true;
		}
		return false;
	}
}
