package Reusable;
import CommonPages.AddDoctors;
import CommonPages.CaseCreation;


import static PageElements.VKT_AddHospital.VKT_Next_Button;

import static Reusable.Reusable.*;
import static io.restassured.RestAssured.given;

import java.time.Duration;

import org.apache.http.HttpStatus;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebElement;

import PageElements.CMS_Agents;
import PageElements.CMS_BusinessPartner;
import PageElements.CMS_Common_PageElements;
import PageElements.CMS_Dashboard;
import PageElements.CMS_Navbar;
import PageElements.CMS_PreMonitoring;
import PageElements.VKT_Account;
import PageElements.VKT_AddAssociates;
import PageElements.VKT_AddDoctor;
import PageElements.VKT_AddHospital;
import PageElements.VKT_SideMenu;
import PageElements.VKT_DashboardPage;

import PageElements.VKT_LogoutPage;
import PageElements.VKT_PatientDetails;
import PageElements.VKT_PatientsOpen;
import PageElements.VKT_RegisterPatient_Page;
import PageElements.VKT_Service_Pages;
import PageElements.VKT_UpdatePassword;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class CommonMethods extends Reusable {
	// Log in to VigoKonnect app using username and password
	public static void Login_VigoKonnect_Username(String uName,String password) throws Exception{
		implicitWait(driver,1000);
		Click_Element(driver, VKT_Username_Button);
		isSelected(driver,VKT_Username_Button);
		Thread.sleep(1000);
		EnterText(driver,VKT_Username_TextBox,uName);
		EnterText(driver, VKT_Password_TextBox, password);
		TakeScreenshot(driver, "VigoKonnectLoginScreen");
		Click_Element(driver, VKT_LoginButton);
		Thread.sleep(7000);
		try {
			if(driver.findElement(VKT_UpdatePassword.VKT_ChangePwdTitle).isDisplayed()) {
				EnterData(driver, VKT_UpdatePassword.VKT_NewPassword, "VKPWD");
				EnterData(driver, VKT_UpdatePassword.VKT_ConfirmPassword, "VKPWD");
				Click_Element(driver, VKT_UpdatePassword.VKT_UpdateButton);
				Thread.sleep(4500);
				EnterText(driver,VKT_Username_TextBox,uName);
				EnterData(driver, VKT_Password_TextBox, "VKPWD");
				TakeScreenshot(driver, "VigoKonnectLoginScreen");
				Click_Element(driver, VKT_LoginButton);
				Thread.sleep(7000);
			}
			else {
				throw new Exception("");
			}
		}
		catch(Exception e) {}
		finally {
			Assert_TextValue(uName,
					GetText(driver,By.xpath("//*[contains(@text,'"+uName+"')]")));
		}

	}
	
	// Log in to VigoKonnect app using username
	public static void Login_VigoKonnect_Username(String uName) throws Exception {
		Login_VigoKonnect_Username(uName,"changeme");
	}

	// Dashboard after login
	public static void clickOnHamburger() throws Exception {
		Thread.sleep(500);
		Click_Element(driver, VKT_DashboardPage.VKT_ASideMenu);
		Thread.sleep(500);
		TakeScreenshot(driver, "VigoKonnectDashboardPage");
	}

	// Register Patient
	public static void RegisterPatient(CaseCreation obj) throws Exception {
		Thread.sleep(2000);
		Click_Element(driver, VKT_RegisterPatient);
		Thread.sleep(1000);
		isSelected(driver,VKT_RegisterPatient);
		Assert_TextValue("REGISTER PATIENT",
				GetText(driver, VKT_RegisterPatient_Page.VKT_RegPatientTitle));
		Thread.sleep(1000);
		obj.FillCaseCreationForm();
	}
	public static void caseCreationSuccessPage() throws Exception{
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		TakeScreenshot(driver,"CaseCreationWithPatientId");
		Thread.sleep(2000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Thread.sleep(1000);
	}
	
	public static String caseCreationSuccessPageForVSP() throws Exception{
		TakeScreenshot(driver,"RegistrationPageWithDetails");
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_RegPatientSubmit);
		TakeScreenshot(driver,"CaseCreationWithPatientId");
		Thread.sleep(2000);
		System.out.println("The Patient Id is :\t" + GetText(driver, VKT_RegisterPatient_Page.VKT_Patient_ID));
		Click_Element(driver, VKT_RegisterPatient_Page.VKT_Patient_Done);
		Thread.sleep(1000);
		String caseId = GetText(driver,By.xpath("//android.view.View[contains(@text,'VC')]"));
		Click_Element(driver,By.xpath("//android.widget.Image[contains(@text,'back-icon')]"));
		Thread.sleep(1000);
		return caseId;
	}
	//get user mobile number
	public static String getDoctorMobileNumber() throws Exception{
		clickOnHamburger();
		Click_Element(driver,VKT_SideMenu.VKT_Account);
		//Assert_TextValue("","");
		String number=GetText(driver,By.xpath("//*[contains(@text,'+91')]"));
		clickOnHamburger();
		Click_Element(driver,VKT_SideMenu.VKT_DB);
		return number.substring(4);
	}

	//get case ID after creation through VSE flow
	public static String getVSEPatientCaseId(String pname) throws Exception {
		Click_Element(driver,VKT_DashboardPage.VKT_PatientOpen);
		TakeScreenshot(driver,"PatientsUnderOpen");
		Thread.sleep(1000);
		Assert_TextValue("Open Leads",
				GetText(driver,By.xpath("//*[contains(@text,'Open Leads')]")));
		EnterText(driver,VKT_PatientsOpen.VKT_SearchTextWithName,pname);
		Click_Element(driver,VKT_PatientsOpen.VKT_SearchClick);
		//driver.findElements(By.className("android.widget.Image")).get(5).click();
		Thread.sleep(2000);
		TakeScreenshot(driver,"Searched_PatientName");
		Click_Element(driver,By.xpath("(//android.view.View[contains(@text,'"+pname+"')])[1]"));
		Thread.sleep(1000);
		isDisplayed(driver,By.xpath("//*[contains(@text,'"+pname+"')]"));
		TakeScreenshot(driver,"PatientDetailsWithCaseId");
		String caseId = GetText(driver,By.xpath("//android.view.View[contains(@text,'VC')]"));
		System.out.println(caseId);
		Thread.sleep(1000);
		Click_Element(driver,By.xpath("//android.widget.Image[contains(@text,'back-icon')]"));
		Assert_TextValue("Open Leads",
				GetText(driver,By.xpath("//*[contains(@text,'Open Leads')]")));
		Thread.sleep(1000);
		Click_Element(driver,VKT_PatientsOpen.VKT_OPbacktoDB);	
		Thread.sleep(1000);
		return caseId;
	}

	//open VigoKonnect Username Login Screen
	public static void OpenVKT_UsernameLogin() throws Exception{
		implicitWait(driver,5000);
		Click_Element(driver, VKT_Username_Button);
		isSelected(driver,VKT_Username_Button);
		//implicitWait(driver,1000);
		TakeScreenshot(driver,"VKTLoginScreen");
	}

	//Logout from VigoKonnect App
	public static void Logout_VigoKonnect() throws Exception{
		clickOnHamburger();
		implicitWait(driver,500);
		Click_Element(driver,VKT_SideMenu.VKT_Logout);
		Thread.sleep(1000);
		Assert_TextValue("Are you sure you want to Logout?",
				GetText(driver,VKT_LogoutPage.VKT_LogoutPopup));
		TakeScreenshot(driver, "VigoKonnectLogoutConfirmationPage");
		Click_Element(driver,VKT_LogoutPage.VKT_LogoutConfirm);
		implicitWait(driver,500);
		TakeScreenshot(driver, "VigoKonnectAfterLogout");
	}
	public static void DB_To_AddAssociatesPage() throws Exception{
		Click_Element(driver,VKT_DashboardPage.VKT_ASideMenu);
		implicitWait(driver,1000);
		Click_Element(driver,VKT_SideMenu.VKT_Associates);
		TakeScreenshot(driver,"VKT_AssociatesList");
		Click_Element(driver,VKT_SideMenu.VKT_AddAssociateButtonImage);
	}
	public static void AssociatesPage_To_Logout() throws Exception{
		Click_Element(driver,VKT_SideMenu.VKT_MenuButton);
		Thread.sleep(1000);
		Click_Element(driver,VKT_SideMenu.VKT_Logout);
		Thread.sleep(1000);
		Assert_TextValue("Are you sure you want to Logout?",
				GetText(driver,VKT_LogoutPage.VKT_LogoutPopup));
		TakeScreenshot(driver, "VigoKonnectLogoutConfirmationPage");
		Click_Element(driver,VKT_LogoutPage.VKT_LogoutConfirm);
		implicitWait(driver,500);
		TakeScreenshot(driver, "VigoKonnectAfterLogout");
	}
	public static void DB_To_AddDoctorsPage() throws Exception{
		Click_Element(driver,VKT_DashboardPage.VKT_ASideMenu);
		Click_Element(driver,VKT_SideMenu.VKT_Doctors);
		TakeScreenshot(driver,"VKT_DoctorsList");
		Click_Element(driver,VKT_SideMenu.VKT_AddDoctorButtonImage);
		implicitWait(driver,7000);
		Assert_TextValue("ADD DOCTOR",
				GetText(driver,VKT_AddDoctor.VKT_DocPageTitle));
	}
	public static void DoctorListPage_To_Logout() throws Exception{
		Click_Element(driver,VKT_SideMenu.VKT_MenuButton);
		Thread.sleep(1000);
		Click_Element(driver,VKT_SideMenu.VKT_Logout);
		Thread.sleep(1000);
		Assert_TextValue("Are you sure you want to Logout?",
				GetText(driver,VKT_LogoutPage.VKT_LogoutPopup));
		TakeScreenshot(driver, "VigoKonnectLogoutConfirmationPage");
		Click_Element(driver,VKT_LogoutPage.VKT_LogoutConfirm);
		implicitWait(driver,500);
		TakeScreenshot(driver, "VigoKonnectAfterLogout");
	}
	// navigate to next page in VKT
	public static void VKT_NextPage() throws Exception {
		vertical_scroll_up(driver);
		implicitWait(driver, 2000);
		Click_Element(driver, VKT_Next_Button);
	}

	// navigate to previous page in VKT
	public static void VKT_PrevPage() throws Exception {
		vertical_scroll_up(driver);
		implicitWait(driver, 2000);
		Click_Element(driver, VKT_AddHospital.VKT_Previous_Button);
	}

	// verifies hospital in vigokonnect using hospital name
	public static void VKT_HospitalVerification(String hospitalName) throws Exception {
		Click_Element(driver, VKT_DashboardPage.VKT_VSE_TotalHospitals);
		implicitWait(driver, 2000);
		TakeScreenshot(driver,"VKT_TotalHospitalList");
		//EnterText(driver, VKT_PatientsOpen.VKT_SearchTextWithName, hospitalName);
		//implicitWait(driver, 1000);
		//TakeScreenshot(driver,"VKT_HospitalSearchList");
		int ele = driver.findElements(By.xpath("//android.view.View[contains(@text,'" + hospitalName + "')]"))
				.size();
		if (ele == 0)
			throw new Exception("Hospital not found");
		System.out.println("Hospital "+hospitalName + " found");
	}

	//updating account password after loggin into vigo konnect.
	public static void VKT_AccountUpdatePassword(String oldPassword,String newPassword,String confirmPassword) throws Exception {
		clickOnHamburger();
		TakeScreenshot(driver, "VKT_SideMenu");
		Click_Element(driver, VKT_SideMenu.VKT_Account);
		Assert_TextValue("ACCOUNT",
				GetText(driver,By.xpath("//*[contains(@text,'ACCOUNT')]")));
		Click_Element(driver, VKT_Account.VKT_AccountChangePassword);
		TakeScreenshot(driver, "VKT_AccountChangePasswordPage");
		Assert_TextValue("CHANGE PASSWORD", GetText(driver, VKT_Account.VKT_ChangePasswordTitle));
		EnterText(driver, VKT_Account.VKT_AccountOldPassword,oldPassword);
		EnterText(driver, VKT_Account.VKT_AccountNewPassword,newPassword);
		EnterText(driver, VKT_Account.VKT_AccountConfirmPassword,confirmPassword);
		Click_Element(driver, VKT_Account.VKT_AccountUpdate);
	}

	//verifying created doctors in vigoKonnect
	public static void vkt_DoctorVerify(AddDoctors AD) throws Exception {
		TakeScreenshot(dr,"VKT_DoctorsList");
		scrollToElement(By.xpath("//android.view.View[contains(@text,'"+AD.firstName+" "+AD.lastName+"')]"));
		Click_Element(driver,By.xpath("//android.view.View[contains(@text,'"+AD.firstName+" "+AD.lastName+"')]"));
		Assert_TextValue(AD.firstName,GetText(dr,VKT_AddDoctor.VKT_DocFirstName));
		Assert_TextValue(AD.lastName,GetText(dr,VKT_AddDoctor.VKT_DocLastName));
		Assert_TextValue(AD.displayName,GetText(dr,VKT_AddDoctor.VKT_DocDisplayName));
		Assert_TextValue(AD.email,GetText(dr,VKT_AddDoctor.VKT_DocEmail));
		Assert_TextValue(AD.mobileNumber,GetText(dr,VKT_AddDoctor.VKT_DocMobileNumber));
		Assert_TextValue(AD.MCINumber,GetText(dr,VKT_AddDoctor.VKT_DocMICNumber));
		Assert_TextValue(AD.speciality,GetText(dr,VKT_AddDoctor.VKT_DocSpeciality));
	}

	//Cms Vse Verification
	public static void Cms_Vse_Verification(String VSEName,String Vse_Phno,String CountryCode) throws Exception {
		EnterText(dr,CMS_BusinessPartner.Cms_BusinessPartner_Search,VSEName);
		Click_Element(dr,CMS_BusinessPartner.Cms_BusinessPartner_SearchButton);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_VSE_Verification");
		Assert_TextValue(VSEName,GetText(dr,By.xpath("//table/descendant::tbody/tr[1]/child::td[2]")));
		Assert_TextValue("(+"+CountryCode+") "+Vse_Phno,GetText(dr,By.xpath("//table/descendant::tbody/tr[1]/child::td[6]")));
	}
	// verifying cms agent
	public static void Cms_Agent_Verification(String fname,String lname,String email,String mobile,String role,String CountryCode) throws Exception {
		EnterText(dr,CMS_Agents.Cms_Agents_SearchBox,fname);
		Click_Element(dr,CMS_Agents.Cms_Agents_SearchButton);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_Agents_Verification");
		Assert_TextValue(fname,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[1]")));
		Assert_TextValue(lname,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[2]")));
		Assert_TextValue(email,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[3]")));
		Assert_TextValue("(+"+CountryCode+") "+mobile,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[4]")));
		Assert_TextValue(role,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[5]")));
	}
	//Verifying Nurse in CMS
	public static void Cms_Nurse_Verification(String fname,String lname,String email,String busPartner,String speciality,String mobile,String CountryCode) throws Exception {
		EnterText(dr,CMS_Common_PageElements.Cms_SearchBox,fname);
		Click_Element(dr,CMS_Common_PageElements.Cms_SearchButton);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_Nurse_Verification");
		Assert_TextValue(fname,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[1]")));
		Assert_TextValue(lname,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[2]")));
		Assert_TextValue("(+"+CountryCode+") "+mobile,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[3]")));
		Assert_TextValue(email,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[4]")));
		Assert_TextValue(busPartner,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[6]")));
		Assert_TextValue(speciality,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[7]")));		
	}
	//Verifying Business group in cms
	public static void Cms_BusinessGroup_Verification(String name) throws Exception{
		EnterText(dr,CMS_Common_PageElements.Cms_SearchBox,name);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_Nurse_Verification");
		Assert_TextValue(name,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[1]")));
	}
	// verifying vse subscription in cms
	public static void Cms_Vse_Subscribtion_verify(String vseName,String[] services) throws Exception {
		EnterText(dr,CMS_Common_PageElements.Cms_SearchBox,vseName);
		Click_Element(dr,CMS_Common_PageElements.Cms_SearchButton);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_VSE_SubscriptionVerification");
		String subscriptions= GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[4]"));
		for(int i=0;i<services.length;i++)
			if(subscriptions.contains(services[i]))
				continue;
			else
				System.out.print(services[i]+" service not been subscribed");
	}
	//verifying vsp in cms
	public static void cms_Vsp_Verification(String vspName,String vseName,String mobile,String countryCode) throws Exception {
		WebElement html = dr.findElement(By.tagName("html"));
		html.sendKeys(Keys.chord(Keys.CONTROL, "80"));
		EnterText(dr,CMS_Common_PageElements.Cms_SearchBox,vspName);
		Click_Element(dr,CMS_Common_PageElements.Cms_SearchButton);
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_VSP_Verification");
		Assert_TextValue(vspName,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[2]")));
		Assert_TextValue("VSP",GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[3]")));
		Assert_TextValue(vspName,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[2]")));
		Assert_TextValue("(+"+countryCode+") "+mobile,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[6]")));
		Assert_TextValue(vseName,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[7]")));
		html.sendKeys(Keys.chord(Keys.CONTROL, "100"));
	}
	//Deleting the ------- From cms
	public static void Delete_ClickOn_TrashBin() throws Exception {
		WebElement html = dr.findElement(By.tagName("html"));
		html.sendKeys(Keys.chord(Keys.CONTROL, "67"));
		Thread.sleep(2000);
		Click_Element(dr,CMS_Common_PageElements.Cms_Delete_Button);
		Thread.sleep(2000);
		Click_Element(dr,By.xpath("//span[contains(text(),' OK')]"));
		html.sendKeys(Keys.chord(Keys.CONTROL, "100"));
	}
	public static void caseVerfication(String caseNumber) throws Exception {
		openCMS_WEB();
		Thread.sleep(2000);
		TakeScreenshot(dr,"CMS_Cases_DrpDown");
		Click_Element(dr,CMS_Dashboard.Cms_Dashboard_PreMonitoring);
		Thread.sleep(2000);
		Assert_TextValue("Pre Monitoring",GetText(dr,CMS_PreMonitoring.Cms_Premonitoring_NavbarTitle));
		TakeScreenshot(dr,"CMS_PreMonitoring_Page");
		EnterText(dr,CMS_Common_PageElements.Cms_SearchBox,caseNumber);
		Click_Element(dr,CMS_Common_PageElements.Cms_SearchButton);
		TakeScreenshot(dr,"CMS_CaseVerification");
		Thread.sleep(1000);
		Assert_TextValue(caseNumber,GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[2]/descendant::a")));
		Assert_TextValue("Vigo Life",GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[5]")));
		Assert_TextValue("ONGOING",GetText(dr,By.xpath("//table/child::tbody/tr[1]/child::td[7]")));
		Thread.sleep(2000);
	}
	public static void caseDeletion(String caseNumber) throws Exception {
		caseVerfication(caseNumber);

		Click_Element(dr,By.xpath("//table/child::tbody/tr[1]/child::td[2]/descendant::a"));
		Thread.sleep(1000);
		Click_Element(dr,By.xpath("//div[@role='tab']/a[contains(text(),' Troubleshoot ')]"));
		Click_Element(dr,By.xpath("//span[contains(text(),'Delete Case')]"));
		Thread.sleep(1000);
		Click_Element(dr,By.xpath("//span[contains(text(),'Yes')]"));
		Thread.sleep(2000);
		int deleteCaseCount = driver.findElements(By.xpath("//span[contains(text(),'Delete Case')]")).size();
		if(deleteCaseCount==0) {
			System.out.println("Deleted Case successfully");
		}
	}
	public static void CMS_Logout() throws Exception{
		Thread.sleep(2000);
		Click_Element(dr,CMS_Navbar.Cms_Navbar_UserAvatar);
		System.out.println("Clicked on user avatar");
		Thread.sleep(2000);
		Click_Element(dr,CMS_Navbar.Cms_Navbar_Logout);
		System.out.println("Clicked on logout button");
		Thread.sleep(2000);
		Click_Element(dr,CMS_Common_PageElements.Cms_OK_Button);
		System.out.println("Clicked on OK button");
		dr.quit();
		System.out.println("closed web");
	}
}