import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Reusable_methods {

	 static WebDriver driver;

	
	@BeforeTest
	
	public static void calling() {
		
		WebDriverManager.chromedriver().setup();
		
		//driver = new ChromeDriver();
		
		driver.get("https://automationpanda.com/2021/12/29/want-to-practice-test-automation-try-these-demo-sites/");
		driver.manage().window().maximize();
		String gettitle =driver.getTitle();
		System.out.println(gettitle);
		
		
		
		
		
		
	}
	
	 
	
}
