package screenShots;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class ITestListenerClass extends BaseTest implements ITestListener {
	
	
	public void onTestFailure(ITestResult result) {
		
		//captureScreenshot(result.getTestName()+".jpg");
		captureScreenshot( result.getTestContext().getName()+"_"+ result.getMethod().getMethodName()+".jpg");
		
	}

	

}
