package FlowControls;

import java.util.Arrays;

public class Second_Task {

	public static void main(String[] args) {
		
		int[] array={ 1, 0, 1, 0, 1, 0, 0, 1};
		
		 Arrays.sort(array);
		 for(int i=0;i<array.length;i++) {
		System.out.print((+array[i]+", "));
    
		
		 }
		
	}

}
