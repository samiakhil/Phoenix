package FlowControls;

public class Task_23Th {
	
    // merge sort
	
			// TODO Auto-generated method stub
	int [] arr = 	{23, 43 ,45, 76, 78 ,90, 0, 21, 6,8, 9};
	
		public static void divided(int []arr ,int start ,int end) {
		
			int length = arr.length;
			//divide(arr,0);
		
		}	
		
		public static void main(String[] args) {

	}

}
