package FlowControls;

import java.util.Arrays;

public class Fifth_Task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[] ={ 6, 0, 8, 2, 3, 0, 4, 0, 1 };
		
	     
	      for(int i=0;i<num.length;i++) {
	    	  if(num[i]!=0) {
		    	  System.out.print(num[i]);
  
	    	  }
	      }
	      
	      for(int j=0;j<num.length;j++) {
	    	  if(num[j]==0) {
		    	  System.out.print(num[j]);
 
	    	  }
	    	  
	      }
		
	}}


