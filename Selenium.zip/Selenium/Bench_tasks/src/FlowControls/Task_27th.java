package FlowControls;

public class Task_27th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		int[] num = {1, 2, 3, 4, 5, 7, 8, 9, 10};
		
		int sum=0;
		int sum1=0;
		for(int i=0;i<num.length;i++) {
			sum=sum+num[i];
		}
		
		for(int i=0;i<=10;i++) {
			sum1=sum1+i;
		}
			System.out.println(sum1-sum);
		}


	}


