package FlowControls;

public class First_Task {

	public static void main(String[] args) {
		
		//nums = [8, 7, 2, 5, 3, 1]
		//target = 10
			
						 
//				Output:
//				 
//				Pair found (8, 2)
//				or
//				Pair found (7, 3)
//		
		int num[] = {8, 7, 2, 5, 3, 1};
		
		for(int i=0;i<num.length;i++) {
		for(int j=i;j<num.length;j++) {
			
			if(num[i]+num[j]==10) {
				System.out.println("pair found :("+num[i]+" ,"+ num[j]+")");
				
			}
			
			
			
		}
		}
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
}
