package FlowControls;

public class Task_14th {

	public static void main(String[] args) {

		int[] num = { 5, 6, 3, 4, 3, 6, 4 };
		int[] index = new int[3];
		int count = 0;
		for (int i = 0; i < num.length; i++) {
			for (int j = i + 1; j < num.length; j++) {
				if (num[i] == num[j]) {
					index[count] = i;
					count++;
				}
			}
		}
		System.out.println(index[0]);
	}
}
