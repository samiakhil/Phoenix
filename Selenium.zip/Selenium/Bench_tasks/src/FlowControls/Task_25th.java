package FlowControls;

import java.util.Arrays;

public class Task_25th {

	public static int index = 0;

	public static void main(String[] args) {

		int x[] = { 1, 4, 7, 8, 10 };
		int y[] = { 2, 3, 9 };
		int[] xy = new int[8];
		int newindex = 0;

		for (int i = 0; i < x.length; i++) {
			xy[index] = x[i];
			index++;
		}
		for (int i = 0; i < y.length; i++) {
			xy[index] = y[i];
			index++;
		}
		Arrays.sort(xy);

		for (int i = 0; i < x.length; i++) {
			x[i] = xy[i];
			
			//System.out.println(x[i]);
		}

		//newindex = 0;
		for (int j = 5; j < xy.length; j++) {
			y[newindex]=xy[j];
			newindex++;
			
		}

		for(int m:x) {
			System.out.print(m);
		}
		System.out.println("   ");
		for(int n :y) {
			System.out.print(n);
		}
	}

}
