package FlowControls;

public class Task_33Th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] num = { 2, 5, 5, 5, 6, 6, 8, 9, 9, 9 };
		int[] index = new int[3];
		int n = 0;
		int target = 5;
		for (int i = 0; i < num.length; i++) {
			if (num[i] == target) {
				index[n] = i;
				n++;
			}
		}
		System.out.println(index[0]);
		System.out.println(index[index.length - 1]);
	}

}
