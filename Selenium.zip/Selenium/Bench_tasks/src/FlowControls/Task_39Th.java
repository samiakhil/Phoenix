package FlowControls;

public class Task_39Th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {0,0,1,1,1,0,0};
		int count=0;
		for(int i=0;i<=num.length-1;i++) {
			if(num[i]==1) {
				count++;
			}
		}
		
		System.out.println(count);
		
	}

}
