package FlowControls;

public class sixth_Task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int number[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
		
		int sum=6;
		
		for(int i=0;i<number.length;i++) {
		for(int j=i;j<number.length;j++) {
		for(int k=i;k<number.length;k++) {
		for(int l=i;l<number.length;l++) {
			if(number[i]+number[j]+number[k]+number[l]==sum&&(number[i]==4&&number[j]==-1&&number[k]==2&&number[l]==1)) {
				
				System.out.println(number[i]+","+number[j]+","+number[k]+","+number[l]);
			}
		}
		}
		}
			
		}
		
		
		
		
	}

}
