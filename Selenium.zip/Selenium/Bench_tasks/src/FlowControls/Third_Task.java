package FlowControls;

public class Third_Task {

	public static void main(String[] args) {

		int[] integer = { 3, 4, 6, 8, 2, 9 };

		int max = 0;

		for (int i = 0; i < integer.length; i++) {
			for (int j = 0; j < integer.length; j++) {

				if (integer[i] * integer[j] > max) {

					max = integer[i] * integer[j];
					if (integer[i] != integer[j] && max == 72) {

						System.out.println(integer[i] + " " + integer[j]);

					}

				}

			}

		}

	}
}
