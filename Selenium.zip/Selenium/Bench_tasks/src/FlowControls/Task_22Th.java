package FlowControls;

public class Task_22Th {
     // selection sort
	public static void main(String[] args) {
	int a[]= {3,5,8,4,1,9,-2};
	int temp;
	int m;
	for(int i=0;i<a.length;i++){
		m=i;
		for(int j=i+1;j<a.length;j++){
			if(a[j]<a[m]){
				m=j;
			}
			temp=a[i];a[i]=a[m];a[m]=temp;
			}}
	System.out.print("The selection sort is:");
	for(int i=0;i<a.length;i++){
		System.out.print(a[i]+" ");
		}}}





