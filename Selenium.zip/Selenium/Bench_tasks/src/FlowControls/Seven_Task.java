package FlowControls;

import java.util.Arrays;

public class Seven_Task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int A[] = {3, 8, 6, 7, 5, 9};
		
		Arrays.sort(A);
		for(int i=0;i<A.length;i++) {
			
			System.out.print(A[i]+ ",");
		}
		
		
		
		
	}

}
