package FlowControls;

public class Task_28th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] num = { 4, 3, 6, 2, 6, 4, 2, 3, 4, 3, 3 };
		int count = 0;
		for (int i = 0; i < num.length; i++) {
			count = 0;
			for (int j = 0; j < num.length; j++) {
				if (num[i] == num[j]) {
					count++;
				}
			}
			if (count % 2 != 0) {
				System.out.println(num[i]);
				break;

			}
		}

	}

}
