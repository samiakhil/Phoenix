package FlowControls;

public class Task_35th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] num = { 2, 3, 5, 7, 9 };
		int target = 7;
		for (int i = 0; i < num.length; i++) {
			if (num[i] == target) {
				System.out.println(i);
			}

		}

	}

}
