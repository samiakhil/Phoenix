package FlowControls;

public class Task_48th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] num= {1,0,1,0,1,0,0,1};
		
		for(int i=0; i<num.length;i++) {
			if(num[i]==0) {
				System.out.print(num[i]+", ");
			}
		}
		for(int i=0;i<num.length;i++) {
			if(num[i]==1) {
				System.out.print(num[i]+" ,");
			}
		}
		
		
		
	}

}
