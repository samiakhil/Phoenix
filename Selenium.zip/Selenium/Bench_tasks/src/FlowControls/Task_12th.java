package FlowControls;

public class Task_12th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {6, -4, -3, 2, 3};
		int sum=2;
		for(int i=0;i<num.length;i++) {
		  for(int n=1;n<num.length;n++) {
			  for(int p=2;p<num.length;p++) {
			  if((num[i]+num[n]+num[p])==sum && num[i]==-3 && num[n]==2 && num[p]==3) {
				  System.out.println(+num[i]+", "+num[n]+" "+num[p]);
				   }
		  }
			
		}
		}
		for(int k=0;k<num.length;k++) {
		for(int m=0;m<num.length;m++) {
			if((num[k]+num[m]) == sum && num[k]==6 && num[m]==-4) {
			System.out.println(num[k]+ " "+num[m]);	
			}
		}
		}
		}}
