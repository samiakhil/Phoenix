package FlowControls;

import java.util.Arrays;

public class Task_13th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//{2,4,6,7,8,9};
		int[] num = { 4, 6, 2, 7, 9, 8 };
		Arrays.sort(num);
		for (int i = num.length - 1; i >= 0; i--) {
			if (i % 2 != 0) {
				System.out.print(num[i]);
			}
		}
		System.out.println();
		for (int i = num.length - 1; i >= 0; i--) {
			if (i % 2 == 0) {
				System.out.print(num[i]);
			}
		}

	}

}
