package FlowControls;

public class Task_17Th {

	public static void main(String[] args) {

		int[] a = { 1, 2, 3, 4, 5 };
		int[] b = { 6, 7, 8, 9, 10 };
		int[] c = new int[10];
		int count = 0;
		for (int i = 0; i < a.length; i++) {

			c[count] = a[i];
			count++;

		}
		for (int i = 0; i < b.length; i++) {

			c[count] = b[i];
			count++;
		}
		for (int i = 0; i < c.length; i++) {
			System.out.print(c[i]);
		}
	}

}
