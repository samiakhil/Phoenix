package FlowControls;

import java.util.HashSet;
import java.util.Set;

public class Nineth_Task {

	
	public static void main(String[] args) {
		int[] num = { 1, 5, 2, 2, 2, 5, 5, 4 };
		int k = 3;
		Set<Integer> s = new HashSet();
		for (int l = 0; l < num.length; l++) {
			s.add(num[l]);
		}
		Integer[] num2 = s.toArray(new Integer[s.size()]);
		for (int i = 0; i < num2.length; i++) {
			for (int j = 0; j < num2.length; j++) {
				if (num2[i] - num2[j] == k) {
					System.out.println("(" + num2[j] + "," + num2[i] + ")");
				}
			}
		}
	}

}
