package FlowControls;

public class Tenth_Task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = { 1, 3, 5, 4, 8, 2, 4, 3, 6, 5 };
		
		int one =arr[1];
		int two =arr[7];
		int three=arr[5];
		
		System.out.println(Math.abs(1-5));
		System.out.println(Math.abs(7-5));
		System.out.println(Math.min(4,2));
	}

}

