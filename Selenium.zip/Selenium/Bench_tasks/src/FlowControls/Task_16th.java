package FlowControls;

public class Task_16th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[]= {5,7,3,4,3,6,4};
		int num2[] = new int[3];
		
		int k=0;
		for(int i=0; i<=num.length-1; i++) {
			int min=0;
			for(int j =i+1; j<=num.length-1; j++) {
				if(num[i] ==num[j]) {
					num2[k]= i;
					k++;
					
				}
			}
		}
		System.out.println(num2[0]);
		
		
	}

}
