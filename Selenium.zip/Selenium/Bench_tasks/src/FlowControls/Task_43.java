package FlowControls;

import java.util.HashMap;
import java.util.Map;

public class Task_43 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Input:  { 10, 8, 15, 12, 6, 20, 1 }
		 
		//Output: { 4, 3, 6, 5, 2, 7, 1 }

		
		
		int num[] = { 10, 8, 15, 12, 6, 1,20 };
		int count = 0;
		int m = 20;
		Map<Integer, Integer> ma = new HashMap<Integer, Integer>();
		ma.put(1, 1);
		ma.put(6,2);
		ma.put(8,3);
		ma.put(4, 10);
		ma.put(5, 12);
		ma.put(6, 15);
		ma.put(7, 20);

		
//		Map<Integer, Integer> na = new HashMap<Integer, Integer>();
//		na.put(1, 1);
//		na.put(6, 2);
//		na.put(8, 3);
//		na.put(10, 4);
//		na.put(12, 5);
//		na.put(15, 6);

		// System.out.println(ma.get(8));
		for (int i = 1; i <= num.length-1; i++) {

			for (int j = 1; j <num.length; j++) {

				if (num[i] == j) {

					System.out.println(ma.get(i));
				}
			}

		}
	}
}
