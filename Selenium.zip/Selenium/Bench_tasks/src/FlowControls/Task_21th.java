package FlowControls;

public class Task_21th {

	// Bubble sort
	
	public void main(String[] args) {
		int a[]= {12,10,4,2,34};
		int temp;
		for(int i=0;i<a.length;i++){
			for(int j=1;j<a.length;j++){
				if(a[j-1]>a[j]){
					temp=a[j-1];
					a[j-1]=a[j];
					a[j]=temp;
					}
				}
			}
		System.out.print("The bubble sort is:");
		for(int i=0;i<a.length;i++)
		{
			System.out.print(a[i]+" ");
			}
	}}
	
	// 
//
//


