package FlowControls;

public class Test_47th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num[] = {9,-3,5,-2,-8,-6,1,3};
		for(int i=0;i<num.length-1;i++) {
			if(num[i]<0) {
				System.out.println(num[i]+" ");
			}
		}
		for(int i=0; i<num.length;i++) {
			if(num[i]>0) {
				System.out.println(num[i]+" ");
			}
		}
		
		
		
		
		
	}

}
