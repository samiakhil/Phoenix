package Jpl_Tasks;

public class Threedpalindrome_4Th {

	public static void main(String[] args) {
		
		String s=args[0];
		System.out.println(s);
		StringBuffer bi =  new StringBuffer(s);
		String f =bi.reverse().toString();
		if(s.equals(f)) {
			System.out.println(" true");
		}
		else {
			System.out.println("false");
		}
		
	
	
		
		
			

	}

}
