package Jpl_Tasks;

public class EvenFinder_5Th {

	public static void main(String[] args) {
		
		
		int no=Integer.parseInt(args[0]);
		try {
			
		String s= no%2==0?"true":"false";
		
		System.out.println(s);
			
		}	
		 catch(NumberFormatException e) {
			 System.out.println("error");
			 
		 }
			
		
		
		

		
		
	}

}
