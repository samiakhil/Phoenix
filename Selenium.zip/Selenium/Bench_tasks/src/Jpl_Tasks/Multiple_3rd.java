package Jpl_Tasks;

public class Multiple_3rd {

	
	public static void main(String[] args) {
		
		
		int no=Integer.parseInt(args[0]);
			int result = (no/100+1)*100;
			System.out.println(result);
			
			
		}
	}
	
	
	
	
	
	
	
	
	

