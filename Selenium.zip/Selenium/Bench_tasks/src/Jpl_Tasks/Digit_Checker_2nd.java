package Jpl_Tasks;

import java.util.Scanner;

public class Digit_Checker_2nd {

	public static void m1(int a, int b) {

		int result = a - b;
		System.out.println(result);
	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Values");
		int a = sc.nextInt();
		System.out.println("Enter values");
		int b = sc.nextInt();
		System.out.println("result: ");
		Digit_Checker_2nd.m1(a, b);

	}

}
