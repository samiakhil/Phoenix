package Arrays_Assignments;

public class ArraysSpecificvalue_2nd {

	public static void main(String[] args) {
		
		int a[] = {1,2,3,4,5,6};
		
		int n=4;
		for(int i=0;i<a.length;i++) {
			if(a[i]==n) {
				System.out.println("presented value");
			}
			else {
				System.out.println("not present value");
			}
		}
		
		

		
		
		
	}

}
