package Arrays_Assignments;

import java.util.ArrayList;

public class Index_of_Array_3rd {

	public static void main(String[] args) {

		int a[] = { 'a', 'b', 'c', 'd', 'f' };

		ArrayList<Character> li = new ArrayList<Character>();
		li.add('a');
		li.add('b');
		li.add('c');
		li.add('d');
		li.add('f');
		System.out.println(li.indexOf('c'));

	}

}
