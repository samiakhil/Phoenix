package Arrays_Assignments;

public class Reverse_Array_6Th {

	
	//Write a Java program to reverse an array of integer values
	
	public static void main(String[] args) {
	
		int a[]= {1,4,6,7,8};
		int rev=0;
		for(int i=a.length-1;i>0;i--) {
			
			System.out.print(a[i]+" ");
			
			
		}

	}

}
