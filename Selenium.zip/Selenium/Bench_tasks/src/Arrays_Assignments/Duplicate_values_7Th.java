package Arrays_Assignments;

public class Duplicate_values_7Th {

	// Write a Java program to find the duplicate values of an array of integer
	// values

	public static void m1(int[] arr) {

		            int count;
		for (int i = 0; i < arr.length; i++) {
			count=0;
			for (int j = i+1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					count++;
					
					arr[j]='%';

				}
				

			}
			if(count>=1&&arr[i]!='%') {
			System.out.println(arr[i]);
		}

	}
	}
	public static void main(String[] args) {
		int[] arr = { 4, 4, 5, 5, 6, 7 };

		m1(arr);

	}

}
