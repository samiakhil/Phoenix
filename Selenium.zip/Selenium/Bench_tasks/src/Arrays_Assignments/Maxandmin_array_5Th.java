package Arrays_Assignments;

public class Maxandmin_array_5Th {

	//Write a Java program to find the maximum and minimum value of an array
	public static void main(String[] args) {
		
		
     int a[] = {5,7,8,9,2,6};
     
     int max=0;
     int min=a[0] ;
     for(int i=0;i<a.length;i++) {
    	 if(a[i]>max) {
    		 max=a[i];
    		 
    	 }
    	 
    	  else if (a[i]<min) {
    		 min =a[i];
    		 

    	 }
     }
    	 System.out.println(" minimum value:"+min);
    	     System.out.println("maximum value:"+max);
    	   
     
   
		
		
		}

}
