package Arrays_Assignments;

public class K_largest {

	public static void main(String[] args) {
	
	
		int k=3;
		int a[]= {4,5,3,7,8,9};
		
	      for(int i=0;i<a.length;i++) {
	    	  if(a[i]<=k) {
	    		  k=a[i];
	    		  System.out.println(k);
	    	  }
	    	  
	      }
		
		
	
	}

}
