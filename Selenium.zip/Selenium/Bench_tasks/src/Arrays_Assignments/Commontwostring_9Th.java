package Arrays_Assignments;

import java.util.HashSet;

public class Commontwostring_9Th {

	// Write a Java program to find the common elements between two arrays (string
	// values)

	public static void common(String[] arr, String[] arrs) {

		// HashSet<String> di = new HashSet<>();

		for (int i = 0; i < arr.length; i++) {
			for (int j = 0; j < arrs.length; j++) {
				if (arr[i].equals(arrs[j])) {
					System.out.println(arrs[j] + " ");

				}

			}
		}

	}

	public static void main(String[] args) {

		String[] arr = { "akhil", "sami", "to" };
		String[] arrs = { "akhil", "testing" };

		common(arr, arrs);

	}

}
