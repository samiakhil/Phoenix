package Arrays_Assignments;

import java.util.ArrayList;

public class Element_Remove_4Th {

	
	//Write a Java program to remove a specific element from an array
	
	public static void main(String[] args) {
	
		  int b[] = {1,2,3,4,5};
		  ArrayList arr = new ArrayList();
		  arr.add(1);
		  arr.add(2);
		  arr.add(3);
		  arr.add(4);
		  System.out.println(arr);
		  arr.remove(2);
		  System.out.println("after remover:"+arr);
		  

		
		
	}

}
