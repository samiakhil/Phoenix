package Arrays_Assignments;

import java.util.Scanner;


// Write a Java program to find the duplicate values of an array of string values
public class Duplicate_String_8Th {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in) ;
			
		String[] ar = new String[6];
		System.out.println("Enter values:");
		for(int i=0;i<ar.length;i++) {
			
		
			 ar[i] =sc.nextLine();
			 
		}
		System.out.println("Enter values are:");
		for(int i=0;i<ar.length;i++) {
			
		System.out.println(ar[i]);
		}
	}
		public  void main() {
		
			
			
			
			
		}

		 
		 
			 

	
			

		
		
	}




