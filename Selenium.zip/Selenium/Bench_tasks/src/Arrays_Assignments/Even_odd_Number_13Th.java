package Arrays_Assignments;

public class Even_odd_Number_13Th {

	//Write a Java program to separate even and odd numbers of agiven array of integers. Put all even numbers first, and then odd numbers.
	
	public static void evod(int a[]) {
		
		int index[]= new int[9];
		for(int i=0;i<a.length;i++) {
			if(a[i]%2==0) {
				System.out.println("even:"+a[i]);
			}
			 if(a[i]%2==1) {
				System.out.println("odd:"+a[i]);
				}
			}
		}
		
		public static void main(String[] args) {
		int a[]= {2,3,4,5,6,7,8,9};
		evod(a);

	}

}
