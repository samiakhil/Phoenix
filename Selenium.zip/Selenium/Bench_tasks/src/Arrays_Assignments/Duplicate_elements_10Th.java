package Arrays_Assignments;

public class Duplicate_elements_10Th {

	// Write a Java program to remove duplicate elements from an array

	public static void duplicate(int a[]) {

		int count = 0;
		for (int i = 0; i < a.length; i++) {
			
			for (int j = i + 1; j < a.length; j++) {
                    
				if (a[i] == a[j]) {

					System.out.println(a[j]);
				}
			}
								}
			}
		
     public static void main(String[] args) {

		int a[] = { 3, 5, 6, 7, 7, 3 };
		duplicate(a);

	}

}
