package Arrays_Assignments;

public class Secondlargest_11Th {

	// Write a Java program to find the second largest element in an array.

	public static void second(int a[]) {

		int secondmax = a[0];
		for (int i = 0; i < a.length; i++) {
			System.out.println(a[i]);
		}
		for (int i = 0; i < a.length; i++) {

			if (a[i] > secondmax) {

				secondmax = a[i];
			}

		}
		System.out.println("data:" + secondmax);

	}

	public static void main(String[] args) {
		int a[] = { 3, 4, 5, 1, 6, 7 };

		second(a);

	}

}
