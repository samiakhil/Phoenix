package Arrays_Assignments;

public class AverageValue_1St {

	public static void main(String[] args) {
		
		int a[] = {10,23,12,89,45};
		int sum=0;
		for(int i=0;i<a.length; i++) {
			sum= sum+a[i]/2;
		}
		
		System.out.println(sum);
	}

}
