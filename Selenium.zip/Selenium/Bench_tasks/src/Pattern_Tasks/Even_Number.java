package Pattern_Tasks;

public class Even_Number {
        // even numbers
	
//	public static void even(int num) {
//
//		if (num % 2 == 0) {
//
//			System.out.println("even number");
//		}
//		else {
//			System.out.println(" not even number");
//		}
//		
//	}
//	
//	public static void main(String[] args) {
//		int num=13;
//		even(num);
//		
//	}
//	

	// even numbers 1 to 10 
	
//	public void even() {
//		
//		for(int i=0;i<10;i++) {
//		if(i %2==0) {
//			System.out.println(i+":even number");
//			}
//		
//		// if you declare only print even numbers remove else block
//		
////		else {
////			System.out.println(i+":not even number");
////		}
////		
//	}
//}
//	public static void main(String[] args) {
//		
//		Even_Number ev = new Even_Number();
//		ev.even();
//		
//	}
	
	
	
	
}