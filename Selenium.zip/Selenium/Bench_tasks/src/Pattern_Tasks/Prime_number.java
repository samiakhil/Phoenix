package Pattern_Tasks;

import java.util.Scanner;

public class Prime_number {

	/*
	 * public void prime(int num) {
	 * 
	 * int count = 0; for (int i = 1; i <= num; i++) { if (num % i == 0) {
	 * 
	 * count++; } }
	 * 
	 * if (count == 2) { System.out.println("prime number");
	 * 
	 * } else { System.out.println("not prime number"); }
	 * 
	 * }
	 */
	

	/*
	 * public static void main(String[] args) { 
	 * //int num = 2;
	 *  Prime_number pr = new
	 * Prime_number(); 
	 * //pr.prime(num);
	 * 
	 * 
	 * }
	 */
	public static void prime(int n1,int n2)
	{
		for(int i=n1;i<=n2;i++)
		{
			int count=0;
			for(int j=1;j<=i;j++)
			{
				if(i%j==0)
				{
					count++;
				}
			}
			if(count==2)
			{
				System.out.println(i+" prime number");
			}
			else
			{
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		//int num=0;
				
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the range");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		Prime_number.prime(n1, n2);
		
		}
	}
	
	


