package Pattern_Tasks;

import java.util.Scanner;

public class Swap_Two_values {

	// two values
//	public static void swap(int a, int b) {
//		a =a+b;
//		b =a-b;
//		a= a-b;
//		System.out.println(a+" "+b);
//	}
//	
//	public static void main(String[] args) {
//		swap(13,17);
//		
//	}
	
	// two values with third variable
	
	
	public static void swap(int a, int b) {
		//int a,b,c;
		int temp;
		temp=a;
		a=b;
		b=temp;
		//a =temp;
		 System.out.println("After swaping values:"+a+" "+b);
      
		}
	 public static void main(String[] args) {
		
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter first value");
		 int dont = sc.nextInt();
		 System.out.println("Enter second value");
		 int dom = sc.nextInt();
		 
		 swap(dont, dom);
	      
		
				 
	}
	
	
	
	
	// three variables 
	
//	public static void swap(int a, int b,int c) {
//		
//		a=a+b+c;
//		b=a-(b+c);
//		c=a-(b+c);
//		a=a-(b+c);
//		System.out.println(a+" "+b+" "+c);
//	}
//	public static void main(String[] args) {
//		int a=34;
//	    int b=56;
	//    int c=98;
//		swap(a, b, c);
//	}
	
	// three variable using third variable temp
	
//	public static void swap(int a, int b,int c) {
//	 int temp;
//		temp =a+b+c;
//		b=temp-(b+c);
//		c=temp-(b+c); 
//		a=temp-(b+c);
//		System.out.println("After swapping the numbers are:"+a+" "+b+" "+c);
//		}
//	public static void main(String[] args) {
//		int a,b,c;
//		a=34;
//		b=56;
//		c=24;
//		System.out.println("Before swapping the numbers are:"+a+" "+b+" "+c);
//		swap(a,b,c);
//		
//	}
	
	
	
}
