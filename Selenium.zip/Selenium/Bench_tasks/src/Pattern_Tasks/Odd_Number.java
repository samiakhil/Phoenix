package Pattern_Tasks;

public class Odd_Number {

	public static void main(String[] args) {
	
        // if you put in to k=1
		// if you put in to k=2
		
		int k=1;
		for(int i=0;i<=4;i++) {
			for(int j=0;j<=4;j++) {
				System.out.print(k+" ");
				k=k+2;
			}
			System.out.println(" ");	
		}
		
	}
	

}
