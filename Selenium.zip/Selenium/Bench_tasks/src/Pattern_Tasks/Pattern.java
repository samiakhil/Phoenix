package Pattern_Tasks;

public class Pattern {
//out put:
//	*****
//	*****
//	*****
//	*****
	
//	public static void main(String[] args) {
//
//		for (int i = 0; i < 4; i++) {
//			for (int j = 0; j < 5; j++) {
//				System.out.print("*");
//			}
//
//			System.out.println();
//		}
//
//	}	
//----------------------------------------	
	
	// triangle pattern
   //	output
	//*
//	  **
//	  ***
//	  ****
//	public static void main(String[] args) {
//		
//	
//	for(int i=0;i<4;i++) {
//		for(int j=0;j<=i;j++) {
//			
//			System.out.print("*");
//		}
//		System.out.println("");
//	}
//	
//	
//}
	
//----------------------------------------------------
	//left triangle   Output
//	****
//	 ***
//	  **
//	   *
	public static void main(String[] args) {
		for(int i=0;i<=4;i++) {
		for(int j=0;j<=i;j--) {
			System.out.print("*");
		}
		System.out.println("");
	}
		
		
		
		
		
		
		
		
		

}}
