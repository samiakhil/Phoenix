package Pattern_Tasks;

public class Leap_year {

	public int leap(int year) {

		if (year % 4 == 0) {

			System.out.println("leap year");
		} else {
			System.out.println("not leap year");
		}

		return year;
	}

	public static void main(String[] args) {

		int year = 2012;

		Leap_year as = new Leap_year();
		as.leap(year);

	}

}
