package String_Tasks;

public class First1St_Task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name ="Akhil Sami Testing";
		String[] sd = name.split(" ");
		
		for(int i=0; i<sd.length;i++) {
	          
			System.out.print(sd[i]);
		}
		
				
		
		
		
		
		
		
		
		
	}

}
