package String_Tasks;

public class Task_10th {

	// 10)Program to Find the Frequency of Characters

	public static void main(String[] args) {

		String name = "aakhilssssami";

		char[] ch = name.toCharArray();
		int[] mi = new int[name.length()];
		int count = 0;
		for (int i = 0; i < ch.length; i++) {
			mi[i] = 1;
			for (int j = i + 1; j < ch.length; j++) {
				if (ch[i] == ch[j]) {
					count++;
					mi[i]++;
					ch[j] = '0';

				}

			}

		}
		for (int i = 0; i < mi.length; i++) {
			if (ch[i] != ' ' && ch[i] != '0') {
				System.out.print(ch[i] + ":" + mi[i] + " ");
			}

		}
	}
}
