package String_Tasks;

public class Task_11Th {

	//11)Program to Find the Largest and Smallest Word in a String
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String name ="I am an an tester";
		String[] arr = name.split(" ");
		//char[] arr =name.toCharArray();
		//String[] arr = name.split("");
	
		
		int count;
		int max=0;
		int min=name.length();
	    String minf="";
	    String mins="";
		for(int i=0;i<arr.length;i++) {
		
			//for(int j=i+1;j<arr.length;j++) {
				
				if(arr[i].length()>max) {
					max=arr[i].length();
					minf =arr[i];
					//System.out.print(arr[i]+" ");
					//System.out.println(arr[i].length());
				}
				if(arr[i].length()<min) {
					min=arr[i].length();
					mins=arr[i];
				}
			//}
			
		}
		System.out.println(minf);
		System.out.println(mins);
		//System.out.println("max:"+ max+ " ");
		//System.out.println("min:"+min);
		
		
	}

}
