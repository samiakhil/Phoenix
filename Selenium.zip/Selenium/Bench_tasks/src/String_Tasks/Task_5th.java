package String_Tasks;

public class Task_5th {

	//5) Program to Determine Whether a Given String is Palindrome
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name ="mom";
		String Count="";
		
		for(int i=name.length()-1;i>=0;i--) {
			Count =Count+name.charAt(i);
		}
		
		   if(name.equals(Count)) {
			   
			   System.out.println("palindrome");
		   }
			
		   else {
			   System.out.println(" not palindrome");
		   }
			
		}}
		
		
	