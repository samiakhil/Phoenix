package String_Tasks;

import java.net.MulticastSocket;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;

public class Task_9th {

	// 9) Program to Find the Duplicate Words in a String

	public static void main(String[] args) {

//		String s = "i am am a a test engineer";
//		String[] ch = s.split(" ");
//		//char[] ch =s.toCharArray();
//      int count;
//		
//		for(int i=0;i<ch.length;i++) {
//			count=1;
//			for(int j=i+1;j<ch.length; j++) {
//				if(ch[i].equals(ch[j])) {
//					count++;
//					
//					ch[j]="0";
//				}
//			}
//			if(count>1&& ch[i]!="0") {
//				System.out.print(ch[i]+" ");
//			}
		
		String s= "akhilsami";
		char[] ch =s.toCharArray();
		String m="";
		for(int i=0;i<ch.length;i++) {
			if(i>=0 && i<2) {
				System.out.print(ch[i]);
			}
			else {
				
				//System.out.print(ch[i]);
			}
	//System.out.print(s.charAt(i));
					}
				
	
					
				}
			//}
				
		
		//}
		
		
		
//		Set<String> my = new LinkedHashSet<String>();
//		for (String x : ch) {
//			my.add(x);
//		}
//
//		Iterator<String> mi = my.iterator();
//		while (mi.hasNext()) {
//			System.out.print(mi.next() + " ");
//		}
//
//	}

}
//}
