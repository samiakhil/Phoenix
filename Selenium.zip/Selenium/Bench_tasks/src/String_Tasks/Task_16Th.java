package String_Tasks;

public class Task_16Th {

	//Write a Java program to print after removing duplicates from a given String
	
	public static void main(String[] args) {
		
		String name="Akhillssaami";
		
		System.out.println("give string:"+ name);
		removeDuplicate(name);
		
		
	}
	private static void removeDuplicate(String name) {
		// TODO Auto-generated method stub
		char[] ch =name.toCharArray();
		String mi="";
		for(char i:ch) {
			
			if(mi.indexOf(i)==-1){
				mi=mi+i;
				}
		}
		
		System.out.println(mi);
		
	}
	}


