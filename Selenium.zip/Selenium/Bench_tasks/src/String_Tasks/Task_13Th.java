package String_Tasks;

import java.util.Scanner;

public class Task_13Th {

	//Write a Java program to get the character at the given index within the 
//	String 
//	 Sample Output: 
//	 Original String = Java Exercises! 
//	 The character at position 0 is J 
//	 The character at position 10 is i
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String name="Java Exercises";
		
		Scanner obj = new Scanner(System.in);
		System.out.println("Enter word");
		 String world =obj.nextLine();
		
		 System.out.println(world);
		 
		 Scanner obj1 =new Scanner(System.in);
		 System.out.println("Enter Index");
		 
		 int in = obj1.nextInt();
		 System.out.println(in);
		 char[] d =world.toCharArray();
		 for(int i=0;i<d.length;i++) {
			 if(i==in) {
			System.out.println(d[i]);	 
			 }
		 }
		 
		
	
		
	}

}
