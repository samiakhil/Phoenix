package String_Tasks;



public class Task_14th {

	//Write a Java program to replace all the 'd' characters with 'f'
	
//	public static void main(String[] args) {
//		
//		String  str =" It is a dog big";
//		
//		String st = str.replace('d', 'f');
//		System.out.println("original :" +str);
//		System.out.println("update string:"+st);
//		
//	}
	
	//factorial
	
	
		
	
//	public void fact(int i,int fact,int number) {
//		
//		//number=5;
//		for( i=1;i<=number;i++) {
//		
//		fact=fact*i	;
//        
//		
//			
//		}
//		System.out.println(fact);
//		}
//	public static void main(String[] args) {
//		Task_14th si = new Task_14th();
//		si.fact(1, 1, 5);
//		
//		
		
//	}
	
	//prime number
	
//	static boolean isPrime (int n) {
//		
//		
//	for(int i=2;i<n;i++) {
//		if(n%i==0) {
//			return false;
//		}
//	}
//	return true;
//	    
//	}
//	public static void main(String[] args) {
//		//Task_14th mi = new Task_14th();
//		
//		if(isPrime(22)) {
//			System.out.println("is Prime");
//		}else {
//			System.out.println("not");
//		}
//	}

	
	public void prime(int n) {

		int count = 0;

		for (int i = 1; i <= n; i++) {
			if (n % i == 0) {
				count++;
			}

			
					
}
		if (count == 2) {
			System.out.println("is prime");
		}
		else if(count>2) {
			System.out.println("not prime");
		}
	}

	public static void main(String[] args) {
		Task_14th gi = new Task_14th();

		gi.prime(15);
	}

}
