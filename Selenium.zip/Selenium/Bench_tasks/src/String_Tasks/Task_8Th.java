package String_Tasks;

public class Task_8Th {

	// 8) Program to Find the Duplicate Characters in a String
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "akhilsami";
		int count = 0;
		char[] ch = name.toCharArray();

		for (int i = 0; i < ch.length; i++) {
			count = 0;
			for (int j = 0; j < ch.length; j++) {
				if (ch[i] == ch[j]) {
					count++;

				}

			}

			if (count > 1) {
				System.out.println(ch[i] + " " + count);
			}

		}

	}

}
