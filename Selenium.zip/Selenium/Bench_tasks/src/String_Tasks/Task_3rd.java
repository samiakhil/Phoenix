package String_Tasks;

public class Task_3rd {

	
	//3) Program to replace the spaces of a string with a specific character
	
	public static void main(String[] args) {
		
		String name = "Akhil Sami Testing";
		
		String s ="";
		char[] ch =name.toCharArray();
		
		for(int i=0;i<ch.length;i++) {
			if(ch[i]!=' ') {
				s=s+ch[i];
			}
			else {
				s+="*";
			
				
			}
			
		}

		System.out.println(s);
		
		
		
		
		
	}

}
