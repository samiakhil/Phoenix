package String_Tasks;

public class Task_2nd {

	// Program to replace lower-case characters with upper-case and vice versa
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String name ="AkhilSamiTesting";
		char[] sm = name.toCharArray();
		
				
		for(int i=0;i<sm.length;i++) {
			
				
           if(Character.isUpperCase(sm[i])) {
        	 
        	   sm[i]=Character.toLowerCase(sm[i]);
        	   System.out.print(sm[i]+" ");
           }
        	   else if (Character.isLowerCase(sm[i])) {
        		   sm[i]=Character.toUpperCase(sm[i]);
        		  System.out.print(sm[i]+ " "); 
        		   
           }

				
			}
		}
		
		
	}


