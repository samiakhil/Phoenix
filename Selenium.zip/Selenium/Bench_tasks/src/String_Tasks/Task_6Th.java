package String_Tasks;

import java.util.Arrays;

public class Task_6Th {

	//6) Program to Find Maximum and Minimum Occurring Character in a String

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name ="Akhilsamiii";
		
		int  max=0;
		int count=0;
		int min=1;
		char[]ch =name.toCharArray();
		
		int[] num =new int[name.length()];
		for(int i=0;i<ch.length;i++) {
			count=0;
		for(int j=0; j<ch.length;j++) {
			if(ch[i]==ch[j]) {
				count++;
			}
		}
			
			num[i]=count;
			if(count>max) {
				max=count;
			}
			if(count<min) {
				min =count;
				
			}
		}
		System.out.println("max="+ max);
		System.out.println("min="+min);
		
//	Arrays.sort(num);
//	System.out.println(num[0]);
//	System.out.println(num[num.length-1]);
		
	}

}
