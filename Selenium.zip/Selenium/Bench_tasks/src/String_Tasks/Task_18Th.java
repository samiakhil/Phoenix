package String_Tasks;

public class Task_18Th {

	//How to Reverse A string 4 Different ways in java?
	
	public static void main(String[] args) {
		
		String name ="akhil";
		
		 //char ch[] = name.toCharArray();
		String rev="";
		
		for(int i=name.length()-1;i>=0;i--) {
			
			rev=rev+name.charAt(i);
			
				
			}
			
		System.out.println(rev);

		}
		
			
		}


