package String_Tasks;

import java.util.Scanner;

public class Task_19Th {

	// Java Program to remove Special Characters From Given String

	public static void special(String str) {

		// str="akhil#$sam1i";

		char ni[] = str.toCharArray();
		for (int i = 0; i < ni.length; i++) {

			int ch = (int) ni[i];
			// System.out.println("enter");
			if (ch >= 97 && ch <= 122) {
				System.out.print(ni[i]);
			}
			if (ch >= 65 && ch <= 95) {
				System.out.println(ni[i]);

			}
            if(ch>='0' && ch<='9') {
            	System.out.print(ni[i]);
            }
		}

	}

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter name:");
		String di =sc.nextLine();
		Task_19Th jio = new Task_19Th();
		jio.special(di);
	}
}
