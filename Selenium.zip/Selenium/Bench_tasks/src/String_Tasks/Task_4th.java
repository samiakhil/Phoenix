package String_Tasks;

public class Task_4th {

	//4) Program to Count the Total Number of Characters in a String
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name ="Akhil Sami";
		char[] ch =name.toCharArray();
		String so ="";
		//String count=" ";
		for(int i=0; i<ch.length; i++) {
			if(ch[i]!=' ') {
				so=so+ch[i];
				
			}
		}
		
		System.out.println(so.length());
		
		
	}

}
