package String_Tasks;

public class Task_22Th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "AAkkhilll";

		char[] ch = name.toCharArray();

		for (int i = 0; i < ch.length; i++) {
			for (int j = i + 1; j < ch.length; j++) {
				char temp;

				if (ch[i] > ch[j]) {

					temp = ch[i];
					ch[i] = ch[j];
					ch[j] = temp;

				}
			}

			System.out.print(ch[i]);

		}

	}

}
