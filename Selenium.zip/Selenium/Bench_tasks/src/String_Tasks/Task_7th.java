package String_Tasks;

public class Task_7th {

	//7) Program to Find Reverse of a String
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String name ="Testing";
		String rev ="";
		for(int i=name.length()-1;i>=0;i--) {
			rev =rev+name.charAt(i);
			
		}
		
		System.out.print(rev);
		
	}

}
