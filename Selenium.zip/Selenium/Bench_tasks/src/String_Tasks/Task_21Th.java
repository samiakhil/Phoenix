package String_Tasks;

import java.util.Scanner;

public class Task_21Th {

	
	public void duplicate(String str) {
		
	//	String str="";
		
		//String sd =str.replaceAll("[^A-Za-z0-9^]"+" ");
		char ch[] = str.toCharArray();
		for(int i=0;i<=ch.length-1;i++) {
			for(int j=i+1;j<ch.length;j++) {
				
				if(ch[i]== ch[j]) {
					System.out.print(ch[j]+" ");
					
				}
			}
		}
	}
	public static void main(String[] args) {
		
		Task_21Th fi = new Task_21Th();
		Scanner sc = new Scanner(System.in) ;
			System.out.println("Enter value");
		String ji = sc.nextLine();
		fi.duplicate(ji);
		}
		
	}


