package String_Tasks;

import java.util.Scanner;

public class Task_20Th {

	// Java Program To Remove White Spaces from given String

	public void spaces(String str) {

		String[] st = str.split(" ");
		for (String ch : st) {

			System.out.print(ch);

		}

	}

	public static void main(String[] args) {

		Task_20Th di = new Task_20Th();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		String co = sc.nextLine();
		di.spaces(co);

	}
}
