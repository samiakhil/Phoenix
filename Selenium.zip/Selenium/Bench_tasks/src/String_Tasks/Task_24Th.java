package String_Tasks;

public class Task_24Th {

	//Java Program to Find First Not Repeated Character
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s =" Akkhfhd";
		
		
		
		}

}
