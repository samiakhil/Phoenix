package String_Tasks;

import java.util.Scanner;

public class Task_25Th {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "aakhilssssami";

//		char[] ch = name.toCharArray();
//		int[] mi = new int[name.length()];
//		int count = 0;
//		for (int i = 0; i < ch.length; i++) {
//			mi[i] = 1;
//			for (int j = i + 1; j < ch.length; j++) {
//				if (ch[i] == ch[j]) {
//					count++;
//					mi[i]++;
//					ch[j] = '0';
//
//				}
//
//			}
//
//		}
//		for (int i = 0; i < mi.length; i++) {
//			if (ch[i] != ' ' && ch[i] != '0') {
//				System.out.print(+mi[i] + " ");
//			}
//
//		}
		//-----------------------------
		
//		StringBuilder bi = new StringBuilder(name);
//		bi.reverse();
//		System.out.println(bi);
	//	-------------------------------
		
		String rev="";
		Scanner sc = new Scanner(System.in);
		System.out.println("enter name");
		
		String inti =sc.nextLine();
		
		for(int i=name.length()-1;i>=0;i--) {
		     rev=rev+inti.charAt(i);
		     System.out.println(rev);
		     
		     
		}}}


