package TaskOne;

import java.util.Arrays;

public class Dupp {

	public static void main(String[] args) {
		
		
	/*	String str = "santhoshsszsssaaaaa"; 
		int arr[] = {2,3,4,6,7,8,9,9};

		for (int i = 0; i < arr.length; i++) {
			int count = 1;
			for (int j = i + 1; j < arr.length; j++) {
				if (arr[i] == arr[j]) {
					count++;
					arr[j] = '0'; 
				}
				}
			
			  if (count > 1 && arr[i] != '0') { 
					System.out.println(arr[i]);
			  }}
			
			
		String str1 = "san santhosh san ram ram raju raju ram";
					String[] split = str1.split(" ");
					System.out.println(Arrays.toString(split));
				
					   }*/

}}
