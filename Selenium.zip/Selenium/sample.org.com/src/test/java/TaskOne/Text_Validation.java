package TaskOne;

import static org.testng.Assert.assertEquals;

import java.awt.Window;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Text_Validation {

	//public static void main(String[] args) {
	@Test	
	public void main() {
		//Webdrivermanager.chromedriver.setup();
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.ojas-it.com/");
		driver.manage().window().maximize();
//		String sc ="Ojas is a Cost Effective IT Services Company with 11 years of rich experience in serving its customers with a team of 700+ IT Professionals. We’re one of the fastest growing companies in India providing Services in Application Dev & Support, Identity Governance, Testing Services, Mobile Dev & Testing, Staff Augmentation and Staffing Services to our customers.";
//		 WebElement script =driver.findElement(By.xpath("(//h4[@class='text-center'])[2]"));
//		Assert.assertEquals(sc,script);
//		
		
		WebElement si=driver.findElement(By.xpath("//h2[text()='Our Top Customers']"));
//		JavascriptExecutor js= (JavascriptExecutor)driver;
//        js.executeScript("arguments[0].scrollIntoView()",si);
		
      Actions ac = new Actions(driver);
      ac.moveToElement(si).perform();
      ac.doubleClick(si).perform();
		
		
        
	//  Dimensions dim = new Dimensions()
		
		
				
		//Assert.assertEquals(true, false);
		//System.out.println(script.getAttribute(sc));
		//System.out.println(script.getText().contains(sc));
		
		//driver.close();
		
		
		
		
		
	}
		
		

	}


