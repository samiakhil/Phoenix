package TaskOne;

public interface Interfaces {

	
	public void surface();
	public void nature();

	
}