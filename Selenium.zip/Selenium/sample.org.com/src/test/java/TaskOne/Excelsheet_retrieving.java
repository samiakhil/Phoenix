package TaskOne;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excelsheet_retrieving {
	public static void main(String[] args) throws Exception {

		File src = new File("C:\\Users\\as21305\\Desktop\\akhil2.xlsx");

		FileInputStream fis = new FileInputStream(src);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.getSheetAt(0);
		int rowCount = sh.getLastRowNum();

		for (int i = 0; i <= rowCount; i++) {
			Row row = sh.getRow(i);
			int cellCount = row.getLastCellNum();
			for (int j = 0; j < cellCount; j++) {
				Cell cell = row.getCell(j);
				System.out.print(cell.getStringCellValue());
				System.out.print(" | ");
			}
			System.out.println();
		}
	}
}