package TaskOne;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MavenProjectandtestng extends Writeexcel {
	// static WebDriver driver;

	@Test
	public static void setup() throws Throwable {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		openNewTab(driver, "https://demoqa.com/", 1);
		String gettitle = driver.getTitle();
		System.out.println(gettitle);
		write(gettitle, 0, 7);
		openNewTab(driver, "http://omayo.blogspot.com/", 2);
		String gettitle2 = driver.getTitle();
		System.out.println(gettitle2);
		write(gettitle2, 1, 4);
		openNewTab(driver, "https://adactinhotelapp.com/", 3);
		String gettitle3 = driver.getTitle();
		System.out.println(gettitle3);
		write(gettitle3, 2, 5);

	}

	public static void openNewTab(WebDriver driver, String url, int position) throws FileNotFoundException {
		// TODO Auto-generated method stub
		((JavascriptExecutor) driver).executeScript("window.open()");

		ArrayList<String> tabs = new ArrayList<String>(driver.getWindowHandles());
		System.out.println("tabs : " + tabs.size() + " >position: " + position + " >\t" + url);

		driver.switchTo().window(tabs.get(position));

		driver.get(url);
	}

//	@Test
	public void write_the_data_xl() throws Exception {

		File file = new File("C:\\Users\\as21305\\Desktop\\akhil1.xlsx");
		FileInputStream fis= new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(fis);
		XSSFSheet sh = wb.createSheet();
		sh.createRow(0).createCell(0).setCellValue("gettilte");
		// sh.getRow(0).createCell(1).setCellValue(69);
		FileOutputStream fos = new FileOutputStream(file);
		wb.write(fos);
		wb.close();
	}

//			  @AfterTest
//	  public void endsession() {
//		  driver.quit();
//	  }

}
