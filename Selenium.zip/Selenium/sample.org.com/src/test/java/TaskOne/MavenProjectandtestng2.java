package TaskOne;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.ArrayList;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class MavenProjectandtestng2 extends Writeexcel {

	public static void write(int j, int i) throws Exception {
		File file = new File("C:\\Users\\as21305\\Desktop\\akhil1.xlsx");
		FileInputStream fis = new FileInputStream(file);
		XSSFWorkbook book = new XSSFWorkbook(fis);
		XSSFSheet sheet = book.createSheet();
		sheet.createRow(i).createCell(j).setCellValue("Test");
		FileOutputStream fos = new FileOutputStream(file);
		book.write(fos);

	}

	public static void main(String[] args) throws Exception {
		write(0, 0);
	}
}
