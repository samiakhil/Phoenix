package TaskOne;

public class Interfacetwo implements Interfaces {

	public void surface() {
				
		System.out.println("ejjrg");
		
	}

	public void nature() {
		 System.out.println("hfhjy");		
	}

	public static void main(String[] args) {
		Interfacetwo fim = new Interfacetwo();
		fim.surface();
		fim.nature();
	}
	
	
	
}
