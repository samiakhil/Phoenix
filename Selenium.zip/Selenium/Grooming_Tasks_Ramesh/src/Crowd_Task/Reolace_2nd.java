package Crowd_Task;

import java.util.Arrays;

public class Reolace_2nd {

	public static void main(String[] args) {
		
		int ar[] = {10,8,15,12,6,20,1};
		int arr[]= {10,8,15,12,6,20,1};
		
		Arrays.sort(arr);
      int n=0;
      for(int i=0;i<ar.length;i++) {
    	  for(int j=0;j<ar.length;j++) {
    		  if(ar[i]==arr[j]) {
    			  ar[i]=j+1;
    			  break;
    			  
    	    }
    	  }
      }
		for(int i=0;i<ar.length;i++) {
			System.out.print(ar[i]+" ");
		}

	}

}
