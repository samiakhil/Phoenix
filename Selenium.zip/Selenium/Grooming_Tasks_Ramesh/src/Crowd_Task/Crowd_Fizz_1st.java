package Crowd_Task;

public class Crowd_Fizz_1st {

	
	public static void fizz(int a) {
		
		for(int i=1;i<100;i++) {
			if(i%(3*5)==0) {
				System.out.println("fizzbuzz");
		}
			else if(i%3==0) {
				System.out.println("fizz");
			}
			else if(i%5==0) {
				System.out.println("buzz");
			}
			else {
				System.out.println(i);
			}
	}
}
	public static void main(String[] args) {
	
		Crowd_Fizz_1st.fizz(100);// 1 to 100 values to print
		
		
	}

}
