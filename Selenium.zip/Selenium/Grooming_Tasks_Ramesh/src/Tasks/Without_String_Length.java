package Tasks;

public class Without_String_Length {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String a="akhilsami";
		int i=0;
		for(char c:a.toCharArray()) {
			i++;
			
		}
		
		System.out.println(i);
		
		
	}

}
