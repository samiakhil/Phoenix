package Tasks;

public interface Interfaces {

	
	
	void m1();void m2();
	}
public class Interface_17 implements Interfaces {
		public void m1(){
			System.out.println("Class A");
			}
		public void m2() {
			System.out.println("Class B");
			}
		public static void main(String[] args) {
			 Interface_17 i=new Interface_17();
			 i.m1();
			 i.m2();
			 }
	}
	

