package Tasks;




	
 class Demo {
public void car(String s1,String s2) {
	 System.out.println("My Car is RR");
	 }}
	 public class Method_overriding_16 extends Demo {
		 public void car(String s1,String s2) {
			 //main.car("m", "n");
			 System.out.println("my car is HONDA");
			 //super.car("n","s2");
			 }
		 public static void main(String[] args) {
			 Method_overriding_16 m=new Method_overriding_16();
			 m.car("m", "n");
			 }
	 }
		
	


