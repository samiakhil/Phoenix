package Tasks;

public class Even_or_odd {

	public static void main(String[] args) {
		
		int a=10;
		
		for(int i=0;i<a;i++) {
			
		if(i%2==0) {
			
			System.out.println(i+" = "+"even");
		}
		else {
			System.out.println(i+" = "+"odd number");
		}
		
		
		
	}

}
}