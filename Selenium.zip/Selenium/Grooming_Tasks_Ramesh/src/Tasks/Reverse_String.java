package Tasks;

public class Reverse_String {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String s="akhil";
		String rev=" ";
		
		for(int i=s.length()-1;i>=0;i--) {
			rev=rev+s.charAt(i);
		}
			System.out.print(rev);

		}
		
			}


