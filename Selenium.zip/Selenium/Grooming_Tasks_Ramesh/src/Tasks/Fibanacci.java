package Tasks;

public class Fibanacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int d=5;
		int a=0;
		int b=1;
		int c=0;
		for(int i=0;i<=d;i++) {
			
			c=a+b;
			a=b;
			b=c;
			System.out.println(c);
			
				}
		
		
		
		
	}

}
