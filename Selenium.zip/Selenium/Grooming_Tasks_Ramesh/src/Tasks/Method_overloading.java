package Tasks;

public class Method_overloading {

	
	public static void main(int a ,int b) {
		int c=a+b;
		System.out.println(c);
		
	}
	
	public static void main(String c) {
		
		System.out.println(c);
	}
	
	
	
	public static void main(String[] args) {
		
		main(10, 5);
		main("akhil");

		
		
		
		
		
		
	}

}
