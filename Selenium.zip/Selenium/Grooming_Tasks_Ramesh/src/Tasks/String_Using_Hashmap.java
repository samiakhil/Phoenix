package Tasks;

import java.util.HashMap;

public class String_Using_Hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		String d="akhil";
		
		HashMap<String,String> di = new HashMap<>();
	
		
		
		
		
	}

}
