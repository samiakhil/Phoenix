package Tasks;

import java.util.Arrays;

public class Second_max_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int c[]= {32,45,67,12,89,23};
		
		Arrays.sort(c);
        for(int i=0;i<c.length;i++) {
        	        }
		
        System.out.println(c[c.length-2]);

	}

}
