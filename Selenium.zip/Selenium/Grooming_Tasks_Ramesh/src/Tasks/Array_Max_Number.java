package Tasks;

public class Array_Max_Number {

	public static void main(String[] args) {
		 int a[] = {10,23,45,58,26,49};
		 
		 int max=0;
		 for(int i=0;i<=a.length-1;i++) {
			 
			 if(max<a[i]) {
				 max=a[i];
				  }
			 }
		 
		 System.out.println(max);
		}
	}
