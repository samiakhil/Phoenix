package Tasks;

public class Arrays_min_Number {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int b[] = {23,56,12,34,89,67};
		
		int min=b[0];
		for(int i=0;i<b.length;i++) {
			if(b[i]<min) {
				min=b[i];
			}
		}
		System.out.println(min);
		
		
		
	}

}
