package Tasks;

public class Sum_of_anarray {

	
	public static void main(String[] args) {
		
	
	int a[]= {23,45,67,35,89};
	
	int sum=0;
	
	for(int i=0;i<a.length;i++) {
		sum=sum+a[i];
	}
	
	System.out.println(sum);

	}
}
