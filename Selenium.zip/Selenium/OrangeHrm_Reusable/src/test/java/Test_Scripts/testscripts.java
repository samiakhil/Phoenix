package Test_Scripts;

import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import com.google.inject.Key;
import com.google.inject.internal.Scoping;

import Orange_base.Base;
import Orange_base.Re_Method;

import static Orange_base.Re_Method.*;
import static Reusable.Homepage.*;

import Reusable.Homepage;
import Reusable.Reusable_login;
import Reusable.Reusable_login.*;


public class testscripts extends Base{
	public static Homepage ho;
	//Reusable_login log = new Reusable_login();
	
	public static void main(String[] args) throws Throwable {
		Reusable_login log = new Reusable_login();
		Re_Method me = new Re_Method();  
		ho = new Homepage();
				
		File fo = new File("C:\\Users\\as21305\\Sample\\OrangeHrm_Reusable\\Propertiesfile");
		FileInputStream fi = new FileInputStream(fo);
		Properties prop = new Properties();
        prop.load(fi);
		
			
        browserlaunch("chrome");
        
        driver.get(prop.getProperty("url"));
        
        Thread.sleep(5000);
        
       	driver.findElement(log.username).sendKeys(prop.getProperty("username"));
       	driver.findElement(log.password).sendKeys(prop.getProperty("password"));
		driver.findElement(log.submit).click();
		 Thread.sleep(5000);

		driver.findElement(ho.Pim).click();
		 Thread.sleep(5000);

		driver.findElement(ho.Add).click();
		
		 Thread.sleep(5000);

		sendkeys(ho.firstname, "akhil");
		//sendkeysonwebelement(ho.firstname(driver),"akhil");
		//sendkeysSOmething(ho.firstname,"");
		sendkeys(ho.lasttname,"sami");
		submits(ho.submit);
		Thread.sleep(5000);
		//WebElement ele = driver.findElement(By.xpath("nationality"));
		//dropdown(ho.nationality, "India");
		
//	Select s=new Select(driver.findElement(By.xpath("(//div[@class='oxd-select-text-input'])[1]")));
//	List<WebElement> options=s.getOptions();
//	System.out.println(options.get(0).toString());

		WebElement nationality = driver.findElement(By.xpath("(//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow'])[1]"));
		nationality.click();
		Robot rt = new Robot();
		rt.keyPress(KeyEvent.VK_DOWN);
		rt.keyPress(KeyEvent.VK_ENTER);
		rt.keyRelease(KeyEvent.VK_ENTER);
		rt.keyRelease(KeyEvent.VK_DOWN);
		
		Actions ac = new Actions(driver);
		ac.clickAndHold(nationality).moveToElement(nationality).build().perform();
		ac.sendKeys(Keys.F5).build().perform();
		ac.sendKeys(Keys.ALT).build().perform();
	}

	
	}

	
	
	
	

