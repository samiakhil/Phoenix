package Test_Scripts;

import java.util.Arrays;

public class Reverse_word {

	public static void main(String[] args) {
		
//		String s ="the is string";
//		char m[]=s.toCharArray();
//		String reverse ="";
//		for(int i=m.length-1; i>=0;i--) {
//		
//		
//	System.out.print(m[i]+" ");
//	}
		
//	int a[]= {5,4,2,6,9,3};
//	Arrays.sort(a);
//	for(int i=0; i<a.length;i++) {
//		//System.out.println(a[i]);
//		//System.out.println(a[a[0]]);
//	
//	}
//		
//		
//		int a[]= {5,4,11,6,9,3};
//		
//		int  small=a[1];
//		
//		for(int i=0;i<a.length;i++) {
//			
//		if(a[i]<small) {	
//			small = a[i];
//			
////			a[i]=small;
//			
//		
//		}
//		//System.out.println(small);
//		}
//		System.out.println(small);
//		
//		for(int i=0;i<a.length;i++) {
//			
//			if(a[i]>small) {	
//				small = a[i];
//				
////				a[i]=small;
//				
//			
//			}
//			//System.out.println(small);
//			}
//			System.out.println(small);
////	-----------------------------------------------------------------		
//	  Even numbers adding
			int v[]= {2,4,5,6,1,7,3,2,2};
			
		
	     int even =0;
	     for(int j=0;j<v.length;j++) {
	    	 
	    	if(v[j]%2==0) 
	    	{
	    		even=even+v[j];
	    	}
	    	
	     }
	     System.out.println(even);
	//------------------------------------------------------
	 // Pattern Program
	    int n=5;
	    
	  for(int i=0;i<=n;i++) {
	  for(int j=1;j<=i;j++) {
		  
		  System.out.print(j);
		  
	  }
	  System.out.println("");
		  
	  }
	     
       
	     
	     
		
//		
//		reverse +=m[i];
//		}
//		System.out.print(reverse);
//}	
		
		
		
//		String sentence = "This is a string";
//		String[] words = sentence.split(" ");
//		String invertedSentece = "";
//		for (String word : words){
//		    String invertedWord = "";
//		    for (int J = word.length() - 1; J >= 0; J--)
//		        invertedWord += word.charAt(i);
//		    invertedSentece += invertedWord;
//		    invertedSentece += " ";
//		}
//		invertedSentece.trim();
		
		}
		
		
		
	}
	
	
	

