package Test_Scripts;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Orange_base.BrowserLaunch_Desired;
import Reusable.Homepage;

public class ClickONPIM extends BrowserLaunch_Desired {

	@Test(priority = 1)
	public static void ClickONPOM() throws Throwable {

		try {
			WebElement ele = driver.findElement(Homepage.Pim);
			if (ele.isDisplayed()) {
				ele.click();
			} else {
				System.out.println("PIM has been Deprecated..........!");
			}
			
			
		} catch (Exception e) {
			System.out.println("Error :"+ e.getMessage());
		}
	}

}
