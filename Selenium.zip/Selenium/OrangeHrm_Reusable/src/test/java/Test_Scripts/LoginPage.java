package Test_Scripts;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import Orange_base.Base;
import Orange_base.BrowserLaunch_Desired;
import Reusable.Homepage;
import Reusable.Reusable_login;

public class LoginPage extends BrowserLaunch_Desired {
	public static Homepage ho;
	// Reusable_login log = new Reusable_login();

	@Test(priority = 0)
	public static void LoginPageMethod() throws Throwable {
		Reusable_login log = new Reusable_login();
		ho = new Homepage();
		driver.get(MyProp("url"));
		Thread.sleep(5000);
		driver.findElement(log.username).sendKeys(MyProp("username"));
		driver.findElement(log.password).sendKeys(MyProp("password"));
		driver.findElement(log.submit).click();
		Thread.sleep(5000);

	}

	@Test(priority = 1)
	public static void ClickONPOM() throws Throwable {

		try {
			WebElement ele = driver.findElement(Homepage.Pim);
			if (ele.isDisplayed()) {
				ele.click();
			} else {
				System.out.println("PIM has been Deprecated..........!");
			}

		} catch (Exception e) {
			System.out.println("Error :" + e.getMessage());
		}
	}

	public static String MyProp(String Value) throws Exception {
		File fo = new File("C:\\Users\\as21305\\Sample\\OrangeHrm_Reusable\\Propertiesfile");
		FileInputStream fi = new FileInputStream(fo);
		Properties prop = new Properties();
		prop.load(fi);
		String ReturnedValue = prop.getProperty(Value);

		return ReturnedValue;
	}

}
