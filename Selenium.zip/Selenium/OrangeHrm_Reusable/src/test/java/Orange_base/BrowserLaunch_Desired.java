package Orange_base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.BeforeTest;

import Test_Scripts.LoginPage;
import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserLaunch_Desired {

	public static WebDriver driver;

	@BeforeTest
	public static void browserlaunch() throws Exception {

		// browser="chrome";
		if (LoginPage.MyProp("browser").equalsIgnoreCase("chrome")) {
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			driver.manage().window().maximize();
		} else if (LoginPage.MyProp("browser").equalsIgnoreCase("Edge")) {
			WebDriverManager.edgedriver().setup();
			driver = new EdgeDriver();
		} else if (LoginPage.MyProp("browser").equalsIgnoreCase("FireFox")) {
			driver = new FirefoxDriver();
			WebDriverManager.firefoxdriver().setup();
		}

	}

}
