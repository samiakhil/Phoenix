package Orange_base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Base {

	public static WebDriver driver ;
	public static void browserlaunch(String browser) {
		
		//browser="chrome";
		if(browser.equalsIgnoreCase(browser)) {
			
			driver = new ChromeDriver();
		driver.manage().window().maximize();
			WebDriverManager.chromedriver().setup();
		}
		else if(browser.equalsIgnoreCase(browser)) {
			driver = new EdgeDriver();
			WebDriverManager.edgedriver().setup();
			}
		else if(browser.equalsIgnoreCase(browser)){
			
			driver= new FirefoxDriver();
		WebDriverManager.firefoxdriver().setup();
		}
		
		
		
	}
	
	
}
