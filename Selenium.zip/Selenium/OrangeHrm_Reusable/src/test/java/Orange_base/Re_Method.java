package Orange_base;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Re_Method extends Base {

//	public static WebDriver driver;

	// send keys

	public static void sendkeysonwebelement(WebElement element, String text) {

		// element.click();
		// element.clear();
		element.sendKeys(text);
	}

	public static void sendkeysSOmething( By xpath,String text) {

		WebElement element=driver.findElement(xpath);
		element.sendKeys(text);
	}


	public void send(WebElement e, WebElement a) {

		e.sendKeys("satyanara");
		a.sendKeys("484I12");
	}

	public static void sendkeys(By locator, String path) {
		try {
			WebElement sendtext = driver.findElement(locator);
			if (sendtext.isDisplayed()) {
				sendtext.click();
				sendtext.sendKeys(path);
			}
		} catch (Exception e) {
			System.out.println("Exception: " + e);
		}
	}
	
	public static void submits(By locator) {
		
		WebElement element =driver.findElement(locator);
		element.submit();
		}

	public static void dropdown(By locator, String Text) {
		//WebElement element = driver.findElement("");
		WebElement ele = driver.findElement(locator);
		Select select = new Select(ele);
		select.selectByVisibleText(Text);
	}
	
	
//	// Reusable method for wait and click
//		public static void waitForElementClickable(WebElement element) {
//			WebDriverWait wait = new WebDriverWait(driver, Integer.parseInt(ConstantUtils.waitTime));
//			wait.until(ExpectedConditions.elementToBeClickable(element));
//		}
//     	

	// Method for check the button and click on it
	public static void checkIfButtonExistsAndClick(WebElement element) throws Throwable {
		if (element.isDisplayed()) {
			// GenericMethods.sychronizationinterval();
			element.click();
		}
	}
}
