package jenkins;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Reporter;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Dataprovider {

//	public static / driver;
	
	@DataProvider(name="authorization")
	
	public Object[][] credencials(){
		
		return new Object[][] {{"jej","hggy"},{"ghg","jh"},{"ytfty","gvg"}};
		}
	
 
	@Test(dataProvider="authorization")
	public void test(String username,String Password) {

		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();

		driver.get("https://adactinhotelapp.com/HotelAppBuild2/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(username);
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(Password);
		driver.findElement(By.xpath("//*[@id=\"login\"]")).click();

	}

}
