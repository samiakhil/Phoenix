package Bench_resources;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;


@Test
public class Loginpage {

	  public static WebDriver driver;
		public void login() throws IOException {
			
		//ChromeOptions c=new ChromeOptions();
		WebDriverManager.chromedriver().setup();
		
		WebDriver driver = new ChromeDriver();
		FileReader f = new FileReader("C:\\Users\\as21305\\Sample\\Bench_Project\\file.properties");
		Properties p = new Properties();
        p.load(f);
		
		driver.manage().window().maximize();
		
		driver.get(p.getProperty("url"));
		//screenshotAS();
		
		
		
		
		
		
		}
	
}
