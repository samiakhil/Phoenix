package Bench_resources;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Reusable_Methods  extends Pageobjects{

	
	
	public static WebDriver driver; 
	public static void login_sendkeys (String username, String password,String login) {
		driver.findElement(Pageobjects.user).sendKeys(username);
		driver.findElement(Pageobjects.pass).sendKeys(password);
		driver.findElement(Pageobjects.login).sendKeys(null);
		}
	
	public static void click() {
		//driver.findElement()
		
	}
	
	
	
	
	
}
