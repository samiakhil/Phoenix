package task1.task1;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Reuasable2 {
	
		public static WebDriver driver;
		public void send(WebElement e,WebElement a)
		{
		   // driver.get(url);
		    e.sendKeys("satyanara");
		    a.sendKeys("484I12");
		}
		public  void allelements(List<WebElement> list)
		{
		    //driver.get(url);
		    // List<WebElement> allInputElemen = (List<WebElement>) list;
		     for(WebElement g:list)
		     {
		         System.out.println(g.getText());
		     }

		}
		public String gettext(WebElement a )
		{
		   // driver.get(url);
			String s= a.getText();
		    return s;
		}
		public void dropdown(WebElement z,int index)
		{
		  //  driver.get(url);
		    Select s=new Select(z);
		    s.selectByIndex(index);
		}
		public void actions(WebElement k)
		{
		    //driver.get(url);
		    Actions a=new Actions(driver);
		    a.doubleClick(k).build().perform();
		}
		public static void setup(String url)  {
			WebDriverManager.chromedriver().setup();
			 driver = new ChromeDriver();
			 driver.get(url);
			driver.manage().window().maximize();
			
		}
		 public void quit()
		    {
		        driver.quit();
		}
}
