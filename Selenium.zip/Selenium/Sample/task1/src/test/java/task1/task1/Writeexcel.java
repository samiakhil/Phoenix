package task1.task1;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Writeexcel {

	public static WebDriver driver;

	public static void write(String s, int j, int i) throws Throwable {

		File file = new File("C:\\Users\\as21305\\Desktop\\akhil1.xlsx");
		FileInputStream inputstrm = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(inputstrm);
		XSSFSheet sh = wb.getSheetAt(0);
		sh.createRow(i).createCell(j).setCellValue(s);
		FileOutputStream fo = new FileOutputStream(file);
		wb.write(fo);
		wb.close();
//		Cell cel =row.createCell(j);
//		cel.setCellValue(s);
	}

	public static void read(int i, int j, WebElement a) throws Throwable {

		FileInputStream fi = new FileInputStream("‪C:\\Users\\as21305\\Desktop\\akhil.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fi);
		XSSFSheet sh = wb.getSheet("akhil");
		Row row = sh.getRow(i);
		Cell cell = row.getCell(j);
		for (j = 0; j < 1; j++) {
			a.sendKeys(sh.getRow(i).getCell(j).getStringCellValue());
		}

		System.out.println(sh.getRow(i).getCell(j).getStringCellValue());

	}

	public static void screenshot() throws Throwable {

		File screen = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Destination = new File("C:\\Users\\as21305\\eclipse-workspace\\task1\\Screenshots.png");
		FileUtils.copyFile(screen, Destination);

		Reporter.log("\"<a href=" + Destination.getAbsolutePath() + "> <img src=" + Destination.getAbsolutePath()
				+ " height='100' width='100'/> </a>\"");

	}

}
