/**
 * 
 */
/**
 * @author as21305
 *
 */
module Sample {
}