package Rest_Pak;

import files.Payload1;
import io.restassured.path.json.JsonPath;

public class Complex {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JsonPath kl = new JsonPath(Payload1.addplace());
		
		int count =kl.getInt("courses.size()");
		System.out.println(count);
		int totalnumber = kl.getInt("dashboard.purchaseAmount");
		System.out.println(totalnumber);
		
		String title=kl.get("courses[0].title");
		System.out.println(title);
		//print all the courses in the below title
		
		
		for(int i=0;i<count;i++) {
			String totaltitle=kl.get("courses["+i+"].title");
			System.out.println(kl.get("courses["+i+"].price"));
			System.out.println(totaltitle+"--  --");
		}
		
	}

}
