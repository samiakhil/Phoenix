package Rest_Pak;

import org.testng.Assert;
import org.testng.annotations.Test;

import files.Payload1;
import io.restassured.path.json.JsonPath;
import io.restassured.path.json.config.JsonPathConfig;

public class Sumofcourse {

	
	// using jsoneditor online
	//public static void main(String[] args) {
	     
	@Test
	public void sum() {
		
		int sum=0;
		JsonPath js = new JsonPath(Payload1.addplace());
		int count =js.getInt("courses.size()");
		System.out.println(count);
		
		for(int i=0;i<count;i++) {
			
			int price = js.getInt("courses["+i+"].price");
			int copies = js.getInt("courses["+i+"].copies");
			//int title = js.getInt("courses["+i+"].title");
			int amount =price*copies;
			System.out.println(amount);
			sum=sum+amount;
		}
			System.out.println(sum);
			int purchaseamount = js.getInt("dashboard.purchaseAmount");
			Assert.assertEquals(sum, purchaseamount);
			
		}
		
		
}


