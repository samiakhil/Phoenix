package Rest_Pak;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;

import org.testng.Assert;

import files.Payload1;


public class Payload {

	
	   public static void main(String[] args) {
		
		   
		   //given  : all input details
		   //when   : submit the api
		   //Then   : Validating Response
		   
		  RestAssured.baseURI="https://rahulshettyacademy.com";
		String res=  given()
				.log().all().
				queryParam("key","qaclick123").
				header("content-type"," application/json")	     
                .body(Payload1.pay()).
                when()
		        .post("/maps/api/place/add/json")
           .then().log().all().
           assertThat().statusCode(200).extract().response().asString();
           
	   System.out.print(res);
	   JsonPath js=new JsonPath(res);
	   String placeid = js.getString("place_id");
	   System.out.println(placeid);
	   
         //update place
	   
	   System.out.println(" updated data here-----------");
	   
	   given().log().all().queryParam("key","qaclick123").header("content-type"," application/json")
	     
       .body(" {\r\n"
       		+ "\"place_id\":\""+placeid+"\",\r\n"
       		+ "\"address\":\"80 Summer walll"
       		+ ", USA\",\r\n"
       		+ "\"key\":\"qaclick123\"\r\n"
       		+ "}").
            when().put("/maps/api/place/update/json")
            .then().assertThat().log().all().statusCode(200);
           
		  // get place
	   
	   System.out.println("get place------------------");
	   
	   String getreplace = given().log().all().queryParam("place_id", placeid).queryParam("key","qaclick123")
			   .when().get("maps/api/place/get/json")
			   .then().assertThat().log().all().statusCode(200).extract().response().asString();
	   
	   JsonPath js1=Reusable_Method.rawtojson(getreplace);
	   
	   //JsonPath jm = new JsonPath(getreplace);
	   String actual =js1.getString("address");
	   System.out.println(actual);
	   Assert.assertEquals(actual, "80 Summer walll, USA");
	   
	   
	}
	
}
