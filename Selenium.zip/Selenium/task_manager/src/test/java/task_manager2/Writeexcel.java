package task_manager2;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;

public class Writeexcel {

	
	public static WebDriver driver;

	public static void write(String s, int j, int i) throws Throwable {

		File file = new File("D:\\akhil1.xlsx");
		FileInputStream inputstrm = new FileInputStream(file);
		XSSFWorkbook wb = new XSSFWorkbook(inputstrm);
		XSSFSheet sh = wb.getSheet("akhil");
		sh.createRow(i).createCell(j).setCellValue(s);
		FileOutputStream fo = new FileOutputStream(file);
		wb.write(fo);
		wb.close();
//		Cell cel =row.createCell(j);
//		cel.setCellValue(s);
	}

	public static void read(int i, int j, WebElement a) throws Throwable {

		FileInputStream fi = new FileInputStream("C:\\Users\\as21305\\Desktop\\akhil2.xlsx");
		XSSFWorkbook wb = new XSSFWorkbook(fi);
		XSSFSheet sh = wb.getSheet("akhil2");
		Row row = sh.getRow(i);
		Cell cell = row.getCell(j);
		for (j = 0; j < 1; j++) {
			a.sendKeys(sh.getRow(i).getCell(j).getStringCellValue());
		}

		System.out.println(sh.getRow(i).getCell(j).getStringCellValue());

	}

	public static void screenshot() throws Throwable {

		File screen = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File Destination = new File("C:\\Users\\as21305\\Sample\\task_manager\\Screenshot\\3.png");
		FileUtils.copyFile(screen, Destination);

		Reporter.log("\"<a href=" + Destination.getAbsolutePath() + "> <img src=" + Destination.getAbsolutePath()
				+ " height='100' width='100'/> </a>\"");

	}

	
	
	
	
}
