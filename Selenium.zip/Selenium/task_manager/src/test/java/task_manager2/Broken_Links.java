package task_manager2;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Iterator;
import java.util.List;

import org.apache.hc.core5.http.HttpConnection;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Broken_Links {

	
	public static WebDriver driver;

	public static void main(String[] args) {
	
		String homepage ="http://www.zlti.com";		
		String URL="";
		HttpURLConnection huc =null;
		
		int responsecode=200;
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(homepage);
		List<WebElement>links = driver.findElements(By.tagName("a"));
		
		Iterator<WebElement> it =links.iterator();
		while(it.hasNext()){
			URL =it.next().getAttribute("href");
			System.out.println(URL);
			
			if(URL == null || URL.isEmpty()){
				System.out.println("URL is either not configured for anchor tag or it is empty");
				continue;
				}

				if(!URL.startsWith(homepage)){
				System.out.println("URL belongs to another domain, skipping it.");
				continue;
				}

				try {
				huc = (HttpURLConnection)(new URL(URL).openConnection());

				huc.setRequestMethod("HEAD");

				huc.connect();

				responsecode = huc.getResponseCode();

				if(responsecode >= 400){
				System.out.println(URL+" is a broken link");
				}
				else{
				System.out.println(URL+" is a valid link");
				}

				} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				}
				}

				driver.quit();

				}
			}

