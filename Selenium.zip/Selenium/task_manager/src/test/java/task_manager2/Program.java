package task_manager2;

public class Program {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a[]= {1,0,1,0,1,0};
		
		for(int b=0;b<a.length;b++) {
		for(int c=b+1;c<a.length;c++) {
			
			if(a[b]==0 && a[c]==1) {
				
				System.out.println(a[b]+"  "+a[c]);
				
				
			}
				}
		
		
			
		}
		
		
	}

}
