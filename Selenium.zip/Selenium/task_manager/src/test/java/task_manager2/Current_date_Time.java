package task_manager2;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class Current_date_Time  {

	
	//public static Object current_date_and_time() {
		
	public static void main(String[] args) {
		
	// first way
		Date t = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("YYYY_MM_dd");
		
		//System.out.println(sdf.format(t));
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.DATE,3);
		Date dt=cal.getTime();
		String futuredate = new SimpleDateFormat("YYYY/MM/dd").format(dt);	
		System.out.println(futuredate);
		
		//return sdf.format(t);
		
	// second way	
		
//		DateTimeFormatter sm =  DateTimeFormatter.ofPattern("YYYY_MM_dd"+ " "+"_HH_mm_ss ");
//		LocalDateTime now = LocalDateTime.now();
//		System.out.println(now.format(sm));
//		
//	// third way
//		
//		System.out.println(java.time.LocalDateTime.now());
//		
//	// fourth way
//		System.out.println(java.time.Clock.systemUTC().instant());
//		
		
		
	}
	
	
	}
