package task_manager2;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.Test;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;



public class Reusable2 extends Reusable1 {

	
	
@Test
	
	public void textbox() {
		
		 setup("https://adactinhotelapp.com/"); //send(fullname,lastname);
		 WebElement fullname = driver.findElement(By.xpath("//input[@type='text']"));
		 WebElement lastname = driver.findElement(By.xpath("//input[@type='password']"));
		 send(fullname,lastname);
		 quit();
		 }
		
	@Test
	public void gettext1() {
		setup("https://adactinhotelapp.com/");
		WebElement reg = driver.findElement(By.xpath("//a[text()='New User Register Here']"));
		System.out.println(gettext(reg));
		//String s=gettext(reg);
		quit();
	}
     
	
	
	@Test
	public void listofElements() {
		setup("https://adactinhotelapp.com/");
		
		allelements(driver.findElements(By.tagName("*")));
		quit();
	}
	
	@Test 
	public void select() {
	 

	setup("https://adactinhotelapp.com/"); //send(fullname,lastname);
	WebElement fullname = driver.findElement(By.xpath("//input[@type='text']"));
	WebElement lastname = driver.findElement(By.xpath("//input[@type='password']"));
	send(fullname,lastname);
	driver.findElement(By.xpath("//input[@name='login']")).click();
	WebElement slt = driver.findElement(By.xpath("//select[@name='location']"));
	dropdown(slt,1);

	quit();
	}
	
	
	@Test
	public void action() throws IOException {
		setup("https://adactinhotelapp.com/");
		WebElement act = driver.findElement(By.xpath("//td[contains(text(),'Username')]"));
	actions(act);
	Screenshot snp= new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);

	ImageIO.write(snp.getImage(), "png", new File("C:\\Users\\dt21271\\eclipse-workspace\\Maven\\Screenshots\\snpp1.png"));
	File fl = new File("C:\\Users\\dt21271\\eclipse-workspace\\Maven\\Screenshots\\snpp1.png");
	Reporter.log("Validation Is completed Successfully......." +"<a href='"+ fl + "' target=_blank'>clickhere</a>");
}

	

	
	

	
	
	
	
	
	
	
	
	
}
